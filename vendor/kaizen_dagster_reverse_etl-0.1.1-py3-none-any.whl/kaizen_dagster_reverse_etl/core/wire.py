"""The sync's wire contract: the Debezium-style envelope and its two encodings.

Consumers (the Debezium JDBC sink, the schema registry) depend on
the exact output, so the builders here are the contract's text: the envelope is
Debezium's `before`/`after`/`op`/`source` shape, the JSON encoding is Kafka
Connect JSON with the schema embedded in every message, and the Avro encoding
registers `<topic>-key`/`<topic>-value` subjects in the registry.

Nothing here touches Kafka, Dagster or the environment -- which is what makes
the wire-format tests possible without services: golden files pin the output
byte for byte.

The CDF row contract these builders consume (identical to what
table_changes()/readChangeFeed produced, so the delta reader's reconstruction
slots straight in): one dict per row, payload values typed,
`_change_type` in {insert, update_preimage, update_postimage, delete},
`_commit_version` int, `_commit_timestamp` a microsecond UTC string.
"""

import datetime
import io
import json
import struct
from itertools import zip_longest
from typing import Protocol, TypedDict, cast

import fastavro
from confluent_kafka.schema_registry import (
    Schema,
    SchemaRegistryClient,
    SchemaRegistryError,
)
from confluent_kafka.serialization import MessageField, SerializationContext

from ..components.cdf_sync.config import CdfSyncConfig

# One row's payload: column -> a JSON-shaped value. The delta reader returns
# typed scalars; the wire never needs more than that.
type RowPayload = dict[str, object]

# The registry subject records only its id through confluent-kafka's typing;
# the schema text is read back through this narrow seam.
type RegisteredSchema = str


class EventSource(TypedDict):
    """The change-event metadata Debezium keeps under `source`."""

    commit_version: int | None
    commit_timestamp: str | None


class DebeziumEvent(TypedDict):
    """One logical change: CDF's update preimage/postimage pair collapsed into
    one `before`/`after` envelope, `op` in Debezium's c/u/d vocabulary."""

    before: RowPayload | None
    after: RowPayload | None
    op: str
    source: EventSource


# CDF's own metadata columns -- see Databricks' Change Data Feed docs.
CHANGE_TYPE_COLUMN = "_change_type"
COMMIT_VERSION_COLUMN = "_commit_version"
COMMIT_TIMESTAMP_COLUMN = "_commit_timestamp"
CDF_METADATA_COLUMNS = (
    CHANGE_TYPE_COLUMN,
    COMMIT_VERSION_COLUMN,
    COMMIT_TIMESTAMP_COLUMN,
)

# Not a Connect type: marks a column carried as an ISO-8601 string with a
# timezone (e.g. 2026-10-03T03:41:08.345Z) whose schema field is named
# io.debezium.time.ZonedTimestamp, so the Debezium sink creates a timestamptz
# column. See connect_field().
ZONED_TIMESTAMP = "zoned_timestamp"
_ZONED_TIMESTAMP_SCHEMA_NAME = "io.debezium.time.ZonedTimestamp"

# Not a Connect type either: marks a DATE column, carried as days since 1970-01-01 (int32) so the
# Debezium sink creates a date column (JSON: schema name io.debezium.time.Date; Avro: logicalType date).
# The reader hands dates over as ISO strings; coerce converts them.
DATE = "date"
_DATE_SCHEMA_NAME = "io.debezium.time.Date"
_EPOCH = datetime.date(1970, 1, 1)

RowField = tuple[str, str, bool]  # (column name, connect type, optional)


def registered_schema_text(schema: object) -> RegisteredSchema:
    """The schema text of a registry version entry. confluent-kafka returns it
    as a Schema object in recent versions and a plain string in older ones --
    both through one seam here."""
    return cast("str", getattr(schema, "schema_str", schema))


def last_schema_json(row_fields: list[RowField], column_ids: dict[str, int]) -> str:
    """The state row's last_schema: the source's current columns with their
    delta.columnMapping ids (None when unknown), so the next sync can tell a
    rename from a drop."""
    return json.dumps(
        [{"name": field[0], "id": column_ids.get(field[0])} for field in row_fields]
    )


def _row_without_cdf_columns(row: RowPayload) -> RowPayload:
    return {k: v for k, v in row.items() if k not in CDF_METADATA_COLUMNS}


def to_debezium_events(
    rows: list[RowPayload], key_columns: list[str]
) -> list[DebeziumEvent]:
    """Group raw CDF rows into one Debezium-style envelope per logical change.

    CDF emits an update as *two* rows -- update_preimage and
    update_postimage, sharing the same key and `_commit_version` -- which is
    audit-useful but redundant for any consumer that just wants current
    state, and isn't a shape most downstream systems (FORMAT
    DEBEZIUM sources, generic CDC consumers) understand natively. Grouping
    by (row key, commit version) rather than assuming preimage/postimage are
    adjacent in the input list -- table_changes() documents no ordering
    guarantee, and the delta reader's reconstruction orders only by
    `_commit_version`.

    Groups accumulate *lists* of rows per change type, not a single row --
    the source table has no enforced uniqueness on key_columns (a real,
    reachable state, not a theoretical one), so a single commit can touch more
    than one physical row sharing the same key. Preimages and postimages are
    paired positionally (`zip_longest`, in per-commit ordering) rather than
    assuming exactly one of each -- CDF emits each affected physical row's own
    preimage next to its own postimage, so this correctly reconstructs N
    independent update events for N duplicate rows instead of silently
    collapsing them into one.

    Output shape per event: before/after carry the row's own columns only
    (CDF's `_change_type`/`_commit_version`/`_commit_timestamp` moved into
    `source`, which is where Debezium's own convention puts change-event
    metadata as opposed to row content).
    """
    groups: dict[tuple[object, ...], dict[str, list[RowPayload]]] = {}
    order: list[tuple[object, ...]] = []

    for row in rows:
        change_type = row.get(CHANGE_TYPE_COLUMN)
        row_key = tuple(row.get(col) for col in key_columns)
        group_key = (row_key, row.get(COMMIT_VERSION_COLUMN))
        if group_key not in groups:
            groups[group_key] = {}
            order.append(group_key)
        groups[group_key].setdefault(str(change_type), []).append(row)

    events: list[DebeziumEvent] = []
    for group_key in order:
        group = groups[group_key]
        _, commit_version = group_key
        any_row = next(iter(next(iter(group.values()))))
        raw_timestamp = any_row.get(COMMIT_TIMESTAMP_COLUMN)
        source = EventSource(
            commit_version=commit_version if isinstance(commit_version, int) else None,
            commit_timestamp=raw_timestamp if isinstance(raw_timestamp, str) else None,
        )

        for insert_row in group.get("insert", []):
            events.append(
                DebeziumEvent(
                    before=None,
                    after=_row_without_cdf_columns(insert_row),
                    op="c",
                    source=source,
                )
            )
        for delete_row in group.get("delete", []):
            events.append(
                DebeziumEvent(
                    before=_row_without_cdf_columns(delete_row),
                    after=None,
                    op="d",
                    source=source,
                )
            )
        preimages = group.get("update_preimage", [])
        postimages = group.get("update_postimage", [])
        for pre, post in zip_longest(preimages, postimages):
            events.append(
                DebeziumEvent(
                    before=_row_without_cdf_columns(pre) if pre is not None else None,
                    after=_row_without_cdf_columns(post) if post is not None else None,
                    op="u",
                    source=source,
                )
            )
    return events


def summarize_ops(events: list[DebeziumEvent]) -> dict[str, int]:
    """Count events per Debezium `op` value, for run metadata."""
    counts: dict[str, int] = {}
    for event in events:
        op = event.get("op", "unknown")
        counts[op] = counts.get(op, 0) + 1
    return counts


def coerce(value: object, connect_type: str) -> object:
    """A value as the reader handed it over -> the declared Connect type. The
    delta reader returns typed payloads already; this still casts the string
    forms (the state's recorded values, a hand-fed row) so the JSON converter's
    laxness cannot leak into the wire."""
    if value is None:
        return None
    if connect_type.startswith("int"):
        return (
            int(str(value))
            if not isinstance(value, int) or isinstance(value, bool)
            else value
        )
    if connect_type in ("float", "double"):
        return float(str(value)) if not isinstance(value, (int, float)) else value
    if connect_type == "boolean":
        return value if isinstance(value, bool) else str(value).lower() == "true"
    if connect_type == DATE:
        return (datetime.date.fromisoformat(str(value)[:10]) - _EPOCH).days
    return value


def coerce_row(row: RowPayload | None, row_fields: list[RowField]) -> RowPayload | None:
    if row is None:
        return None
    return {
        name: coerce(row.get(name), connect_type)
        for name, connect_type, _ in row_fields
    }


def connect_field(name: str, connect_type: str, optional: bool) -> dict[str, object]:
    if connect_type == ZONED_TIMESTAMP:
        return {
            "field": name,
            "type": "string",
            "name": _ZONED_TIMESTAMP_SCHEMA_NAME,
            "optional": optional,
        }
    if connect_type == DATE:
        return {
            "field": name,
            "type": "int32",
            "name": _DATE_SCHEMA_NAME,
            "optional": optional,
        }
    return {"field": name, "type": connect_type, "optional": optional}


def connect_row_schema(
    cfg: CdfSyncConfig, optional: bool, row_fields: list[RowField]
) -> dict[str, object]:
    return {
        "type": "struct",
        "name": f"{cfg.envelope_schema_name}.Value",
        "optional": optional,
        "fields": [connect_field(n, t, o) for n, t, o in row_fields],
    }


def build_connect_json_message(
    cfg: CdfSyncConfig,
    event: DebeziumEvent,
    key_columns: list[str],
    row_fields: list[RowField],
) -> tuple[bytes, bytes]:
    """Build the (key, value) pair for one event as Kafka Connect JSON with
    embedded schemas (`{"schema": ..., "payload": ...}`), for the Debezium
    JDBC sink. Key must be non-null so the sink can resolve the primary key
    from `record_key`; deletes carry the row in `before` and `op` = "d"."""
    row_for_key = event.get("after") or event.get("before") or {}
    field_types = {n: t for n, t, _ in row_fields}
    key_schema: dict[str, object] = {
        "type": "struct",
        "name": f"{cfg.envelope_schema_name}.Key",
        "optional": False,
        "fields": [connect_field(c, field_types[c], False) for c in key_columns],
    }
    key = {
        "schema": key_schema,
        "payload": {c: coerce(row_for_key.get(c), field_types[c]) for c in key_columns},
    }

    value_schema: dict[str, object] = {
        "type": "struct",
        "name": f"{cfg.envelope_schema_name}.Envelope",
        "optional": False,
        "fields": [
            {
                "field": "before",
                **connect_row_schema(cfg, optional=True, row_fields=row_fields),
            },
            {
                "field": "after",
                **connect_row_schema(cfg, optional=True, row_fields=row_fields),
            },
            {"field": "op", "type": "string", "optional": False},
            {
                "field": "source",
                "type": "struct",
                "optional": True,
                "fields": [
                    {"field": "commit_version", "type": "int64", "optional": True},
                    {"field": "commit_timestamp", "type": "string", "optional": True},
                ],
            },
        ],
    }
    source = event.get("source") or EventSource(
        commit_version=None, commit_timestamp=None
    )
    payload: dict[str, object] = {
        "before": coerce_row(event.get("before"), row_fields),
        "after": coerce_row(event.get("after"), row_fields),
        "op": event["op"],
        "source": {
            "commit_version": coerce(source.get("commit_version"), "int64"),
            "commit_timestamp": source.get("commit_timestamp"),
        },
    }
    value = {"schema": value_schema, "payload": payload}
    return (
        json.dumps(key, default=str, sort_keys=True).encode("utf-8"),
        json.dumps(value, default=str).encode("utf-8"),
    )


# --- Avro (Confluent wire format, schemas in the registry) ----------------------
# Same envelope as the JSON message. Every row column is a nullable union defaulting to null, so a column
# added later is a backward-compatible schema change; timestamps stay ZonedTimestamp strings, the one form
# that gives timestamptz with microseconds downstream. The registry (Apicurio) matches a
# schema by its exact string, and the Confluent converter looks the schema up in the Avro library's compact
# canonical form, so schemas are registered in that form: compact JSON, with the namespace only on the
# top-level record (nested records inherit it and are referenced by their short name).

_AVRO_TYPE_BY_CONNECT_TYPE = {
    "int8": "int",
    "int16": "int",
    "int32": "int",
    "int64": "long",
    "float": "float",
    "double": "double",
    "boolean": "boolean",
    "string": "string",
}


def avro_value_type(connect_type: str) -> object:
    if connect_type == ZONED_TIMESTAMP:
        return {"type": "string", "connect.name": _ZONED_TIMESTAMP_SCHEMA_NAME}
    if connect_type == DATE:
        return {"type": "int", "logicalType": "date"}
    return _AVRO_TYPE_BY_CONNECT_TYPE[connect_type]


class AvroSchemaSource(Protocol):
    """The config surface the Avro schema builders read: the envelope's name and the
    two subjects. The sync's CdfSyncConfig carries them -- the wire contract's
    arithmetic lives in one place."""

    @property
    def envelope_schema_name(self) -> str: ...

    @property
    def key_subject(self) -> str: ...

    @property
    def value_subject(self) -> str: ...


def avro_schemas(
    cfg: AvroSchemaSource, key_columns: list[str], row_fields: list[RowField]
) -> tuple[dict[str, object], dict[str, object]]:
    """(key schema, value schema); the value schema is the Debezium envelope."""
    namespace = cfg.envelope_schema_name
    field_types = {n: t for n, t, _ in row_fields}
    key_schema: dict[str, object] = {
        "type": "record",
        "name": "Key",
        "namespace": namespace,
        "fields": [
            {"name": c, "type": avro_value_type(field_types[c])} for c in key_columns
        ],
    }
    row_schema: dict[str, object] = {
        "type": "record",
        "name": "Value",
        "fields": [
            {"name": n, "type": ["null", avro_value_type(t)], "default": None}
            for n, t, _ in row_fields
        ],
    }
    source_schema: dict[str, object] = {
        "type": "record",
        "name": "Source",
        "fields": [
            {"name": "commit_version", "type": ["null", "long"], "default": None},
            {"name": "commit_timestamp", "type": ["null", "string"], "default": None},
        ],
    }
    value_schema: dict[str, object] = {
        "type": "record",
        "name": "Envelope",
        "namespace": namespace,
        "fields": [
            {"name": "before", "type": ["null", row_schema], "default": None},
            {"name": "after", "type": ["null", "Value"], "default": None},
            {"name": "op", "type": "string"},
            {"name": "source", "type": ["null", source_schema], "default": None},
        ],
    }
    return key_schema, value_schema


def avro_schema_string(schema: dict[str, object]) -> str:
    return json.dumps(schema, separators=(",", ":"))


def avro_payloads(
    event: DebeziumEvent, key_columns: list[str], row_fields: list[RowField]
) -> tuple[dict[str, object], dict[str, object]]:
    row_for_key = event.get("after") or event.get("before") or {}
    field_types = {n: t for n, t, _ in row_fields}
    source = event.get("source") or EventSource(
        commit_version=None, commit_timestamp=None
    )
    key: dict[str, object] = {
        c: coerce(row_for_key.get(c), field_types[c]) for c in key_columns
    }
    value: dict[str, object] = {
        "before": coerce_row(event.get("before"), row_fields),
        "after": coerce_row(event.get("after"), row_fields),
        "op": event["op"],
        "source": {
            "commit_version": coerce(source.get("commit_version"), "int64"),
            "commit_timestamp": source.get("commit_timestamp"),
        },
    }
    return key, value


class WireAvroSerializer:
    """A Confluent-wire Avro serializer that resolves the schema id ONCE, at
    construction, and encodes each message directly with fastavro plus the
    hand-written framing (magic byte 0, big-endian int32 schema id, payload).

    It replaces confluent-kafka's AvroSerializer, whose output is byte-identical
    but whose per-call machinery (subject-name strategy, schema-parse cache,
    the rules engine, original-key tracking) costs ~1.5 ms per message -- at a
    1M-row sync that is ~25 minutes of pure overhead against ~0.01 ms/msg here
    (measured 2026-11-09: 1.46 ms/msg via AvroSerializer, 0.009 ms/msg via
    fastavro.schemaless_writer for the same events and schema).

    `use_latest=True` mirrors the conf the old path passed when the schemas are
    already in the registry: the id is the registry's LATEST version for the
    subject (get_latest_version), not a fresh register. `use_latest=False`
    mirrors auto.register.schemas: the schema registers at construction (the
    old path registered on the first message -- the sync only builds
    serializers for event-bearing chunks, so the registration happens either
    way) and that register's id is used."""

    _parsed: dict[str, object]
    _schema_id: int

    def __init__(
        self,
        client: SchemaRegistryClient,
        schema: dict[str, object],
        subject: str,
        use_latest: bool,
    ) -> None:
        self._parsed = cast("dict[str, object]", fastavro.parse_schema(schema))
        if use_latest:
            self._schema_id = cast("int", client.get_latest_version(subject).schema_id)
        else:
            # register_schema_full_response, not register_schema: the latter
            # returns the bare id int, the former the RegisteredSchema the id
            # comes from -- and it is the call the old AvroSerializer path
            # made, so registry-recording fakes see the same request.
            self._schema_id = cast(
                "int",
                client.register_schema_full_response(
                    subject, Schema(avro_schema_string(schema), "AVRO")
                ).schema_id,
            )

    def __call__(
        self, obj: object, ctx: SerializationContext | None = None
    ) -> bytes | None:
        if obj is None:
            return None
        buf = io.BytesIO()
        fastavro.schemaless_writer(buf, self._parsed, obj)  # pyright: ignore[reportUnknownMemberType]
        return _WIRE_MAGIC + struct.pack(">i", self._schema_id) + buf.getvalue()


_WIRE_MAGIC = b"\x00"


def avro_serializers(
    cfg: CdfSyncConfig,
    key_columns: list[str],
    row_fields: list[RowField],
    client: SchemaRegistryClient,
) -> tuple[WireAvroSerializer, WireAvroSerializer]:
    """Serializers that write the Confluent wire format. When both schemas are already in the registry (checked
    here, one GET per subject) they point at the latest registered version instead of re-registering on the first
    message -- two fewer round-trips per unchanged sync. When they are not (first run), the serializers register
    them at construction. See WireAvroSerializer for why the encoding is direct
    fastavro rather than confluent-kafka's AvroSerializer."""
    key_schema, value_schema = avro_schemas(cfg, key_columns, row_fields)
    known = all(
        schema_already_registered(client, subject, schema)
        for subject, schema in (
            (cfg.key_subject, key_schema),
            (cfg.value_subject, value_schema),
        )
    )
    return (
        WireAvroSerializer(client, key_schema, cfg.key_subject, use_latest=known),
        WireAvroSerializer(client, value_schema, cfg.value_subject, use_latest=known),
    )


def schema_already_registered(
    client: SchemaRegistryClient, subject: str, schema: dict[str, object]
) -> bool:
    """True when the registry's latest version for subject is identical to schema.

    Both sides are parsed before comparing, so key-order/whitespace differences
    between what we build and what the registry stores cannot false-negative.
    Any registry error -- a missing subject above all -- counts as "not
    registered": the caller then registers anyway, exactly as before this check
    existed, so a registry blip can never skip a needed registration."""
    try:
        latest = client.get_latest_version(subject)
        registered = registered_schema_text(latest.schema)
        same = cast(
            "bool", json.loads(registered) == json.loads(avro_schema_string(schema))
        )
        return same
    except SchemaRegistryError:
        return False


def register_avro_schemas(
    client: SchemaRegistryClient,
    cfg: AvroSchemaSource,
    key_columns: list[str],
    row_fields: list[RowField],
) -> None:
    """Register both schemas and make sure the registry's LATEST version is the one
    the sync just built.

    Re-registering content that already exists as an OLDER version is a no-op on
    Confluent-compatible registries: the register returns that version's schema id
    and does not create a new version, so the latest stays wherever it was.
    Consumers validate a new column against the registry's latest, so
    "registered" is not enough -- the built schema must BE the latest.

    The latest-version READ also lags the writes for seconds (Apicurio, seen
    live: a register answered with a NEW version's schema id while
    get_latest_version still reported the old one past a 4s retry window), so
    the decision here never reads after writing: it takes a FRESH snapshot of
    the subject (versions, ids, contents) before the register, then reads the
    register's returned schema id -- authoritative for what the register did.
    A returned id unknown to the snapshot means a new version was created (the
    latest is ours); an id matching the version that WAS the latest means the
    register deduped onto it (the latest is ours); an id matching an OLDER
    version means the register deduped onto it, and the versions after it are
    soft-deleted before registering again -- the dedup then lands on that
    version, which is now the latest. Soft delete keeps the content resolvable
    by id, so messages already on the topic still deserialize (verified live:
    ids of the deleted versions still answer GET /schemas/ids/<id>)."""
    key_schema, value_schema = avro_schemas(cfg, key_columns, row_fields)
    for subject, schema in (
        (cfg.key_subject, key_schema),
        (cfg.value_subject, value_schema),
    ):
        built = avro_schema_string(schema)
        # FRESH reads, before any write: version -> (schema id, content == built).
        snapshot: dict[int, tuple[int, bool]] = {}
        try:
            for version in client.get_versions(subject):
                entry = client.get_version(subject, version)
                if entry.schema_id is None:
                    continue  # an entry without an id cannot match a register's return
                stored = cast(
                    "bool",
                    json.loads(registered_schema_text(entry.schema))
                    == json.loads(built),
                )
                snapshot[version] = (entry.schema_id, stored)
        except SchemaRegistryError:
            pass  # a missing subject registers below
        if snapshot and snapshot[max(snapshot)][1]:
            continue  # the latest already IS the built schema
        schema_id = client.register_schema(subject, Schema(built, "AVRO"))
        holder = next((v for v, (i, _) in snapshot.items() if i == schema_id), None)
        if holder is None or holder == max(snapshot):
            continue  # a new version was created, or the dedup landed on the version that was already latest
        # The register deduped onto an OLDER version: retire everything after it
        # (soft delete) and register again -- the dedup then lands on that
        # version, now the latest. No reads after the writes: the register's id
        # already told us everything this check would ask.
        for version in sorted((v for v in snapshot if v > holder), reverse=True):
            try:
                _ = client.delete_version(subject, version)
            except SchemaRegistryError:
                pass  # already gone
        _ = client.register_schema(subject, Schema(built, "AVRO"))


def build_avro_message(
    cfg: CdfSyncConfig,
    event: DebeziumEvent,
    key_columns: list[str],
    row_fields: list[RowField],
    serializers: tuple[WireAvroSerializer, WireAvroSerializer],
) -> tuple[bytes, bytes]:
    key, value = avro_payloads(event, key_columns, row_fields)
    key_serializer, value_serializer = serializers
    key_bytes = key_serializer(
        key, SerializationContext(cfg.kafka_topic, MessageField.KEY)
    )
    value_bytes = value_serializer(
        value, SerializationContext(cfg.kafka_topic, MessageField.VALUE)
    )
    # A None return means the serializer refused the payload -- a configuration
    # error, not a wire format; surface it as one instead of producing None.
    if key_bytes is None or value_bytes is None:
        raise RuntimeError(f"Avro serialization returned None for {cfg.kafka_topic}")
    return key_bytes, value_bytes
