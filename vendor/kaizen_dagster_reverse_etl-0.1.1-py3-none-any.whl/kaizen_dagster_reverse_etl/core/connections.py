"""The env contract: one env-fed function per connection.

The components declare no Dagster resources — the same defs.yaml deploys to
staging and production, and the environment is the only layer that differs per
deployment (the host location provisions env per environment: Vault → External
Secrets Operator → container_context.<env>.yaml). Every connection here reads
`os.environ` at call time — never import time, so a test (or a reconfigured
process) can change the environment between calls — and the assets call these
functions directly: no `required_resource_keys`, no `context.resources`,
nothing for a team to bind. Names and decisions live in files, values live in
the environment.

The functions return the connection's client surface (the methods the assets
call); the tests' fakes (tests/reverse_etl_fakes.py) implement the same shapes,
and a test patches these functions with them.

## The environment the functions read

| Function | Variables |
|---|---|
| `state_postgres` | `POSTGRES_HOST` (**required** — no default: `host.docker.internal` does not resolve on the macOS host, so one value cannot serve both the containers and the host), `POSTGRES_PORT` (5432), `POSTGRES_DB` (postgres), `POSTGRES_USER` (postgres), `POSTGRES_PASSWORD` ("") |
| `databricks(workspace_url)` | `DATABRICKS_AZURE_TENANT_ID`, `DATABRICKS_AZURE_CLIENT_ID`, `DATABRICKS_AZURE_CLIENT_SECRET` — the sync's own storage credentials, which delta-rs needs and no resource ever carries; **service principal, never a SAS token** (a SAS token expires and silently broke every MV refresh once), and PATs are org-banned. The workspace URL is an argument, not env: the sync component resolves `workspace:` against the root `databricks-workspaces.yaml` and passes it down |
| `kafka` | `KAFKA_OUTPUT_BOOTSTRAP` (required — the producer config raises without it) plus the optional `KAFKA_OUTPUT_SASL_USERNAME`/`_MECHANISM`/`_PASSWORD`; admin, producer and consumer share the one output-cluster scheme |
| `registry` | none — the registry URL is a config field with an org-specific default (everything env-adjacent that is not a credential stays in config) |

Everything env-adjacent that is not a credential stays in YAML or config: the
registry URL is a config field, the DuckDB path is typed, topic names are
derived.
"""

import json
import os
import time
from collections.abc import Callable
from typing import cast

import psycopg2
import requests
from confluent_kafka import Producer
from confluent_kafka.admin import AdminClient
from confluent_kafka.schema_registry import SchemaRegistryClient
from psycopg2.extensions import connection as _PgConnection

# The AAD app-id scope of Azure Databricks: the client-credentials grant the
# service principal exchanges its secret against. It is a fixed public
# identifier, not a deployment value.
_DATABRICKS_AAD_SCOPE = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"

# Transient network failures worth one retry: the brokers and the control plane
# are reached over VPN and blips are the common failure. The retry re-sends the
# request, so a statement that executed before the connection dropped may run
# twice; every call here tolerates that (the UC lookups are reads, the token
# grant is idempotent).
_TRANSIENT = (requests.exceptions.ConnectionError, requests.exceptions.Timeout)


def _with_retry(
    send: Callable[[], requests.Response], attempts: int = 2, delay: float = 3.0
) -> requests.Response:
    """Call send(), retrying once on transient connection errors (VPN blips)."""
    for attempt in range(attempts):
        try:
            return send()
        except _TRANSIENT:
            if attempt == attempts - 1:
                raise
            time.sleep(delay)
    raise AssertionError("unreachable: the loop either returns or raises")


# The psycopg2 surface the call sites use: a context-manager connection whose
# cursor is itself a context manager executing one statement and fetching its rows.
class Connectable:
    """The one method the Postgres call sites need: .connect(). Public because the state backends (core/state.py) type their postgres argument with it."""

    _open: Callable[[], _PgConnection]

    def __init__(self, open_connection: Callable[[], _PgConnection]) -> None:
        self._open = open_connection

    def connect(self) -> _PgConnection:
        return self._open()


def _require_postgres_host() -> str:
    host = os.environ.get("POSTGRES_HOST", "")
    if not host:
        raise ValueError(
            "POSTGRES_HOST is required (no default: host.docker.internal does not resolve on a macOS host, so one value cannot serve both the containers and the host). The host location sets it per environment in its container context."
        )
    return host


def state_postgres() -> Connectable:
    """The sync's watermark state (core/state.py's PostgresSyncState)."""

    def open_connection():
        return psycopg2.connect(
            host=_require_postgres_host(),
            port=int(os.environ.get("POSTGRES_PORT", "5432")),
            dbname=os.environ.get("POSTGRES_DB", "postgres"),
            user=os.environ.get("POSTGRES_USER", "postgres"),
            password=os.environ.get("POSTGRES_PASSWORD", ""),
        )

    return Connectable(open_connection)


def azure_storage_options(location: str) -> dict[str, str]:
    """delta-rs storage options for a table's ABFS location: the same service
    principal the sync already authenticates with, under the *bare* key names
    object_store's Azure builder accepts. The azure_-prefixed variants silently
    miss the tenant and secret, fall back to the IMDS managed-identity probe
    (169.254.169.254 — unreachable outside Azure) and hang until the retries
    exhaust (verified live)."""
    return {
        "account_name": location.split("@")[1].split(".")[0],
        "client_id": os.environ["DATABRICKS_AZURE_CLIENT_ID"],
        "tenant_id": os.environ["DATABRICKS_AZURE_TENANT_ID"],
        "client_secret": os.environ["DATABRICKS_AZURE_CLIENT_SECRET"],
    }


# The control-plane lookups (the AAD token, the UC storage locations) are stable
# for hours and cost ~1.3s per sync when fetched fresh. They are cached on disk
# with TTLs: the token retires well before its ~1h validity, the locations
# because a drop+recreate can move a managed table. The location TTL is short on
# purpose — a stale location after a drop+recreate points at the OLD table's
# storage, which is worse than a fresh fetch. A missing or corrupted cache just
# means a fresh fetch; the write is best-effort.
_CONTROL_PLANE_CACHE_PATH = os.path.join(
    os.environ.get("DAGSTER_HOME", "/workspace"),
    "dagster_storage",
    "reverse_etl_control_plane_cache.json",
)
_TOKEN_CACHE_TTL = 45 * 60
_LOCATION_CACHE_TTL = 10 * 60


def _control_plane_cache_read() -> dict[str, object]:
    try:
        with open(_CONTROL_PLANE_CACHE_PATH) as handle:
            loaded = cast("object", json.load(handle))
        # The cache's dict shape; anything else is a corrupted cache, which reads as a miss.
        cache = cast("dict[str, object]", loaded) if isinstance(loaded, dict) else {}
        return cache
    except OSError, ValueError:
        return {}


def _control_plane_cache_write(cache: dict[str, object]) -> None:
    try:
        parent = os.path.dirname(_CONTROL_PLANE_CACHE_PATH)
        if parent:
            os.makedirs(parent, exist_ok=True)
        temporary = _CONTROL_PLANE_CACHE_PATH + ".tmp"
        with open(temporary, "w") as handle:
            json.dump(cache, handle)
        os.replace(temporary, _CONTROL_PLANE_CACHE_PATH)
    except OSError:
        pass  # best-effort: a fresh fetch is always the fallback


class DatabricksApi:
    """The Databricks REST surface the sync reaches — all control plane, no
    compute: the AAD token grant, Unity Catalog storage locations, and their
    disk cache. The data plane is delta-rs reading ADLS directly (the zero-DBU
    seam); this class never touches a warehouse."""

    _workspace_url: str

    def __init__(self, workspace_url: str) -> None:
        self._workspace_url = workspace_url.rstrip("/")

    def require_env(self) -> None:
        """Fail fast with the missing service-principal variable names."""
        missing = [
            name
            for name in (
                "DATABRICKS_AZURE_TENANT_ID",
                "DATABRICKS_AZURE_CLIENT_ID",
                "DATABRICKS_AZURE_CLIENT_SECRET",
            )
            if not os.environ.get(name, "")
        ]
        if missing:
            raise ValueError(f"Missing required env vars: {missing}")

    def token(self) -> str:
        """A fresh AAD access token (client-credentials grant)."""
        response = _with_retry(
            lambda: requests.post(
                f"https://login.microsoftonline.com/{os.environ['DATABRICKS_AZURE_TENANT_ID']}/oauth2/v2.0/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": os.environ["DATABRICKS_AZURE_CLIENT_ID"],
                    "client_secret": os.environ["DATABRICKS_AZURE_CLIENT_SECRET"],
                    "scope": _DATABRICKS_AAD_SCOPE,
                },
                timeout=30,
            )
        )
        response.raise_for_status()
        payload = cast("dict[str, object]", response.json())
        return str(payload["access_token"])

    def cached_token(self) -> str:
        """token() with a 45-minute disk cache (the AAD token lives ~1h). The
        sync's pre-check needs the token for the UC location lookups on every
        run; a fresh client-credentials request costs ~0.4s of each one."""
        cache = _control_plane_cache_read()
        entry = _cast_entry(cache.get("token"))
        if _cache_fresh(entry):
            return str(entry["value"])
        token = self.token()
        cache["token"] = {"value": token, "expires": time.time() + _TOKEN_CACHE_TTL}
        _control_plane_cache_write(cache)
        return token

    def table_location(self, token: str, fqn: str) -> str:
        """The table's abfss storage location, from the Unity Catalog REST API.

        Control-plane call — no compute, no DBUs. Replaces the DESCRIBE DETAIL
        the prototypes ran once on the warehouse."""
        response = _with_retry(
            lambda: requests.get(
                f"{self._workspace_url}/api/2.1/unity-catalog/tables/{fqn}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
        )
        if not response.ok:
            raise RuntimeError(
                f"UC REST lookup for {fqn} failed ({response.status_code}): {response.text[:300]}"
            )
        payload = cast("dict[str, object]", response.json())
        location = str(payload.get("storage_location") or "")
        if not location:
            raise RuntimeError(f"UC REST returned no storage_location for {fqn}")
        return location

    def table_location_cached(self, token: str, fqn: str) -> str:
        """table_location() with a 10-minute disk cache. Managed tables' storage
        locations only move when the table is dropped and recreated; the TTL
        bounds a stale entry and clear_location_cache clears it immediately. If
        a fetch fails (e.g. a rotated secret invalidated a cached token), the
        whole cache is discarded so the next run starts fresh."""
        cache = _control_plane_cache_read()
        locations = _cast_locations(cache.get("locations"))
        entry = _cast_entry(locations.get(fqn))
        if _cache_fresh(entry):
            return str(entry["value"])
        try:
            location = self.table_location(token, fqn)
        except RuntimeError:
            _control_plane_cache_write({})
            raise
        locations[fqn] = {
            "value": location,
            "expires": time.time() + _LOCATION_CACHE_TTL,
        }
        cache["locations"] = locations
        _control_plane_cache_write(cache)
        return location

    def clear_location_cache(self) -> None:
        """Delete the on-disk token/location cache (best-effort). A drop+recreate
        moves managed tables to new storage locations, and a cached location
        would point at the dead tables — the sync would pre-check 'no new
        commits' against them and silently no-op until the TTL expired (bit us
        live: reset → insert → sync produced nothing for ten minutes)."""
        try:
            os.remove(_CONTROL_PLANE_CACHE_PATH)
        except OSError:
            pass  # nothing cached (or already gone) — a fresh fetch is the fallback


def _cast_entry(entry: object) -> dict[str, object]:
    return cast("dict[str, object]", entry) if isinstance(entry, dict) else {}


def _cast_locations(locations: object) -> dict[str, object]:
    return cast("dict[str, object]", locations) if isinstance(locations, dict) else {}


def _cache_fresh(entry: dict[str, object]) -> bool:
    expires = entry.get("expires")
    return (
        isinstance(expires, (int, float))
        and expires > time.time()
        and bool(entry.get("value"))
    )


class KafkaClients:
    """The Kafka clients: the admin (the sync's topic check) and the output
    cluster's producer. One credential scheme for both: KAFKA_OUTPUT_*."""

    def admin_client(self) -> AdminClient:
        bootstrap = os.environ.get("KAFKA_OUTPUT_BOOTSTRAP", "")
        if not bootstrap:
            raise ValueError("KAFKA_OUTPUT_BOOTSTRAP must be set")
        conf: dict[str, str | int | float | bool] = {"bootstrap.servers": bootstrap}
        username = os.environ.get("KAFKA_OUTPUT_SASL_USERNAME", "")
        if username:
            conf.update(
                {
                    "security.protocol": "SASL_SSL",
                    "sasl.mechanism": os.environ.get(
                        "KAFKA_OUTPUT_SASL_MECHANISM", "SCRAM-SHA-512"
                    ),
                    "sasl.username": username,
                    "sasl.password": os.environ.get("KAFKA_OUTPUT_SASL_PASSWORD", ""),
                }
            )
        return AdminClient(conf)

    def producer(self) -> Producer:
        """A producer whose TLS/SASL handshake starts now, in librdkafka's
        background threads. The brokers are reached over VPN and connecting
        takes ~9s; creating the producer before the delta reads lets that happen
        off the critical path (a fresh process per run means there is nothing to
        reuse it from)."""
        producer = Producer(kafka_producer_config())
        _ = producer.poll(0)
        return producer


def kafka_producer_config() -> dict[str, str]:
    """The output cluster's client config, shared by the admin and the
    producer: one credential scheme, one place."""
    bootstrap = os.environ.get("KAFKA_OUTPUT_BOOTSTRAP", "")
    if not bootstrap:
        raise ValueError("KAFKA_OUTPUT_BOOTSTRAP must be set")

    conf: dict[str, str] = {"bootstrap.servers": bootstrap}
    username = os.environ.get("KAFKA_OUTPUT_SASL_USERNAME", "")
    if username:
        conf.update(
            {
                "security.protocol": "SASL_SSL",
                "sasl.mechanism": os.environ.get(
                    "KAFKA_OUTPUT_SASL_MECHANISM", "SCRAM-SHA-512"
                ),
                "sasl.username": username,
                "sasl.password": os.environ.get("KAFKA_OUTPUT_SASL_PASSWORD", ""),
            }
        )
    # Volume headroom (100k+ event syncs): compress on the wire, let librdkafka
    # batch briefly (the produce loop's final flush absorbs the linger), and
    # raise the queue ceilings so a large backlog never blocks the enqueuer.
    conf.update(
        {
            "compression.type": "lz4",
            "linger.ms": "50",
            "batch.size": str(1024 * 1024),
            "queue.buffering.max.messages": str(500000),
            "batch.num.messages": str(20000),
        }
    )
    return conf


class SchemaRegistry:
    """The registry client factory. The URL is a config field (an org-specific
    default), so this connection reads no environment."""

    def client(self, url: str) -> SchemaRegistryClient:
        return SchemaRegistryClient({"url": url})


def databricks(workspace_url: str) -> DatabricksApi:
    return DatabricksApi(workspace_url)


def kafka() -> KafkaClients:
    return KafkaClients()


def registry() -> SchemaRegistry:
    return SchemaRegistry()
