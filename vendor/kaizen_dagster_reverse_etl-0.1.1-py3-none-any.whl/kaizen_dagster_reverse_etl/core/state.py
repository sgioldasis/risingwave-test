"""The sync's watermark state: where the last synced version and the last-seen schema live.

Three backends behind one small interface:

- `DeltaSyncState` — the default: a Delta table addressed by its UC name and resolved to storage
  through the same cached UC lookup the source uses, so the YAML stays environment-neutral. The
  table is the deployment's one-time setup: the lookup failure carries the CREATE TABLE, and a
  registered-but-empty table fails with how to initialize it. Reads and writes are delta-rs over
  storage — no compute, no DBUs, no Postgres dependency.
- `PostgresSyncState` — the shared Postgres table `reverse_etl_sync_state`, keyed by sync_name,
  that the team creates (D1). The precondition fails with the DDL when it is absent.
- `DuckDBSyncState` — a local file, single writer, created on first run (D15): a local file is not
  shared infrastructure, so the sync may bring it into being itself.

All keep the same columns and the same semantics — append-only writes, freshest-row-wins reads —
so a sync's replay behaviour does not depend on the backend. No imports from the other library
modules (beyond the connection types), so any of them can import this one.

Besides the watermark, every write records WHERE it came from: `source_fqn` and `label` beside
`sync_name` (the watermark guard's stable anchor — both sync_name and label move on a rename,
the source table does not).
"""

import datetime
from typing import TYPE_CHECKING, Protocol, cast, final

import psycopg2

from ..components.cdf_sync.config import CdfSyncConfig
from .connections import Connectable, DatabricksApi, azure_storage_options

if TYPE_CHECKING:
    import duckdb

STATE_TABLE = "reverse_etl_sync_state"


def state_table_ddl(table: str = STATE_TABLE) -> str:
    """The state table's DDL — what the host location's setup runs and what the Postgres
    precondition's error carries, so a team can create the table from the failure message alone."""
    return f"""CREATE TABLE IF NOT EXISTS {table} (
    sync_name TEXT NOT NULL,
    last_commit_version BIGINT NOT NULL,
    last_schema TEXT,
    source_fqn TEXT,
    label TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
)"""


# The guard's columns: every write records WHERE it came from (source_fqn, label) beside
# sync_name, so an empty read for this sync's key can be checked against rows for the same
# source under another key — sync_name and label both move on a rename, the source does not.
GUARD_COLUMNS = ("source_fqn", "label")


def state_table_migration_ddl(table: str = STATE_TABLE) -> str:
    """The guard columns' migration for a pre-guard table: what require()'s failure carries
    verbatim (check-only) and what create() runs (migrate), so an existing deployment's next
    setup run upgrades its table in place. DuckDB files pre-dating the guard are recreated,
    not migrated — disposable, single-writer."""
    return (
        ";\n".join(
            f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} TEXT"
            for column in GUARD_COLUMNS
        )
        + ";"
    )


class SyncState(Protocol):
    """The sync's watermark store. A failed run leaves the watermark unmoved, so the next run
    replays the same versions and re-runs whatever failed — every implementation must keep that
    true (targets upsert by key, which makes the replay safe)."""

    def require(self) -> None:
        """The run's precondition. Postgres: fail with the DDL when the table is absent. DuckDB:
        create the file and table on first run."""
        ...

    def read(self, sync_name: str) -> list[tuple[int | None, str | None]]:
        """[(last_commit_version, last_schema), ...] freshest first. An empty list is the
        first-run state, not an error."""
        ...

    def write(
        self,
        sync_name: str,
        version: int,
        last_schema: str | None,
        *,
        source_fqn: str | None = None,
        label: str | None = None,
    ) -> None:
        """Append the watermark. source_fqn and label ride along as the watermark guard's stable
        anchor (a legacy row written without them matches no source and is repopulated by the
        next run)."""

    def rows_for_source(self, source_fqn: str) -> list[tuple[str, str | None]]:
        """[(sync_name, label), ...] for rows recorded against this source table — the watermark
        guard's lookup. A row written without a source (NULL) matches nothing, like SQL NULL."""
        ...

    def create(self) -> None:
        """Create the store if absent (the host location's setup)."""
        ...

    def clear(self, sync_name: str) -> str:
        """Delete one sync's rows (the store may be shared — never drop it); returns the line to
        log."""
        ...


@final
class PostgresSyncState:
    """The watermark in the shared Postgres table (keyed by sync_name, so a reset clears only its
    own rows)."""

    def __init__(self, postgres: Connectable, table: str = STATE_TABLE) -> None:
        self.postgres, self.table = postgres, table

    def ddl(self) -> str:
        return state_table_ddl(self.table)

    def require(self) -> None:
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(f"SELECT to_regclass('{self.table}')")
                rows = cast("list[tuple[object, ...]]", cur.fetchall())
                present = rows[0][0] is not None
                columns: set[str] = set()
                if present:
                    cur.execute(
                        "SELECT column_name FROM information_schema.columns WHERE table_name = %s",
                        (self.table.split(".")[-1],),
                    )
                    columns = {
                        str(row[0])
                        for row in cast("list[tuple[object, ...]]", cur.fetchall())
                    }
        finally:
            conn.close()
        if not present:
            raise RuntimeError(
                f"The watermark state table {self.table} does not exist -- create it before running the sync:\n{self.ddl()}"
            )
        missing = sorted(set(GUARD_COLUMNS) - columns)
        if missing:
            # Check-only: the run refuses to start on a pre-guard table rather than failing at
            # write time with UndefinedColumn — the fix travels with the failure (D15-consistent).
            raise RuntimeError(
                f"The watermark state table {self.table} predates the watermark guard (missing column(s): {', '.join(missing)}). Add them before running the sync:\n{state_table_migration_ddl(self.table)}"
            )

    def read(self, sync_name: str) -> list[tuple[int | None, str | None]]:
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        f"SELECT last_commit_version, last_schema FROM {self.table} WHERE sync_name = %s ORDER BY last_commit_version DESC",
                        (sync_name,),
                    )
                except psycopg2.errors.UndefinedTable:
                    conn.rollback()
                    return []
                rows = cast("list[tuple[object, ...]]", cur.fetchall())
                return [
                    (
                        int(cast("int", v)) if v is not None else None,
                        cast("str | None", s),
                    )
                    for v, s in rows
                ]
        finally:
            conn.close()

    def rows_for_source(self, source_fqn: str) -> list[tuple[str, str | None]]:
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        f"SELECT sync_name, label FROM {self.table} WHERE source_fqn = %s",
                        (source_fqn,),
                    )
                except psycopg2.errors.UndefinedTable:
                    conn.rollback()
                    return []
                rows = cast("list[tuple[object, ...]]", cur.fetchall())
                return [(str(name), cast("str | None", label)) for name, label in rows]
        finally:
            conn.close()

    def write(
        self,
        sync_name: str,
        version: int,
        last_schema: str | None,
        *,
        source_fqn: str | None = None,
        label: str | None = None,
    ) -> None:
        # The precondition at the top of the run checked the table, so an INSERT here never
        # creates it — a table dropped mid-run fails the run with the watermark unmoved, and the
        # next run replays the same versions.
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO {self.table} (sync_name, last_commit_version, last_schema, source_fqn, label) VALUES (%s, %s, %s, %s, %s)",
                    (sync_name, version, last_schema, source_fqn, label),
                )
            conn.commit()
        finally:
            conn.close()

    def create(self) -> None:
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(self.ddl())
                # The migration rides with create(): a pre-guard table upgrades in place, so the
                # host's next setup run brings its state table to the guard's shape.
                cur.execute(state_table_migration_ddl(self.table))
            conn.commit()
        finally:
            conn.close()

    def clear(self, sync_name: str) -> str:
        conn = self.postgres.connect()
        try:
            with conn.cursor() as cur:
                try:
                    cur.execute(
                        f"DELETE FROM {self.table} WHERE sync_name = %s", (sync_name,)
                    )
                except psycopg2.errors.UndefinedTable:
                    conn.rollback()
                    return f"{self.table} does not exist — nothing to clear"
                else:
                    conn.commit()
                    return f"Cleared {sync_name}'s watermark rows from {self.table} (other syncs' watermarks untouched)"
        finally:
            conn.close()


@final
class DuckDBSyncState:
    """The watermark in a local DuckDB file: one sync per file (DuckDB allows one writer), same
    table and columns as the Postgres backend. Created on first run (D15) — a local file is not
    shared infrastructure, so require() brings it into being instead of failing."""

    def __init__(self, path: str) -> None:
        self.path = path

    def _connect(self) -> duckdb.DuckDBPyConnection:
        # Imported here so a Postgres-state sync never pays the duckdb import.
        import duckdb

        return duckdb.connect(self.path)

    def ddl(self) -> str:
        return state_table_ddl(STATE_TABLE)

    def require(self) -> None:
        self.create()

    def create(self) -> None:
        with self._connect() as con:
            _ = con.execute(self.ddl())

    def read(self, sync_name: str) -> list[tuple[int | None, str | None]]:
        with self._connect() as con:
            rows = cast(
                "list[tuple[object, ...]]",
                con.execute(
                    f"SELECT last_commit_version, last_schema FROM {STATE_TABLE} WHERE sync_name = ? ORDER BY last_commit_version DESC",
                    [sync_name],
                ).fetchall(),
            )
        return [
            (int(cast("int", v)) if v is not None else None, cast("str | None", s))
            for v, s in rows
        ]

    def rows_for_source(self, source_fqn: str) -> list[tuple[str, str | None]]:
        # A file pre-dating the guard has no source_fqn column and is not migrated (disposable,
        # single-writer): delete the file and let the next run recreate it.
        with self._connect() as con:
            rows = cast(
                "list[tuple[object, ...]]",
                con.execute(
                    f"SELECT sync_name, label FROM {STATE_TABLE} WHERE source_fqn = ?",
                    [source_fqn],
                ).fetchall(),
            )
        return [(str(name), cast("str | None", label)) for name, label in rows]

    def write(
        self,
        sync_name: str,
        version: int,
        last_schema: str | None,
        *,
        source_fqn: str | None = None,
        label: str | None = None,
    ) -> None:
        with self._connect() as con:
            _ = con.execute(
                f"INSERT INTO {STATE_TABLE} (sync_name, last_commit_version, last_schema, source_fqn, label) VALUES (?, ?, ?, ?, ?)",
                [sync_name, version, last_schema, source_fqn, label],
            )

    def clear(self, sync_name: str) -> str:
        with self._connect() as con:
            _ = con.execute(
                f"DELETE FROM {STATE_TABLE} WHERE sync_name = ?", [sync_name]
            )
        return f"Cleared {sync_name}'s watermark rows from {self.path} (other syncs' watermarks untouched)"


def delta_state_ddl(table_fqn: str) -> str:
    """The UC state table's DDL — one warehouse statement per environment (the deployment's
    one-time setup; the sync's own path never touches compute), and what the delta backend's
    failure carries so a team can create the table from the message alone.

    Both Databricks default-on table features are disabled: delta-rs (the sync's reader and
    writer) can neither read a table whose protocol carries the deletionVectors reader feature
    nor write one carrying RowTracking/DomainMetadata. An empty state table needs neither, ever
    (verified live: both defaults produced a table delta-rs refused)."""
    return f"""CREATE TABLE {table_fqn} (
    sync_name STRING NOT NULL,
    last_commit_version BIGINT NOT NULL,
    last_schema STRING,
    source_fqn STRING,
    label STRING,
    updated_at TIMESTAMP
)
TBLPROPERTIES (
    'delta.enableDeletionVectors' = false,
    'delta.enableRowTracking' = false
)"""


# The Delta state table's columns — the same six the SQL backends keep, in Delta types.
DELTA_STATE_COLUMNS: tuple[tuple[str, str], ...] = (
    ("sync_name", "string"),
    ("last_commit_version", "long"),
    ("last_schema", "string"),
    ("source_fqn", "string"),
    ("label", "string"),
    ("updated_at", "timestamp"),
)


def _delta_state_arrow_schema():
    """The state table's pyarrow schema (lazy: a Postgres-state sync never pays the import)."""
    import pyarrow as pa

    types = {
        "string": pa.string(),
        "long": pa.int64(),
        "timestamp": pa.timestamp("us", tz="UTC"),
    }
    return pa.schema([(name, types[kind]) for name, kind in DELTA_STATE_COLUMNS])


@final
class DeltaSyncState:
    """The watermark in a Delta table resolved from its UC name (build_sync_state does the
    lookup; this class holds the storage location it resolves to). Keyed by sync_name exactly
    like the Postgres backend; writes append, and every read opens a FRESH DeltaTable so a run
    reads its own write. The table is the deployment's one-time setup: require() is check-only,
    and create() initializes the Delta log of a registered-but-empty table."""

    def __init__(
        self, location: str, storage_options: dict[str, str] | None = None
    ) -> None:
        self.location, self.storage_options = location, storage_options or {}

    def _open(self):
        # A fresh DeltaTable per call: the read must see the write from moments before
        # (read-your-write), which a cached snapshot would not guarantee.
        from deltalake import DeltaTable

        return DeltaTable(self.location, storage_options=self.storage_options)

    def require(self) -> None:
        from deltalake.exceptions import TableNotFoundError

        try:
            table = self._open()
        except TableNotFoundError as error:
            raise RuntimeError(
                f"The watermark state table is registered but has no Delta log at {self.location} -- initialize it once (DeltaSyncState(location).create(), or one CREATE TABLE on the warehouse) before running the sync."
            ) from error
        present = {str(field.name) for field in table.schema().fields}
        missing = sorted({name for name, _ in DELTA_STATE_COLUMNS} - present)
        if missing:
            raise RuntimeError(
                f"The watermark state table at {self.location} predates the watermark guard (missing column(s): {', '.join(missing)}). Recreate it: register the new table in UC, then point state_table/state_schema at it."
            )

    def read(self, sync_name: str) -> list[tuple[int | None, str | None]]:
        # The state table holds one row per run -- Python-side filtering over to_pylist()
        # is the typed path (the dataset bridge and pyarrow.compute are stubs swamps).
        rows = cast(
            "list[dict[str, object]]", self._open().to_pyarrow_table().to_pylist()
        )
        # Freshest first, the Postgres read's ORDER BY last_commit_version DESC.
        pairs = [
            (
                cast("int | None", row.get("last_commit_version")),
                cast("str | None", row.get("last_schema")),
            )
            for row in rows
            if row.get("sync_name") == sync_name
        ]
        pairs.sort(
            key=lambda pair: pair[0] if pair[0] is not None else -1, reverse=True
        )
        return pairs

    def rows_for_source(self, source_fqn: str) -> list[tuple[str, str | None]]:
        rows = cast(
            "list[dict[str, object]]", self._open().to_pyarrow_table().to_pylist()
        )
        # A row written without a source (NULL) never matches an equality filter, like SQL NULL.
        return [
            (
                str(cast("object", row.get("sync_name"))),
                cast("str | None", row.get("label")),
            )
            for row in rows
            if row.get("source_fqn") == source_fqn
        ]

    def write(
        self,
        sync_name: str,
        version: int,
        last_schema: str | None,
        *,
        source_fqn: str | None = None,
        label: str | None = None,
    ) -> None:
        import pyarrow as pa
        from deltalake import write_deltalake

        row = pa.Table.from_pylist(
            [
                {
                    "sync_name": sync_name,
                    "last_commit_version": version,
                    "last_schema": last_schema,
                    "source_fqn": source_fqn,
                    "label": label,
                    "updated_at": datetime.datetime.now(datetime.UTC),
                }
            ],
            schema=_delta_state_arrow_schema(),
        )
        write_deltalake(
            self.location, row, mode="append", storage_options=self.storage_options
        )

    def create(self) -> None:
        """Initialize the Delta log of a registered-but-empty state table (the host setup's
        equivalent of running the DDL). Idempotent: an existing log is overwritten with the
        empty schema — the watermark rows, if any, do not survive, so this is setup-only."""
        import pyarrow as pa
        from deltalake import write_deltalake

        empty = pa.Table.from_pylist([], schema=_delta_state_arrow_schema())
        write_deltalake(
            self.location, empty, mode="overwrite", storage_options=self.storage_options
        )

    def clear(self, sync_name: str) -> str:
        from deltalake.exceptions import TableNotFoundError

        try:
            table = self._open()
        except TableNotFoundError:
            return f"{self.location} has no Delta log — nothing to clear"
        # Delta DELETE appends a tombstone commit: the store is shared, so only this sync's
        # rows go; the operation is one more commit, never a table drop.
        _ = table.delete(f"sync_name = '{sync_name.replace(chr(39), chr(39) * 2)}'")
        return f"Cleared {sync_name}'s watermark rows from the state table at {self.location} (other syncs' watermarks untouched)"


def build_sync_state(
    cfg: CdfSyncConfig,
    postgres: Connectable | None = None,
    databricks: DatabricksApi | None = None,
) -> SyncState:
    """The state backend the config chose. Postgres needs the postgres connectable; DuckDB needs
    only its file path; Delta needs the Databricks API for the UC lookup — a duckdb-state sync
    never requires the postgres connection, and none of the three binds a Dagster resource."""
    if cfg.state_backend == "duckdb":
        return DuckDBSyncState(cfg.state_path)
    if cfg.state_backend == "delta":
        if databricks is None:
            raise ValueError(
                "the delta state backend needs the Databricks API (the UC lookup)"
            )
        try:
            location = databricks.table_location_cached(
                databricks.cached_token(), cfg.state_fqn
            )
        except Exception as error:
            raise RuntimeError(
                f"The watermark state table {cfg.state_fqn} does not exist -- create it before running the sync (one warehouse statement, then re-run):\n{delta_state_ddl(cfg.state_fqn)}"
            ) from error
        # Local paths (the tests' tmp stand-ins) carry no storage options; abfss does.
        options = azure_storage_options(location) if "abfss://" in location else None
        return DeltaSyncState(location, options)
    if postgres is None:
        raise ValueError("the postgres state backend needs the postgres connection")
    return PostgresSyncState(postgres, cfg.state_table)
