"""The sync asset: one Dagster asset that moves a Delta table's changes to a Kafka topic
for zero Databricks compute.

Everything here is orchestration of the library's own parts: the delta-rs engine
(core/delta_reader.py) reads, the state backends (core/state.py) hold the watermark,
the wire module (core/wire.py) envelopes, the env contract (core/connections.py)
connects. The asset declares no Dagster resources — its connections come from env-fed
functions, so the same defs.yaml deploys to staging and production with nothing for a
team to bind.

Replay safety is the contract this module is shaped around: the watermark is appended
only AFTER the final Kafka flush succeeded, so a failed run moves nothing and the next
run replays the same versions — consumers upsert by key, which makes the replay safe.
"""

import json
import os
import threading
import time
from collections.abc import Callable
from typing import Protocol, cast

from confluent_kafka import Producer
from confluent_kafka.schema_registry import SchemaRegistryClient
from dagster import AssetExecutionContext, AssetKey, MetadataValue, asset

from ...core import connections
from ...core.delta_reader import (
    get_column_ids,
    get_current_version,
    get_earliest_available_version,
    get_row_fields,
    read_changes,
)
from ...core.state import SyncState, build_sync_state
from ...core.wire import (
    COMMIT_VERSION_COLUMN,
    DebeziumEvent,
    RowField,
    avro_payloads,
    avro_serializers,
    build_avro_message,
    build_connect_json_message,
    last_schema_json,
    summarize_ops,
    to_debezium_events,
)
from .config import CdfSyncConfig

type CdfRow = dict[str, object]

MESSAGE_PREVIEW_LIMIT = 50
RAW_MESSAGE_LIMIT = 3

# How many commit versions one read-and-produce chunk covers: a backlog of many
# commits streams through the driver instead of collecting every row up front. A
# single huge commit still arrives as one chunk — that is the memory ceiling, and
# it is comfortable to ~100k rows on the 512m driver.
_CDF_CHUNK_VERSIONS = int(os.environ.get("REVERSE_ETL_CDF_CHUNK_VERSIONS", "10"))


def _workspace_url() -> str:
    """The Databricks workspace URL the sync's control plane talks to (UC storage
    locations); the data plane never sees it — delta-rs reads ADLS directly."""
    url = os.environ.get("DATABRICKS_HOST", "")
    if not url:
        raise ValueError(
            "DATABRICKS_HOST is required (the workspace URL the sync's control plane reads)"
        )
    return url


def _resolve_backfill_version() -> int | None:
    """Explicit first-run override, e.g. to force starting from the exact
    version CDF was enabled at even though earlier history has already aged
    out of retention. Takes precedence over the automatic
    get_earliest_available_version()-based decision in the sync asset."""
    value = os.environ.get("REVERSE_ETL_BACKFILL_FROM_VERSION")
    return int(value) if value else None


def precheck_versions(
    state: SyncState, cfg: CdfSyncConfig, source_location: str
) -> tuple[int | None, int, str | None]:
    """(watermark, source's current version, the state row's last_schema) without
    any warehouse compute: the source's version via a delta-rs log read, the
    watermark via the state backend (core/state.py).

    Powers the sync's no-op pre-check: when the source's version equals
    the watermark there is nothing to sync — a schema change is always a commit,
    so an unchanged version cannot hide one. Only the log is read for the source.
    The state used to be a Delta table next to the source (full-snapshot scans,
    plain-Delta/protocol constraints, a metered SQL write) — it moved to Postgres,
    which deleted all of that along with the sync's last warehouse touch. The
    last_schema rides along so the full path can reuse all three values instead
    of re-reading them. Raises on any problem; the caller fails open to the full
    sync. The deltalake import is module-level (in core.delta_reader):
    importing it lazily would add ~1.5s to every run's measured window."""
    current_version = get_current_version(source_location)
    rows = state.read(cfg.sync_name)
    if not rows:
        return None, current_version, None
    version, last_schema = rows[
        0
    ]  # freshest row wins (ORDER BY last_commit_version DESC)
    return version, current_version, last_schema


def _read_state(state: SyncState, cfg: CdfSyncConfig) -> tuple[int | None, str | None]:
    """(watermark, last_schema) for this sync's state row. last_schema is the JSON
    list of source column names recorded at the previous sync — the evidence the
    drop-propagation pass needs (a column in last_schema but absent from the
    current read is a drop, not a partial read)."""
    rows = state.read(cfg.sync_name)
    if not rows:
        return None, None
    version, last_schema = rows[0]
    return version, last_schema


def _write_state(
    state: SyncState, cfg: CdfSyncConfig, version: int, last_schema: str
) -> None:
    # Append-only: read takes the freshest row for the sync_name, so history accumulates
    # harmlessly and the write is a cheap single-statement insert. The source and label ride
    # along as the watermark guard's stable anchor (core/state.py): both sync_name and label
    # move on a rename, the source table does not.
    state.write(
        cfg.sync_name, version, last_schema, source_fqn=cfg.source_fqn, label=cfg.label
    )


def _require_topic(kafka: connections.KafkaClients, topic: str) -> None:
    """The topic is the team's to create (D5): the core checks it and fails fast if it is
    absent. It never creates one — the component's topic asset runs before the sync."""
    topics = cast(
        "dict[str, object]", kafka.admin_client().list_topics(timeout=15).topics
    )
    if topic not in topics:
        raise RuntimeError(
            f"Kafka topic {topic!r} does not exist -- create it before running the sync"
        )


def check_watermark_identity(state: SyncState, cfg: CdfSyncConfig, log: object) -> None:
    """The watermark guard (the release design): a derived sync_name that lost its watermark must
    not silently restart the sync from the source's current version. When read() comes back
    empty, the run looks up rows for the same source_fqn:

    - this sync_name derived, prior rows also derived-named -> the rename error (a label was
      renamed, or an override typo minted a new identity);
    - this sync_name derived, prior rows explicitly named -> the collision error (a deliberate
      sync already watermarks this source);
    - this sync_name explicitly pinned -> warn and proceed (a deliberate identity: a pinned
      rename, or a legitimate second sync on one table);
    - no prior rows -> genuinely fresh, proceed.

    Legacy rows (NULL source_fqn) match nothing and are repopulated by the next write."""
    if state.read(cfg.sync_name):
        return  # this key has a watermark — genuinely continuing
    others = state.rows_for_source(cfg.source_fqn)
    if not others:
        return  # genuinely fresh
    described = ", ".join(
        f"sync_name='{name}' (label {label})" for name, label in others
    )
    if cfg.sync_name_explicit:
        log.warning(  # pyright: ignore[reportAttributeAccessIssue, reportUnknownMemberType] -- the caller passes a Dagster logger
            f"Watermark(s) exist for {cfg.source_fqn} under {described} — this sync's sync_name='{cfg.sync_name}' is explicitly pinned, so it starts fresh."
        )
        return
    # A stored row is derived-named when it matches the derivation formula over its own label:
    # that reproduces at read time whether the write's sync_name was minted or pinned.
    renamed = [
        (name, label)
        for name, label in others
        if label is not None and name == f"reverse_etl_{label}"
    ]
    if renamed:
        name, label = renamed[0]
        raise RuntimeError(
            f"A watermark exists for {cfg.source_fqn} under sync_name='{name}' (label '{label}'), but this instance derives sync_name='{cfg.sync_name}' — the label was renamed. Pin sync_name in the YAML to keep the watermark, or delete the old rows to start fresh."
        )
    name, label = others[0]
    raise RuntimeError(
        f"A deliberate sync (sync_name='{name}', label '{label}') already watermarks {cfg.source_fqn}, but this instance derives sync_name='{cfg.sync_name}' — this derived name collides with a deliberate sync; set sync_name explicitly."
    )


def _version_chunks(start: int, end: int, size: int) -> list[tuple[int, int]]:
    """Inclusive version sub-ranges covering [start, end], `size` versions each.

    The sync reads and produces one chunk at a time so a backlog of many commits
    streams through the driver instead of collecting every row up front. A single
    huge commit still arrives as one chunk — that is the memory ceiling, and it
    is comfortable to ~100k rows on the 512m driver."""
    if end < start:
        return []
    return [
        (version, min(version + size - 1, end))
        for version in range(start, end + 1, size)
    ]


def _split_at_schema_changes(
    chunks: list[tuple[int, int]], schema_at: Callable[[int], list[RowField]]
) -> list[tuple[int, int]]:
    """Split every chunk whose columns differ between its first and last version, so each chunk has one schema.

    A chunk spanning versions is read and enveloped with the schema of its top version: a row written before a
    rename in the same chunk would be produced under the new name with its value dropped. `schema_at(version)` is
    the table's columns at that version; a chunk is bisected until both ends agree, which costs two schema reads per
    multi-version chunk and a few more only where a schema really changed. Single-version chunks need no check."""
    split: list[tuple[int, int]] = []

    def visit(first: int, last: int) -> None:
        if first == last or schema_at(first) == schema_at(last):
            split.append((first, last))
            return
        middle = (first + last) // 2
        visit(first, middle)
        visit(middle + 1, last)

    for first, last in chunks:
        visit(first, last)
    return split


def _next_watermark(rows: list[CdfRow], current_version: int | None) -> int | None:
    """Highest `_commit_version` observed this run, or current_version if no rows.

    The Statement Execution API's JSON response returns every column value as
    a string regardless of its SQL type (confirmed directly against this
    workspace's responses) -- cast explicitly rather than relying on `max()`
    over strings, which would sort lexicographically instead of numerically.
    (The delta-rs reader returns ints; the cast discipline costs nothing and
    documents why max() must never run over raw values.)"""
    versions = [
        int(cast("int", row[COMMIT_VERSION_COLUMN]))
        for row in rows
        if row.get(COMMIT_VERSION_COLUMN) is not None
    ]
    if not versions:
        return current_version
    return max(versions)


class SyncHooks(Protocol):
    """The sync's extension points, called by the sync asset at two fixed points. A
    deployment whose downstream needs care the core does not provide (e.g. adding a
    column to a downstream table before the first message that uses it) passes hooks;
    a sync run without hooks touches only Databricks storage, Kafka and the state
    table — that is the reusable component's behaviour.

    Ordering contract:

    - `before_produce` runs once per EVENT-BEARING chunk, after the chunk's schema is resolved and
      before any of its messages are produced — a downstream column must exist before the first
      message that uses it.
    - `after_delivery` runs once, after the final Kafka flush SUCCEEDED and before the watermark is
      written — a failing hook fails the run before the watermark moves, so the next run repeats it.
      Every hook operation must be idempotent, because that replay re-runs it.
    - Neither hook is called on a run that produces nothing; such a run reports `idle_metadata()`.

    `before_produce` and `after_delivery` return metadata to add to the run: list values are merged
    across chunks (extended, order kept, duplicates dropped), any other value overwrites. Resources
    reach the hooks through the env-fed connection functions
    (core/connections.py)."""

    def before_produce(
        self,
        context: object,
        cfg: CdfSyncConfig,
        row_fields: list[RowField],
    ) -> dict[str, object]: ...

    def after_delivery(
        self,
        context: object,
        cfg: CdfSyncConfig,
        schema: dict[str, object],
    ) -> dict[str, object]: ...

    def idle_metadata(self) -> dict[str, object]: ...


def _merge_hook_metadata(
    into: dict[str, object], extra: dict[str, object]
) -> dict[str, object]:
    """Merge one hook call's metadata into the run's: lists extend (dedup, order kept), the rest overwrite."""
    for key, value in extra.items():
        if isinstance(value, list):
            items = cast("list[object]", value)
            merged = cast("list[object]", into.setdefault(key, []))
            for item in items:
                if item not in merged:
                    merged.append(item)
        else:
            into[key] = value
    return into


def _message_previews(
    cfg: CdfSyncConfig,
    events: list[DebeziumEvent],
    key_columns: list[str],
    row_fields: list[RowField],
    limit: int = MESSAGE_PREVIEW_LIMIT,
) -> list[dict[str, object]]:
    """The (key, value) pairs actually sent to Kafka for the first `limit`
    events, so the run's materialization metadata can show real produced
    messages rather than just op counts. Only each message's `payload` is
    shown: the embedded schema repeats on every message and would drown it."""
    previews: list[dict[str, object]] = []
    for event in events[:limit]:
        if cfg.encoding == "avro":
            key_payload, value_payload = avro_payloads(event, key_columns, row_fields)
            previews.append({"key": key_payload, "value": value_payload})
            continue
        key, value = build_connect_json_message(cfg, event, key_columns, row_fields)
        previews.append(
            {
                "key": cast("dict[str, object]", json.loads(key))["payload"],
                "value": cast("dict[str, object]", json.loads(value))["payload"],
            }
        )
    return previews


def _raw_messages(
    registry_client: SchemaRegistryClient,
    cfg: CdfSyncConfig,
    events: list[DebeziumEvent],
    key_columns: list[str],
    row_fields: list[RowField],
    limit: int = RAW_MESSAGE_LIMIT,
) -> list[dict[str, object]]:
    """The first `limit` messages exactly as sent to Kafka, embedded
    `schema` included (_message_previews shows payloads only). Avro messages are shown as hex: the
    Confluent wire format, a zero byte and the 4-byte schema id before the Avro payload."""
    raw: list[dict[str, object]] = []
    serializers = (
        avro_serializers(cfg, key_columns, row_fields, registry_client)
        if cfg.encoding == "avro" and events
        else None
    )
    for event in events[:limit]:
        if serializers:
            key, value = build_avro_message(
                cfg, event, key_columns, row_fields, serializers
            )
            raw.append({"key_hex": key.hex(), "value_hex": value.hex()})
            continue
        key, value = build_connect_json_message(cfg, event, key_columns, row_fields)
        raw.append(
            {
                "key": cast("dict[str, object]", json.loads(key)),
                "value": cast("dict[str, object]", json.loads(value)),
            }
        )
    return raw


def _produce_to_kafka(
    producer: Producer,
    registry_client: SchemaRegistryClient,
    cfg: CdfSyncConfig,
    events: list[DebeziumEvent],
    key_columns: list[str],
    row_fields: list[RowField],
    flush: bool = True,
) -> list[str]:
    """Serialize + enqueue the events. Returns the delivery-error strings collected
    while enqueueing (the callbacks fire during flush()). With flush=False the
    caller owns the final wait — see _flush_producer."""
    # produce() is async (it only enqueues); delivery failures surface later in
    # librdkafka's background threads. Collect them per message via on_delivery
    # and fail the run on the flush -- BEFORE the watermark append that follows
    # -- so the next sync replays from the same version instead of silently
    # skipping events that never reached the topic (broker blip, rotated SASL
    # credentials, recreated topic). Duplicate replays are harmless: consumers
    # upsert by key.
    serializers = (
        avro_serializers(cfg, key_columns, row_fields, registry_client)
        if cfg.encoding == "avro"
        else None
    )
    delivery_errors: list[str] = []
    for event in events:
        if serializers:
            key, value = build_avro_message(
                cfg, event, key_columns, row_fields, serializers
            )
        else:
            key, value = build_connect_json_message(cfg, event, key_columns, row_fields)
        # Enqueuing outruns the wire: once librdkafka's queue ceiling is reached
        # (queue.buffering.max.messages = 500k -- above any 100k-row sync but
        # below a 1M-row one) produce() raises BufferError. Serve the delivery
        # callbacks with poll() to free queue space and retry, so a volume sync
        # backpressures on the broker instead of dying at the ceiling. Bounded
        # like the flush below: a wedged broker must fail the run, not hang it.
        queue_full_deadline = time.monotonic() + 120
        while True:
            try:
                _ = producer.produce(
                    topic=cfg.kafka_topic,
                    key=key,
                    value=value,
                    on_delivery=lambda err, msg: (
                        delivery_errors.append(str(err)) if err is not None else None
                    ),
                )
                break
            except BufferError:
                if time.monotonic() > queue_full_deadline:
                    raise RuntimeError(
                        f"Kafka producer queue stayed full for 120s (topic {cfg.kafka_topic})"
                    ) from None
                _ = producer.poll(0.1)
    # Bounded wait, mirroring the connections' connect_timeout: a wedged broker
    # must fail the run, not hang it. flush() returns the number of messages
    # still undelivered (their delivery callbacks have not fired).
    if flush:
        _flush_producer(cfg, producer, delivery_errors)
    return delivery_errors


def _flush_producer(
    cfg: CdfSyncConfig, producer: Producer, delivery_errors: list[str]
) -> None:
    """Wait for every enqueued message's delivery callback, then fail on the errors
    collected (the run's single delivery checkpoint)."""
    undelivered = producer.flush(30)
    if undelivered or delivery_errors:
        raise RuntimeError(
            f"Kafka delivery failed for {cfg.kafka_topic}: {undelivered} undelivered, errors: {delivery_errors[:3]}"
        )


def build_sync_asset(
    cfg: CdfSyncConfig,
    hooks: SyncHooks | None = None,
    deps: tuple[AssetKey, ...] = (),
):
    """The sync asset: delta-rs version-range reconstruction (see
    core/delta_reader.py) -- no CDF read, no Spark, no warehouse anything:
    reads are delta-rs and the watermark state lives in the backend the config chose
    (core/state.py). The asset declares no Dagster resources (the env
    contract, core/connections.py): its connections come from env-fed
    functions — databricks/kafka/registry always, the state Postgres when the
    backend is postgres (a DuckDB state file needs nothing but its path; a Delta
    state table reuses the databricks API's UC lookup). The
    asset writes to Kafka and its state, and nothing else. The Kafka
    topic and the state table must already exist: both are checked before anything
    else runs, and a missing one fails with what to create (D1, D5) — the core
    never creates either.

    `hooks` adds downstream care at the two points documented on SyncHooks — the hooks
    reach their connections through the same env-fed functions.
    `deps` declares upstream assets (a deployment wires its table-setup and topic
    assets in; the bare core declares none)."""

    @asset(
        name=cfg.sync_asset,
        key_prefix=list(cfg.asset_key_prefix) or None,
        group_name=cfg.group_name,
        deps=list(deps) or None,
        # No required_resource_keys (the env contract): the connections come from
        # the env-fed functions in core/connections.py, so the same defs.yaml deploys
        # to staging and production with nothing for a team to bind.
        description=(
            f"Batch-read new/changed/deleted rows from {cfg.source_fqn}'s Change "
            "Data Feed since the last watermark (delta-rs version-range "
            "reconstruction -- no CDF read, no Spark, no warehouse scans), and "
            "produce them as Debezium-style events — no Databricks compute, no DBUs."
        ),
    )
    def cdf_to_kafka(context: AssetExecutionContext):
        databricks, kafka = (
            connections.databricks(_workspace_url()),
            connections.kafka(),
        )
        state: SyncState = build_sync_state(
            cfg,
            connections.state_postgres() if cfg.state_backend == "postgres" else None,
            databricks,
        )
        # The topic and the state store are the team's to provide (D1, D5): both are checked
        # before anything else runs. Neither is ever created here -- except the DuckDB file,
        # which is local and appears on first run (D15).
        _require_topic(kafka, cfg.kafka_topic)
        state.require()
        # The rename guard, before anything reads the source: an empty watermark for this
        # sync's key must not mean a silent fresh start when the source already has one
        # under another key (check_watermark_identity's decision table).
        check_watermark_identity(state, cfg, context.log)
        registry_client = connections.registry().client(cfg.schema_registry_url)
        # The token is control-plane only here: it resolves the tables' storage
        # locations through the UC REST API. No SQL runs against a warehouse.
        # Both come from the disk cache when warm (see DatabricksApi.cached_token).
        databricks.require_env()
        token = databricks.cached_token()
        producer: Producer | None = None

        source_location = databricks.table_location_cached(token, cfg.source_fqn)

        # delta-rs no-op pre-check: read the source's current version and the
        # state table's watermark (no Spark, no warehouse) and end the run when
        # nothing moved — a schema change is always a commit, so an unchanged
        # version cannot hide one. This is the whole run for a no-op. Bounded by a 5s
        # watchdog, because a hung pre-check must not make a no-op slower than the
        # sync it would have saved, and fail-open on any error: the pre-check is
        # an optimization, never a gate.
        precheck: dict[str, object] = {}

        def _precheck() -> None:
            try:
                precheck["result"] = precheck_versions(state, cfg, source_location)
            except Exception as error:  # noqa: BLE001 — fail-open is the design
                precheck["error"] = error

        thread = threading.Thread(target=_precheck, daemon=True)
        thread.start()
        thread.join(5)
        if "error" in precheck:
            context.log.info(
                f"delta-rs pre-check unavailable ({type(precheck['error']).__name__}: {str(precheck['error'])[:120]}) — starting the full sync"
            )
        elif "result" not in precheck:
            context.log.info(
                "delta-rs pre-check did not return in 5s — starting the full sync"
            )
        else:
            last_version_pre, current_version_pre, _ = cast(
                "tuple[int | None, int, str | None]", precheck["result"]
            )
            if last_version_pre is not None and current_version_pre == last_version_pre:
                context.log.info(
                    f"No new commits since version {last_version_pre} for {cfg.sync_name} (delta-rs pre-check)"
                )
                context.add_output_metadata(
                    {
                        "events_synced": MetadataValue.int(0),
                        "op_counts": MetadataValue.json({}),
                        "last_commit_version": MetadataValue.int(last_version_pre),
                        "kafka_topic": MetadataValue.text(cfg.kafka_topic),
                        **(hooks.idle_metadata() if hooks else {}),
                        "kafka_messages": MetadataValue.json([]),
                        "kafka_messages_truncated": MetadataValue.bool(False),
                        "kafka_messages_raw": MetadataValue.json([]),
                        "extraction": MetadataValue.text("delta_rs"),
                        "databricks_compute": MetadataValue.text(
                            "none — delta-rs reads storage directly; the watermark state lives in Postgres"
                        ),
                    }
                )
                return

        if precheck.get("result") is not None:
            # The pre-check read the state row and the source version seconds
            # ago — re-reading both costs two snapshot loads for the same answer.
            last_version, current_version, last_schema = cast(
                "tuple[int | None, int, str | None]", precheck["result"]
            )
        else:
            # The pre-check failed (or hung): the state read is the only
            # fallback that does not repeat whatever broke the delta-rs read.
            last_version, last_schema = _read_state(state, cfg)
            current_version = None
        chunk_start: int | None = None

        if last_version is None:
            backfill_from = _resolve_backfill_version()
            if backfill_from is not None:
                context.log.info(
                    f"First run for {cfg.sync_name} -- backfilling {cfg.source_table} from explicit override version {backfill_from}"
                )
            else:
                earliest_available = get_earliest_available_version(source_location)
                if earliest_available == 0:
                    backfill_from = 0
                    context.log.info(
                        f"First run for {cfg.sync_name} -- {cfg.source_table}'s full history is intact (earliest available version is 0), backfilling from the beginning"
                    )
                else:
                    context.log.info(
                        f"First run for {cfg.sync_name} -- earliest available version is {earliest_available} (history already partially aged out of retention), baselining at {cfg.source_table}'s current version with no historical rows synced"
                    )

            if backfill_from is not None:
                # The Kafka TLS/SASL handshake runs in librdkafka's background
                # threads while the version-diff reads and event building run.
                producer = kafka.producer()
                chunk_start = backfill_from
                if current_version is None:
                    current_version = get_current_version(source_location)
        else:
            # The reconstruction reads every commit since the watermark, and
            # last_version was already fully processed -- +1 to resume from the
            # first un-synced version.
            next_version = last_version + 1
            if current_version is None:
                current_version = get_current_version(source_location)
            if next_version > current_version:
                # No commits since the last run -- the common case for a daily
                # batch once caught up. Checked before reading so a no-op stays
                # a no-op.
                context.log.info(
                    f"No new commits since version {last_version} for {cfg.sync_name}"
                )
            else:
                context.log.info(
                    f"Reading versions {next_version}-{current_version} of {cfg.source_table}"
                )
                # The Kafka TLS/SASL handshake runs in librdkafka's background
                # threads while the version-diff read runs. The read is pinned to
                # current_version so its range matches the watermark exactly.
                producer = kafka.producer()
                chunk_start = next_version

        key_columns = [cfg.key_column]
        events_synced = 0
        op_counts: dict[str, int] = {}
        preview_events: list[dict[str, object]] = []
        raw_preview_events: list[dict[str, object]] = []
        delivery_errors: list[str] = []
        hook_metadata: dict[str, object] = {}
        # The schema the last produced events were enveloped with, and its
        # version -- the propagation needs it to catch schema changes landing
        # inside the unsynced window AFTER the last data event (see below).
        event_row_fields: list[RowField] | None = None
        event_fields_version: int | None = None
        row_fields: list[RowField] = []
        new_version: int | None = None
        rows_seen = False

        if chunk_start is not None:
            # The producer and the current version are both resolved whenever a chunk was
            # queued (see the branches above that set chunk_start).
            assert producer is not None
            assert current_version is not None
            # Read and produce one version chunk at a time so a backlog of many
            # commits streams through the driver instead of collecting every row
            # up front (_version_chunks). A single huge commit still arrives as
            # one chunk -- that is the memory ceiling. No prefetch thread: it
            # measured 187s vs 126s on the 1M sync -- the reader thread's
            # collect->dict conversion and the main thread's events/serialization
            # are both GIL-bound, so they contend instead of overlapping. The
            # overlap that DOES pay is flush=False's: the broker transfers while
            # the next chunk's read runs (GIL-free there).
            chunks = _version_chunks(chunk_start, current_version, _CDF_CHUNK_VERSIONS)
            chunks = _split_at_schema_changes(
                chunks, lambda version: get_row_fields(source_location, version=version)
            )
            for index, (chunk_from, chunk_to) in enumerate(chunks):
                rows = read_changes(cfg, source_location, chunk_from, chunk_to)
                # The watermark advances for EVERY chunk -- including 0-row
                # schema-only ones -- because it must reach the pinned top.
                # Updating it only for row-bearing chunks stranded the
                # watermark on the last EVENT-bearing chunk: a RENAME
                # committing after the last data event in the same sync was
                # read (0 rows) but never watermarked, deferring its
                # propagation to the next sync (verified live 2026-10-19 --
                # Postgres kept the old column name after the rename demo).
                chunk_watermark = _next_watermark(rows, current_version)
                assert (
                    chunk_watermark is not None
                )  # current_version is pinned in this branch
                new_version = (
                    chunk_watermark
                    if new_version is None
                    else max(new_version, chunk_watermark)
                )
                if not rows:
                    continue
                rows_seen = True
                events = to_debezium_events(rows, key_columns)
                if events:
                    # Resolve the schema PER EVENT-BEARING CHUNK, pinned to the
                    # chunk's top version -- the same commit the data was read
                    # at -- and give the hooks their chance BEFORE any message
                    # is produced (a hook may add the column downstream, which
                    # only fills a column from messages read after the column
                    # exists). Set-once-and-reuse is wrong the moment the schema
                    # changes between chunks: later chunks' events would be
                    # enveloped with the FIRST chunk's column list, and the
                    # wire's row projection would silently drop every value
                    # under a column the first chunk predated (verified live
                    # 2026-10-19 -- with the seed backfill in the same sync, the
                    # populate's new-column value was lost exactly this way).
                    # A chunk spanning multiple versions pins to its top, which
                    # is why chunks are split at schema changes
                    # (_split_at_schema_changes): one schema per chunk.
                    row_fields = get_row_fields(source_location, version=chunk_to)
                    event_row_fields = row_fields
                    event_fields_version = chunk_to
                    if hooks is not None:
                        _ = _merge_hook_metadata(
                            hook_metadata,
                            hooks.before_produce(context, cfg, row_fields),
                        )
                    # flush=False: the broker transfers while the NEXT chunk's
                    # version-diff read runs; one bounded flush after the last
                    # chunk (below) is the single delivery checkpoint.
                    delivery_errors.extend(
                        _produce_to_kafka(
                            producer,
                            registry_client,
                            cfg,
                            events,
                            key_columns=key_columns,
                            row_fields=row_fields,
                            flush=False,
                        )
                    )
                    events_synced += len(events)
                    for op, count in summarize_ops(events).items():
                        op_counts[op] = op_counts.get(op, 0) + count
                    # The previews snapshot the events AS PRODUCED, with THIS
                    # chunk's schema -- re-projecting earlier chunks' events at
                    # metadata-build time with a later chunk's schema would
                    # show nulls for columns those events never carried.
                    if len(preview_events) < MESSAGE_PREVIEW_LIMIT:
                        preview_events += _message_previews(
                            cfg, events, key_columns, row_fields
                        )[: MESSAGE_PREVIEW_LIMIT - len(preview_events)]
                    if len(raw_preview_events) < RAW_MESSAGE_LIMIT:
                        raw_preview_events += _raw_messages(
                            registry_client, cfg, events, key_columns, row_fields
                        )[: RAW_MESSAGE_LIMIT - len(raw_preview_events)]
                # Per-chunk heartbeat: the pipeline is bursty by design (read
                # 100k -> build -> enqueue -> repeat), and without this line a
                # watching audience just sees the counts plateau every chunk.
                context.log.info(
                    f"Chunk {index + 1}/{len(chunks)}: versions {chunk_from}-{chunk_to}, {len(rows)} rows, {len(events)} events (total {events_synced})"
                )
            if events_synced:
                context.log.info(
                    f"Produced {events_synced} event(s) to {cfg.kafka_topic}: {op_counts}"
                )
            if events_synced:
                # The single delivery checkpoint for the whole backlog: fail
                # here -- BEFORE the watermark append below -- and the next
                # sync replays the same versions (consumers upsert by key).
                _flush_producer(cfg, producer, delivery_errors)

        if last_version is None and not rows_seen:
            if current_version is None:
                current_version = get_current_version(source_location)
            new_version = current_version
        elif not rows_seen:
            # No rows but the version advanced: schema-only commits (a DROP/ADD
            # COLUMN emits no row events) -- the watermark must still move,
            # otherwise the schema commit is re-read by every sync forever,
            # and drop propagation never fires.
            new_version = current_version

        # Skip the state write when the version is unchanged (no-op syncs):
        # writing the same version costs a full snapshot + commit for nothing.
        # A schema change is always a commit, so an unchanged version cannot
        # hide one.
        if new_version is not None and new_version != last_version:
            # The recorded schema is the table's FINAL schema -- the version the
            # watermark advances to -- against last_schema. The chunk loop's
            # row_fields are pinned to the last EVENT-bearing chunk and must
            # not leak here: a RENAME committing after the last data event in
            # the same sync would otherwise never leave that chunk's schema,
            # the diff would see no change, and the rename would never reach
            # the topic (verified live 2026-10-19: add + populate + rename in
            # one unsynced window left the value under the old column name in
            # Postgres). Reading the ids here unconditionally too keeps the
            # pair from the same commit -- the leak wrote state rows pairing
            # one commit's names with another's ids (id=None), which would
            # turn the next sync's diff into a bogus drop.
            row_fields = get_row_fields(source_location, version=current_version)
            column_ids = get_column_ids(source_location, version=current_version)
            if hooks is not None:
                # Here: AFTER the flush above succeeded, BEFORE the watermark
                # write below -- a failing hook fails the run before the
                # watermark moves, and the next run replays the same versions
                # and re-runs it (every hook operation is idempotent).
                _ = _merge_hook_metadata(
                    hook_metadata,
                    hooks.after_delivery(
                        context,
                        cfg,
                        {
                            "row_fields": row_fields,
                            "column_ids": column_ids,
                            "last_schema": last_schema,
                            "event_row_fields": event_row_fields,
                            "event_fields_version": event_fields_version,
                            "source_location": source_location,
                        },
                    ),
                )
            _write_state(
                state, cfg, new_version, last_schema_json(row_fields, column_ids)
            )

        context.add_output_metadata(
            {
                "events_synced": MetadataValue.int(events_synced),
                "op_counts": MetadataValue.json(op_counts),
                "last_commit_version": (
                    MetadataValue.int(new_version)
                    if new_version is not None
                    else MetadataValue.text("none")
                ),
                "kafka_topic": MetadataValue.text(cfg.kafka_topic),
                **hook_metadata,
                "kafka_messages": MetadataValue.json(preview_events),
                "kafka_messages_truncated": MetadataValue.bool(
                    events_synced > MESSAGE_PREVIEW_LIMIT
                ),
                "kafka_messages_raw": MetadataValue.json(raw_preview_events),
                "extraction": MetadataValue.text("delta_rs"),
                "databricks_compute": MetadataValue.text(
                    "none — delta-rs reads storage directly; the watermark state lives in Postgres"
                ),
            }
        )

    return cdf_to_kafka
