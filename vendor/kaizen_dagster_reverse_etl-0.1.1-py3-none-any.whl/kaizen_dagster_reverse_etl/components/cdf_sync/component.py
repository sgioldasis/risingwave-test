import dataclasses
from typing import override

import dagster as dg

from .config import CdfSyncConfig
from .naming import dagster_names
from .sync import build_sync_asset


class ReverseEtlCdfSync(dg.Component, dg.Model, dg.Resolvable):
    """One Databricks Delta table's changes, read and written to Kafka as Debezium-style events.

    The reusable reverse-ETL component: it builds exactly one Dagster asset, the sync, and
    creates no infrastructure. The sync reads an existing Delta table with delta-rs (no Spark,
    no Databricks compute), keeps its watermark in the state backend the config chose
    (core/state.py: the shared Postgres table, a local DuckDB file, or a UC-named Delta table),
    and produces Debezium-style events to an existing Kafka topic in Connect JSON or Confluent
    Avro.

    The topic and the state table are the deployment's to create, both checked before anything
    runs: a missing one fails the sync with what to create (the topic wants compaction --
    cleanup.policy=compact, a Debezium-style change topic's documented default). The sync asset
    touches only the postgres, databricks, kafka and registry connections (the env contract,
    core/connections.py). Schema changes downstream -- column adds, drop/rename propagation --
    are a consuming project's concern: this component runs without them.

    `name` is a short label deriving the default asset and group names, as
    reverse_etl_<name>_<...>, and -- unless overridden -- the watermark key and topic with it.
    The watermark key (`sync_name`) is the one name a replay silently depends on: changing it
    for an existing sync restarts that sync from the beginning, which is why the sync refuses
    to do that silently (the watermark guard) and why an explicit override exists.
    """

    name: str
    catalog: str
    schema_name: str
    # The existing table. The component never creates it.
    source_table: str
    # The column that identifies a row downstream. No default: a surrogate
    # key means nothing for a real table.
    key_column: str
    # The topic to produce to. Omitted, it derives as reverse_etl_<name>_topic.
    kafka_topic: str | None = None
    # The watermark key and the Debezium envelope prefix. Omitted, it derives as
    # reverse_etl_<name>, so the whole derived name family stays consistent by
    # construction. Given, it is verbatim: pin it to keep the watermark across a
    # label rename -- the sync refuses to restart silently on a rename (the guard).
    sync_name: str | None = None
    # The watermark state (core/state.py): "delta" (the default -- a UC-named Delta
    # table, `state_table` in `state_schema`/`state_catalog`, defaulting to the source's
    # schema; resolved per environment through the UC lookup; it must exist and be
    # registered, and the failure carries the CREATE TABLE), "postgres" (`state_table`,
    # the shared table, which must exist -- the sync fails with the DDL otherwise) or
    # "duckdb" (a local file at `state_path`, created on first run, needing no postgres
    # connection). The default is delta: no Postgres dependency, and the state lives
    # under the same governance as the source.
    state_backend: str = "delta"
    state_table: str | None = None
    state_path: str | None = None
    state_schema: str | None = None
    state_catalog: str | None = None

    # "json" (default: Kafka Connect JSON with the schema embedded in every message) or "avro"
    # (Confluent wire format, schemas in the registry under <topic>-key and <topic>-value).
    encoding: str | None = None
    schema_registry_url: str | None = None

    # Overrides for the derived Dagster names.
    group_name: str | None = None
    sync_asset: str | None = None

    # Dagster asset-key segments prepended to every asset key this component mints
    # (the databricks job orchestration component's asset_key_prefix), so the
    # location's assets nest under it in a multi-location catalog. External names
    # (topic, watermark key) and job names are never prefixed.
    asset_key_prefix: list[str] | None = None

    # Upstream asset keys, so a team can order the sync after its own pipeline's assets.
    # These are the team's own keys: never prefixed.
    deps: list[str] | None = None

    def to_config(self) -> CdfSyncConfig:
        derived = dagster_names(self.name)
        config = CdfSyncConfig(
            sync_name=self.sync_name or f"reverse_etl_{self.name}",
            catalog=self.catalog,
            schema=self.schema_name,
            source_table=self.source_table,
            key_column=self.key_column,
            kafka_topic=self.kafka_topic or f"reverse_etl_{self.name}_topic",
            group_name=derived["group_name"],
            sync_asset=derived["sync_asset"],
            label=self.name,
            sync_name_explicit=self.sync_name is not None,
            state_backend=self.state_backend,
        )
        # The state fields go into the first replace so the config validates the
        # real backend+path combination (duckdb without a path fails here, at load).
        state_fields: dict[str, object] = {
            field: getattr(self, field)
            for field in ("state_table", "state_path", "state_schema", "state_catalog")
            if getattr(self, field) is not None
        }
        overrides: dict[str, object] = {
            field: getattr(self, field)
            for field in (
                "encoding",
                "schema_registry_url",
                "group_name",
                "sync_asset",
                "asset_key_prefix",
            )
            if getattr(self, field) is not None
        }
        return dataclasses.replace(config, **{**state_fields, **overrides})

    @override
    def build_defs(self, context: dg.ComponentLoadContext) -> dg.Definitions:
        # The sync asset, and nothing else: the component creates no infrastructure.
        # The topic must already exist (compacted -- a Debezium-style change topic's
        # documented default); a missing one fails the sync with what to create.
        team_deps = tuple(dg.AssetKey(dep) for dep in self.deps or ())
        return dg.Definitions(
            assets=[build_sync_asset(self.to_config(), deps=team_deps)]
        )
