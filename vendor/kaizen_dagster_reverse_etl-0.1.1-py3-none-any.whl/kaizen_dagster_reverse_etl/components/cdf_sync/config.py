"""One reverse-ETL sync's resolved configuration — everything the sync asset needs, and nothing demo-shaped.

`CdfSyncConfig` is the frozen value the sync component turns a `defs.yaml`
instance into, and the sync's engine, state and wire modules take nothing else.
Keyword-only, so fields can carry defaults without ordering constraints.

No imports from the other library modules, so any of them can import this one.
"""

from dataclasses import dataclass

from .naming import validate_asset_key_prefix

# The registry URL is a config field with an org-specific default: everything
# env-adjacent that is *not* a credential stays in YAML or config.
SCHEMA_REGISTRY_URL = "http://staging-schema-registry.kaizengaming.net/apis/ccompat/v7"


def avro_key_subject(kafka_topic: str) -> str:
    """The registry subject for a topic's key schema."""
    return f"{kafka_topic}-key"


def avro_value_subject(kafka_topic: str) -> str:
    """The registry subject for a topic's value schema."""
    return f"{kafka_topic}-value"


@dataclass(frozen=True, kw_only=True)
class CdfSyncConfig:
    # --- what is synced -------------------------------------------------------
    sync_name: str
    catalog: str
    schema: str
    # The existing table. The sync never creates or alters it.
    source_table: str
    # Surrogate key: identifies a row downstream. One column — see the component's Limits.
    key_column: str
    # The single topic the sync produces to and every consumer reads.
    kafka_topic: str

    # --- identity (the naming policy) ------------------------------------------
    # The YAML label every derived name comes from, and whether the watermark key was
    # pinned or derived. The watermark guard reads the latter: a label rename moves a
    # derived sync_name, a pinned one survives it.
    label: str
    sync_name_explicit: bool

    # --- the Dagster definitions built for it ----------------------------------
    group_name: str
    sync_asset: str
    # Dagster asset-key segments prepended to every asset key this component mints
    # (the databricks job orchestration component's asset_key_prefix), so a
    # location's assets nest under the location in a multi-location catalog. It
    # never touches the external names (topic, watermark key) or the job names.
    # The sync's own `deps` are team asset keys and are not prefixed.
    asset_key_prefix: tuple[str, ...] = ()

    # --- the watermark state (core/state.py) ------------------------------------
    # "delta" (default): a UC-named Delta table (`state_table` in
    # `state_schema`/`state_catalog`), resolved to storage through the same cached UC
    # lookup the source uses, so the YAML stays environment-neutral; it must exist and
    # be registered -- the failure carries the CREATE TABLE. Reads/writes are delta-rs
    # over storage: no compute, and no Postgres dependency at all.
    # "postgres": the shared table `state_table` (keyed by sync_name), which must exist
    # -- the sync's precondition fails with the DDL when it is absent.
    # "duckdb": a local file at `state_path`, one sync per file (DuckDB allows one
    # writer), created on first run.
    # The watermark semantics are identical all three ways: append-only,
    # freshest-row-wins.
    state_backend: str = "delta"
    state_table: str = "reverse_etl_sync_state"
    state_path: str = ""
    # The delta backend's UC coordinates; empty inherits the source's schema/catalog.
    state_schema: str = ""
    state_catalog: str = ""

    # --- message encoding ------------------------------------------------------
    # "json": Kafka Connect JSON with the schema embedded in every message (the default).
    # "avro": Confluent wire format, schemas in the registry under <topic>-key and <topic>-value.
    encoding: str = "json"
    schema_registry_url: str = SCHEMA_REGISTRY_URL

    def __post_init__(self) -> None:
        object.__setattr__(
            self, "asset_key_prefix", validate_asset_key_prefix(self.asset_key_prefix)
        )
        if self.encoding not in ("json", "avro"):
            raise ValueError(
                f"encoding must be 'json' or 'avro', got {self.encoding!r}"
            )
        if self.state_backend not in ("postgres", "duckdb", "delta"):
            raise ValueError(
                f"state_backend must be 'postgres', 'duckdb' or 'delta', got {self.state_backend!r}"
            )
        if self.state_backend == "duckdb" and not self.state_path:
            raise ValueError("state_path is required for the duckdb state backend")

    @property
    def key_subject(self) -> str:
        return avro_key_subject(self.kafka_topic)

    @property
    def value_subject(self) -> str:
        return avro_value_subject(self.kafka_topic)

    @property
    def source_fqn(self) -> str:
        return f"{self.catalog}.{self.schema}.{self.source_table}"

    @property
    def state_fqn(self) -> str:
        """The state table's UC name — the source's schema/catalog unless overridden."""
        return f"{self.state_catalog or self.catalog}.{self.state_schema or self.schema}.{self.state_table}"

    @property
    def envelope_schema_name(self) -> str:
        # Debezium's `<server>.<schema>.<table>` convention, which is what lets a
        # consumer recognise a Debezium event.
        return f"{self.sync_name}.{self.schema}.{self.source_table}"
