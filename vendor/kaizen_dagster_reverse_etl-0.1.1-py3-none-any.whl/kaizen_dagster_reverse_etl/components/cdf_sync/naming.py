"""The Dagster-side names a sync's `name` label mints.

The naming policy (the release design): minted names are derived, owned names
are typed. Everything `reverse_etl_<label>[_<role>]` comes from this module's
one formula, so every consumer of the sync's names derives byte-identical
values by arithmetic, not discipline. Every derived field keeps an explicit
override on the config that owns it — the override exists for migrations, and
typing a minted name is how typos mint accidental identities.
"""

from typing import cast


def dagster_names(label: str) -> dict[str, str]:
    """The Dagster object names for a sync labelled `label`, as
    reverse_etl_<label>[_<role>]: the asset group and the sync asset's name.
    The infrastructure names are never derived — they are explicit in the
    YAML."""
    base = f"reverse_etl_{label}"
    return {
        "group_name": base,
        "sync_asset": f"{base}_to_kafka",
    }


def validate_asset_key_prefix(prefix: object) -> tuple[str, ...]:
    """Normalize an asset_key_prefix to a tuple of segments, validating each.

    The Dagster-side key prefix (the databricks job orchestration component's
    `asset_key_prefix`): segments prepended to every asset key this component
    mints, so a location's assets nest under the location in a multi-location
    catalog. It never touches the external names (topic, watermark key)."""
    if prefix is None:
        return ()
    raw: list[object]
    if isinstance(prefix, str):
        raw = [prefix]
    elif isinstance(prefix, (list, tuple)):
        raw = list(cast("list[object]", prefix))
    else:
        raise TypeError(
            f"asset_key_prefix must be a string or a list of strings, got {prefix!r}"
        )
    segments: list[str] = []
    for segment in raw:
        if not isinstance(segment, str) or not segment.strip():
            raise ValueError(
                f"asset_key_prefix segments must be non-empty strings, got {segment!r}"
            )
        if "/" in segment:
            # AssetKey(["p", "a/b"]).to_user_string() is "p/a/b", which parses
            # back as three segments: a slash here would not round-trip
            # through a Dagster asset key.
            raise ValueError(
                f"asset_key_prefix segments must not contain '/', got {segment!r}"
            )
        segments.append(segment)
    return tuple(segments)
