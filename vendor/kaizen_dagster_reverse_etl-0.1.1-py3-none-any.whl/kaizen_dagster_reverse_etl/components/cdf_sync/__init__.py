"""The sync component: Delta change capture to Kafka, zero DBUs."""
