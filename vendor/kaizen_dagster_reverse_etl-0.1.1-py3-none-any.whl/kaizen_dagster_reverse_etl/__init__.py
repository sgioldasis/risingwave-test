"""Batch reverse ETL for Kaizen teams: a Delta table's changes to Kafka, zero Databricks compute."""
