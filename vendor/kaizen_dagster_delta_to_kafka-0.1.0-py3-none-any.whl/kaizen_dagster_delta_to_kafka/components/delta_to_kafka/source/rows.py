"""The query's rows: the YAML's query, run verbatim on the instance's serverless SQL
warehouse through the Statement Execution API and handed on chunk by chunk as Arrow record
batches. Nothing else reads data -- no table is resolved to a storage location and no
storage is accessed.

`StatementExecutionSource` is the pipeline's `RowSource` for it: `statement_execution`
runs the statement and fetches its chunks, `arrow_conversion` reads each chunk.
"""

from collections.abc import Callable, Iterator

import pyarrow as pa
from dagster import DagsterLogManager
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import StatementResponse

from ..core.interfaces import RowStream
from .arrow_conversion import record_batch, schema_of
from .authentication import Credentials
from .statement_execution import iter_chunks, run_statement


class StatementExecutionSource:
    """Runs one query on one warehouse and streams its rows. The workspace client is
    opened by `client_factory` when the read starts, not when the source is built, so a
    dry run of a misconfigured instance fails where the read happens."""

    def __init__(
        self,
        *,
        host: str,
        credentials: Credentials,
        warehouse: str,
        query: str,
        client_factory: Callable[[str, Credentials], WorkspaceClient],
        log: DagsterLogManager | None = None,
    ) -> None:
        self._host: str = host
        self._credentials: Credentials = credentials
        self._warehouse: str = warehouse
        self._query: str = query
        self._client_factory: Callable[[str, Credentials], WorkspaceClient] = (
            client_factory
        )
        self._log: DagsterLogManager | None = log

    def read(self) -> RowStream:
        """Run the statement to completion and return its schema and a lazy iterator of
        its rows (one record batch per result chunk), plus the run metadata the statement
        adds (the warehouse and how long the statement took). The first chunk arrives with
        the statement; the others are fetched as the iterator is advanced, and the
        iterator fails at its end if the rows read differ from the manifest's count."""
        client = self._client_factory(self._host, self._credentials)
        response, seconds = run_statement(
            client, self._warehouse, self._query, self._log
        )
        return RowStream(
            schema=schema_of(response),
            batches=self._batches(client, response, seconds),
            metadata={"warehouse_id": self._warehouse, "statement_seconds": seconds},
        )

    def _batches(
        self, client: WorkspaceClient, response: StatementResponse, seconds: float
    ) -> Iterator[pa.RecordBatch]:
        rows_read = 0
        for rows in iter_chunks(client, response):
            batch = record_batch(response, rows, first_row_number=rows_read + 1)
            rows_read += batch.num_rows
            yield batch
        if self._log:
            self._log.info(
                f"Statement executed on warehouse {self._warehouse} in {seconds}s: {rows_read} row(s)"
            )
