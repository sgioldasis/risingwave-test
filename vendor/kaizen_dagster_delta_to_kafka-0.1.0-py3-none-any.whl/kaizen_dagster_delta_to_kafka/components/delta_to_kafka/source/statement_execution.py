"""The Databricks Statement Execution API (Databricks SQL, not `runs/submit`), through the
SDK's `StatementExecutionAPI`.

The component deliberately executes SQL statements -- the YAML's query travels verbatim
to the warehouse -- so this is a statement runner, not a job launcher. The
warehouse and the workspace come from the caller (the instance's `warehouse` attribute
and the client opened for the resolved `workspace`), never from module constants.

What the SDK does not do stays here: the bounded wait past the inline one (a wedged
warehouse must fail the run, not hang it), the cancellation that follows, and the
completeness check on a chunked result.
"""

import time
from collections.abc import Iterator, Sequence

from dagster import DagsterLogManager
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors.base import DatabricksError
from databricks.sdk.service.sql import (
    ExecuteStatementRequestOnWaitTimeout,
    StatementResponse,
    StatementState,
)

_INLINE_WAIT = "50s"
_POLL_INTERVAL_SECONDS = 5
_POLL_MAX_WAIT_SECONDS = 600
_TERMINAL_STATES = frozenset(
    {
        StatementState.SUCCEEDED,
        StatementState.FAILED,
        StatementState.CANCELED,
        StatementState.CLOSED,
    }
)


def _state_of(response: StatementResponse) -> StatementState | None:
    """The statement's state, or None when the response carries none."""
    return response.status.state if response.status is not None else None


def _state_name(response: StatementResponse) -> str:
    state = _state_of(response)
    return state.value if state is not None else "unknown"


def submit_statement(
    client: WorkspaceClient,
    statement: str,
    warehouse_id: str,
) -> StatementResponse:
    """One Statement Execution API submission: wait up to 50 s inline, then keep running.
    No catalog or schema is set, so the query must qualify every table name; unqualified
    names resolve against the warehouse default."""
    return client.statement_execution.execute_statement(
        statement=statement,
        warehouse_id=warehouse_id,
        wait_timeout=_INLINE_WAIT,
        on_wait_timeout=ExecuteStatementRequestOnWaitTimeout.CONTINUE,
    )


def cancel_statement(
    client: WorkspaceClient,
    statement_id: str,
    log: DagsterLogManager | None = None,
) -> None:
    """Best-effort cancellation of a statement the client stopped waiting for: without it
    the warehouse keeps executing (and billing) a statement whose result nobody reads.
    A failed cancellation -- rejected or unreachable -- is logged, never raised (the
    original failure still propagates)."""
    try:
        client.statement_execution.cancel_execution(statement_id)
    except (DatabricksError, OSError) as error:
        if log:
            log.warning(f"Cancellation of statement {statement_id} failed: {error}")


def poll(
    client: WorkspaceClient,
    statement_id: str,
    poll_interval: float | None = None,
    max_wait: float | None = None,
) -> StatementResponse:
    """Poll a statement to a terminal state, bounded: a wedged warehouse must fail the
    run, not hang it. The deadline is what run_statement turns into the cancellation
    plus the TimeoutError. The defaults are read at call time, so a test can shorten
    them."""
    interval = _POLL_INTERVAL_SECONDS if poll_interval is None else poll_interval
    limit = _POLL_MAX_WAIT_SECONDS if max_wait is None else max_wait
    deadline = time.time() + limit
    while time.time() < deadline:
        response = client.statement_execution.get_statement(statement_id)
        if _state_of(response) in _TERMINAL_STATES:
            return response
        time.sleep(interval)
    raise TimeoutError(f"Statement {statement_id} did not complete within {limit}s")


def iter_chunks(
    client: WorkspaceClient, response: StatementResponse
) -> Iterator[Sequence[Sequence[str]]]:
    """The API returns a large result in chunks and the first response holds only the first
    one; without the others a read is silently partial and the published set understates
    the query's rows (found 2026-10-07: 49,152 of 80,300 delete events). Yield each
    chunk's rows in order -- the first from the response, the rest fetched as the caller
    asks for them -- and, once the last is yielded, fail if the rows read differ from the
    manifest's total_row_count or the result is flagged truncated.

    The check runs when the iterator is exhausted, so a caller that must not act on a
    partial result has to consume every chunk before it does."""
    result = response.result
    if result is None or result.data_array is None:
        return
    read = len(result.data_array)
    yield result.data_array
    next_index = result.next_chunk_index
    statement_id = response.statement_id or ""
    while next_index is not None:
        try:
            chunk = client.statement_execution.get_statement_result_chunk_n(
                statement_id, next_index
            )
        except DatabricksError as error:
            raise RuntimeError(
                f"Fetching result chunk {next_index} failed: {error}"
            ) from error
        rows = chunk.data_array or []
        read += len(rows)
        yield rows
        next_index = chunk.next_chunk_index
    manifest = response.manifest
    total = manifest.total_row_count if manifest is not None else None
    truncated = manifest.truncated if manifest is not None else None
    if truncated or (total is not None and read != total):
        raise RuntimeError(
            f"Incomplete result: read {read} row(s), manifest total_row_count={total}, "
            + f"truncated={truncated}"
        )


def _failure(response: StatementResponse) -> str:
    """What a non-successful statement reports: its state, and the error when it has one."""
    error = response.status.error if response.status is not None else None
    detail = f": {error.error_code}: {error.message}" if error is not None else ""
    return f"state={_state_name(response)}{detail}"


def run_statement(
    client: WorkspaceClient,
    warehouse_id: str,
    query: str,
    log: DagsterLogManager | None = None,
) -> tuple[StatementResponse, float]:
    """The statement runner: submit the query verbatim on the given warehouse and poll to
    a terminal state. Returns (the finished statement's response, wall seconds); its
    first chunk of rows is in the response and `iter_chunks` reads the rest. Progress is
    logged (the submission, then any handoff to polling) so a queued statement doesn't
    read as a hung run; on the polling deadline the statement is cancelled before the
    TimeoutError propagates."""
    if log:
        log.info(
            f"Submitting the YAML query on warehouse {warehouse_id} (inline wait 50 s)"
        )
    started = time.monotonic()
    try:
        response = submit_statement(client, query, warehouse_id)
        if _state_of(response) not in _TERMINAL_STATES:
            statement_id = response.statement_id or ""
            if log:
                log.info(
                    f"Statement {statement_id} still {_state_name(response)} after the inline wait -- "
                    + f"polling every {_POLL_INTERVAL_SECONDS} s (deadline {_POLL_MAX_WAIT_SECONDS} s)"
                )
            try:
                response = poll(client, statement_id)
            except TimeoutError:
                cancel_statement(client, statement_id, log)
                raise
    except DatabricksError as error:
        raise RuntimeError(
            f"Databricks Statement Execution API request failed: {error}"
        ) from error
    if _state_of(response) != StatementState.SUCCEEDED:
        raise RuntimeError(f"Statement failed: {_failure(response)}")
    return response, round(time.monotonic() - started, 1)
