"""The publish pipeline: read the rows, shape them into messages, send them unless it is a
dry run. It knows no Databricks, no Kafka and no Dagster: it is written against the interfaces
(`interfaces.py`), and `runtime/factory.py` supplies the implementations.

Nothing is sent until every message exists, so a result the format cannot use, or one the
source finds incomplete, fails the run before the sink is touched. In a dry run the whole
path runs and the sink is never called. The full result is published every run; the consumer owns deduplication, so the
pipeline stays stateless.
"""

import time
from collections.abc import Sequence
from dataclasses import dataclass

from .interfaces import MessageFormat, MessageSerializer, MessageSink, RowSource
from .message_metadata import metadata_fields
from .messages import KafkaMessage, MetadataField, RunInfo


@dataclass(frozen=True)
class PublishResult:
    """What one run did: the messages it built (sent unless `dry_run`), what the source
    reported about its read, and how long the whole run took."""

    messages: tuple[KafkaMessage, ...]
    source_metadata: dict[str, object]
    dry_run: bool
    seconds: float


class PublishPipeline:
    def __init__(
        self,
        source: RowSource,
        message_format: MessageFormat,
        serializer: MessageSerializer,
        sink: MessageSink,
        message_metadata: Sequence[MetadataField] = (),
    ) -> None:
        self._source: RowSource = source
        self._format: MessageFormat = message_format
        self._serializer: MessageSerializer = serializer
        self._sink: MessageSink = sink
        self._message_metadata: tuple[MetadataField, ...] = tuple(message_metadata)

    def run(self, run: RunInfo) -> PublishResult:
        """One run: read, shape, serialize, then send unless `run.dry_run`.

        The format checks the result's columns before any row is read, and every batch is
        read and turned into a message before the first message is sent: the source
        verifies the result is complete as its iterator runs out, so an incomplete result
        fails the run with nothing published."""
        started = time.monotonic()
        stream = self._source.read()
        self._format.check_schema(stream.schema)
        extra = metadata_fields(run, self._message_metadata)
        messages: list[KafkaMessage] = []
        for batch in stream.batches:
            records = self._format.shape(batch, first_row_number=len(messages) + 1)
            messages.extend(
                self._serializer.serialize(record, extra) for record in records
            )
        if not run.dry_run:
            self._sink.publish(messages)
        return PublishResult(
            messages=tuple(messages),
            source_metadata=dict(stream.metadata),
            dry_run=run.dry_run,
            seconds=time.monotonic() - started,
        )
