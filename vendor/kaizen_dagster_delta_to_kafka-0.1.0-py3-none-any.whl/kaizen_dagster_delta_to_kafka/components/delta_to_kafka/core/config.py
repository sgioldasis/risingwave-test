"""One instance's configuration, as a frozen model the factory and the asset read.

Construction refuses what would otherwise fail at run time. Errors name the `defs.yaml`
attribute a value came from (`workspace`, not `host`), since that is what the person
fixing it edits. The Dagster names an instance's asset gets (key, group) are derived in
`runtime/assets.py`, not here.
"""

from typing import ClassVar

from pydantic import BaseModel, ConfigDict, model_validator

from .interfaces import MessageFormat
from .messages import MetadataField


def _blank(field: str) -> ValueError:
    return ValueError(f"{field} must not be blank")


class DeltaToKafkaConfig(BaseModel):
    """One instance: a query on a serverless SQL warehouse whose rows are published to a
    Kafka topic in the given message format.

    Construction refuses what would otherwise fail at run time. Errors name the
    `defs.yaml` attribute a value came from (`workspace`, not `host`), since that is
    what the person fixing it edits."""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        frozen=True, arbitrary_types_allowed=True
    )

    # Dagster: the asset's name and the code location's namespace, prepended to the asset
    # key: without it a second location instantiating the same name would collide asset
    # keys.
    name: str
    asset_key_prefix: tuple[str, ...]
    # Source: the query, the Databricks workspace host it runs on (resolved by the
    # component from the repository's databricks-workspaces.yaml, or given literally)
    # and the serverless SQL warehouse it is submitted to (typed in the instance).
    query: str
    host: str
    warehouse: str
    # Sink: the Kafka cluster (a profile name), the topic and how a row becomes a message.
    kafka_profile: str
    topic: str
    message: MessageFormat
    # Run facts added to every message as extra JSON fields; none by default.
    metadata: tuple[MetadataField, ...] = ()
    # Run options.
    dry_run: bool = True
    # Previews echo message contents into run metadata. They are off by default: rows are
    # often customer data.
    preview_limit: int = 0

    @model_validator(mode="after")
    def _refuse_what_would_fail_at_run_time(self) -> DeltaToKafkaConfig:
        identities = (
            ("name", self.name),
            ("query", self.query),
            ("workspace", self.host),
            ("warehouse", self.warehouse),
            ("kafka_profile", self.kafka_profile),
            ("topic", self.topic),
        )
        for field_name, value in identities:
            if not value.strip():
                raise _blank(field_name)
        for segment in self.asset_key_prefix:
            if not segment.strip():
                raise _blank("asset_key_prefix segment")
            if "/" in segment:
                # AssetKey(["p", "a/b"]).to_user_string() is "p/a/b", which parses
                # back as three segments: a slash here would silently turn a local
                # asset into an unrelated external key.
                raise ValueError(
                    f"asset_key_prefix segments must not contain '/' (it would not round-trip through a Dagster asset key); got {segment!r}"
                )
        if self.preview_limit < 0:
            raise ValueError("preview_limit must not be negative")
        return self
