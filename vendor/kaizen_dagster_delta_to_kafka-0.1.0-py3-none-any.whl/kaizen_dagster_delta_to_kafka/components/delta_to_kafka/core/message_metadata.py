"""The metadata an instance can add to every message, as extra fields in the JSON.

Called "message metadata" so it is not confused with the Dagster run metadata the asset
reports. Every field describes the run, never a row, and is the same for every message of
the run: `processed_at` is the run's start, taken once, not a clock read per message.
"""

from collections.abc import Sequence
from datetime import UTC

from .messages import MetadataField, RunInfo


def metadata_fields(
    run: RunInfo, include: Sequence[MetadataField]
) -> dict[str, object]:
    """The chosen fields and their values for this run, in the order they were chosen.
    No fields chosen, no fields added."""
    available: dict[MetadataField, object] = {
        # Second-truncated UTC: a stable, sortable text form.
        "processed_at": run.created.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run.run_id,
        "name": run.name,
        "dry_run": run.dry_run,
    }
    return {field: available[field] for field in include}
