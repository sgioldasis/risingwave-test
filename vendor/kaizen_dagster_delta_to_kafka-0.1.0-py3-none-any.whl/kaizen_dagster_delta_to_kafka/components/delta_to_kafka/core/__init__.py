"""What a run is, with no Databricks, Kafka or Dagster in it: the instance configuration
(`config`), the message types (`messages`), the interfaces a source, serializer and sink
satisfy (`interfaces`), the run facts added to every message (`message_metadata`) and the
pipeline that joins them (`pipeline`). Nothing here imports from `source`, `sink` or
`runtime`: they depend on this package, never the other way round."""
