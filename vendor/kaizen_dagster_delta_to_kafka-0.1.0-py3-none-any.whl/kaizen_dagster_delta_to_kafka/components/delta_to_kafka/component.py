"""The delta-to-kafka Dagster component: one `defs.yaml` instance -> one publisher.

One instance runs a query on a serverless SQL warehouse (the Statement Execution API --
the only way it reads data) and publishes one Kafka message per row to its topic, shaped
by the instance's `message` format. The attributes read in the order data flows:
the Dagster identity (`name`, `asset_key_prefix`), the source (`query`, `workspace`,
`warehouse` -- the id of the serverless SQL warehouse, typed in the instance), the sink
(`kafka_profile`, `topic`, `message`, `metadata`), then the run options.
"""

from typing import Annotated, override

import dagster as dg
from dagster.components import Resolver
from pydantic import Field, model_validator

from .core.config import DeltaToKafkaConfig
from .core.messages import MetadataField
from .runtime.assets import build_instance_defs
from .sink.formats.json import JsonFormat
from .sink.kafka_profile import load_profile
from .source.authentication import resolve_workspace


class DeltaToKafkaComponent(dg.Component, dg.Model, dg.Resolvable):
    """One publisher: a query on a serverless SQL warehouse, one Kafka message per row.
    The query is submitted verbatim through the Statement Execution API; that is the only
    way the component reads data. dry_run (the default) runs the whole path -- query,
    message format, counting -- and sends nothing.
    """

    # --- Dagster -----------------------------------------------------------------
    name: Annotated[
        str,
        Resolver.default(
            description="The asset's name. With `asset_key_prefix` it forms the asset "
            + "key."
        ),
    ]
    # The code location's namespace: prepended to the asset key, so two locations
    # instantiating the same name cannot collide (the workspace's per-location
    # namespacing rule, as the sibling DatabricksJobOrchestrationComponent's
    # `asset_key_prefix`).
    asset_key_prefix: Annotated[
        list[str],
        Resolver.default(
            description="Dagster asset-key segments prepended to the asset key."
        ),
    ] = Field(min_length=1)

    # --- source: the Databricks query ----------------------------------------------
    query: Annotated[
        str,
        Resolver.default(
            description="The query, submitted verbatim. It must qualify every table "
            + "name (catalog.schema.table), and its result columns must suit the "
            + "`message` format."
        ),
    ]
    workspace: Annotated[
        str,
        Resolver(
            resolve_workspace,
            model_field_type=str,
            description="Which registered Databricks workspace hosts the tables this "
            + "instance reads -- a name from the repository's databricks-workspaces.yaml "
            + "(resolved per deployment). A literal https:// host is accepted where a "
            + "registry name is not available.",
        ),
    ]
    warehouse: Annotated[
        str,
        Resolver.default(
            description="The id of the serverless SQL warehouse the query is "
            + "submitted to, typed in the instance (quote it if it is all digits). "
            + "It must belong to `workspace`.",
        ),
    ]

    # --- sink: the Kafka cluster, the topic, the message ---------------------------
    kafka_profile: Annotated[
        str,
        Resolver.default(
            description="The Kafka cluster to publish to: an entry of the Kafka "
            + "profiles file (sink/kafka_profiles.conf), which gives the bootstrap "
            + "servers, the user and the name of the secret holding the password."
        ),
    ]
    topic: Annotated[
        str,
        Resolver.default(
            description="The Kafka topic every message is published to. It must "
            + "already exist."
        ),
    ]
    message: JsonFormat = Field(
        description="How a row becomes a Kafka message: the row as JSON, with the "
        + "columns the query returns, keyed by `key_column`. `json` is the only "
        + "format for now.",
    )
    metadata: Annotated[
        list[MetadataField],
        Resolver.default(
            description="Run facts added to every message as extra JSON fields, after "
            + "the query's columns: `processed_at` (the run's start, UTC), `run_id`, "
            + "`name` (the instance's name) and `dry_run`. None by default. A query "
            + "column with the same name fails the run."
        ),
    ] = Field(default_factory=list)

    # --- run options ---------------------------------------------------------------
    dry_run: Annotated[
        bool,
        Resolver.default(
            description="The default run mode. True (the default) runs the whole path "
            + "-- query, message format, counting -- and sends nothing. "
            + "Flippable per run from the launchpad."
        ),
    ] = True
    preview_limit: Annotated[
        int,
        Resolver.default(
            description="How many messages to echo into the run's metadata as "
            + "previews. 0 (the default) echoes none: rows are often customer data."
        ),
    ] = 0

    # Pydantic needs the hook on the model; the rules live in DeltaToKafkaConfig, which
    # refuses an invalid instance on construction.
    @model_validator(mode="after")
    def validate_configuration(self) -> DeltaToKafkaComponent:
        _ = self.to_config()
        # An unknown or broken profile is a load-time error, not a run-time one.
        _ = load_profile(self.kafka_profile)
        return self

    def to_config(self) -> DeltaToKafkaConfig:
        """The instance's YAML attributes mapped onto the frozen config."""
        return DeltaToKafkaConfig(
            name=self.name,
            asset_key_prefix=tuple(self.asset_key_prefix),
            query=self.query,
            host=self.workspace,
            warehouse=self.warehouse,
            kafka_profile=self.kafka_profile,
            topic=self.topic,
            message=self.message,
            metadata=tuple(self.metadata),
            dry_run=self.dry_run,
            preview_limit=self.preview_limit,
        )

    @override
    def build_defs(self, context: dg.ComponentLoadContext) -> dg.Definitions:
        return build_instance_defs(self.to_config())
