"""The last step before the wire: a record and the run's metadata become one Kafka
message. The only place JSON is written, so every message uses the same encoding.

Values arrive typed (see `source/arrow_conversion.py`), so the encoding says how each
type is written, and refuses a type it has no rule for:

| Python value     | JSON                                              |
| ---------------- | ------------------------------------------------- |
| str, int, float, bool, None | as they are                            |
| `Decimal`        | an exact string, `"12.50"` (a float would round)  |
| `datetime`       | UTC ISO-8601 with `Z` and microseconds, or the wall-clock reading with no zone when it has none |
| `date`           | ISO-8601, `"2026-11-09"`                          |
| `bytes`          | a base64 string                                   |

A NaN or an infinity is refused: JSON has no way to write one.
"""

import base64
import json
from collections.abc import Mapping
from datetime import UTC, date, datetime
from decimal import Decimal

from ..core.messages import KafkaMessage, Record


def wire_text(value: object) -> str | None:
    """How a value that is not plain JSON is written, or None when JSON writes it as it
    is. The one set of rules for payload values and for Kafka keys alike."""
    match value:
        case Decimal():
            return format(value, "f")
        case datetime():
            if value.tzinfo is None:
                return value.isoformat(timespec="microseconds")
            return (
                value.astimezone(UTC)
                .replace(tzinfo=None)
                .isoformat(timespec="microseconds")
                + "Z"
            )
        case date():
            return value.isoformat()
        case bytes():
            return base64.b64encode(value).decode("ascii")
        case _:
            return None


def _default(value: object) -> str:
    text = wire_text(value)
    if text is None:
        raise TypeError(f"Cannot write a {type(value).__name__} value as JSON")
    return text


def key_text(value: object) -> str:
    """A key column's value as the Kafka key's text."""
    text = wire_text(value)
    return str(value) if text is None else text


def canonical_json(payload: Mapping[str, object]) -> str:
    """The wire canon: compact separators, keys in the dict's order (the query result's
    column order, then the metadata), nulls explicit (json.dumps never drops them),
    non-ASCII kept as-is."""
    return json.dumps(
        payload,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
        default=_default,
    )


def encode(record: Record, metadata: Mapping[str, object]) -> KafkaMessage:
    """The record's payload with the metadata fields after its columns, as the value; the
    record's key as the key. A column named like a metadata field is refused rather than
    overwritten: the query's data is never silently replaced."""
    clashes = [name for name in metadata if name in record.payload]
    if clashes:
        raise ValueError(
            f"The query result already has column(s) {clashes} -- rename them in the SELECT, or leave them out of `metadata`"
        )
    return KafkaMessage(
        key=record.key.encode("utf-8"),
        value=canonical_json({**record.payload, **metadata}).encode("utf-8"),
    )


class JsonMessageSerializer:
    """The pipeline's `MessageSerializer`: every message is `encode`d the same way."""

    def serialize(self, record: Record, extra: Mapping[str, object]) -> KafkaMessage:
        return encode(record, extra)
