"""The message format: one JSON message per row, the row as the query returned it, keyed
by one column. The query decides which columns are sent; nothing is added or wrapped here
(run metadata is added by the encoding step, when the instance asks for it)."""

from typing import Literal

import dagster as dg
import pyarrow as pa
from pydantic import Field, field_validator, model_validator

from ...core.messages import Record
from ..encoding import key_text


class JsonFormat(dg.Model, dg.Resolvable):
    """The `message` section: the value is the row as JSON (the query's column order,
    nulls explicit) and the key is `key_column`'s value. `json` is the only format
    there is for now, so any other `format` is refused when the instance loads."""

    format: Literal["json"] = Field(
        description="The message format. Only `json` is supported for now."
    )
    key_column: str = Field(
        description="The result column the Kafka key is taken from. It must be in "
        + "every row's result and never null."
    )

    @field_validator("format", mode="before")
    @classmethod
    def _refuse_any_other_format(cls, value: object) -> object:
        if value != "json":
            raise ValueError(
                f"format must be 'json', the only supported message format for now; got {value!r}"
            )
        return value

    @model_validator(mode="after")
    def _refuse_a_blank_key_column(self) -> JsonFormat:
        if not self.key_column.strip():
            raise ValueError("key_column must not be blank")
        return self

    def check_schema(self, schema: pa.Schema) -> None:
        """A result without the key column fails here, before any row is read -- an empty
        result included, since it still carries its column names."""
        columns = list(schema.names)
        if self.key_column not in columns:
            raise ValueError(
                f"The query result has no key column {self.key_column!r} (found {columns}) -- alias it in the SELECT or change key_column"
            )

    def shape(self, rows: pa.RecordBatch, first_row_number: int) -> list[Record]:
        """The batch's rows as records, in the result's order. A row whose key is null
        fails here, before anything is encoded."""
        records: list[dict[str, object]] = rows.to_pylist()
        shaped: list[Record] = []
        for number, row in enumerate(records, start=first_row_number):
            key = row[self.key_column]
            if key is None:
                raise ValueError(
                    f"Row {number} has a null {self.key_column} -- the Kafka record key cannot be null"
                )
            shaped.append(Record(key=key_text(key), payload=row))
        return shaped
