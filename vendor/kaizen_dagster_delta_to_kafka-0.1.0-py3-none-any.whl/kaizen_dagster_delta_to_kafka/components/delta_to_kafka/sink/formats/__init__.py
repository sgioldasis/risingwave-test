"""Message formats: how a query's rows become Kafka messages. One module per format, each
selectable by the `message` section of a `defs.yaml`; `wire` holds what they share."""
