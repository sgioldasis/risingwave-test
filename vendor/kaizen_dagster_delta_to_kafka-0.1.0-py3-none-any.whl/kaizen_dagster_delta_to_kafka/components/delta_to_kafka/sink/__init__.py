"""Everything that reaches the sink: the message formats (`formats`) and the Kafka
output cluster (`kafka`)."""
