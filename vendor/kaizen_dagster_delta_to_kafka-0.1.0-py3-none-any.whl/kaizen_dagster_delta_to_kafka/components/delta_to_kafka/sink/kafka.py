"""The Kafka cluster: the producer, its config, the produce loop and `KafkaSink`, the
pipeline's `MessageSink` for it. The cluster is a
`KafkaProfile` (see kafka_profile.py): bootstrap servers, user and options come from it.
When it uses SASL, the password is the environment variable the profile's secret key
names (`KafkaProfile.password_secret_key`), read at call time and sourced from the
deployment's secrets. The component is publish-only: there is no admin client and no
consumer here -- topic provisioning belongs to deployment infrastructure.
"""

import os
import time
from collections.abc import Callable, Mapping, Sequence
from typing import Protocol

from confluent_kafka import Producer

from ..core.messages import KafkaMessage
from .kafka_profile import KafkaProfile

# What confluent-kafka's stubs accept as a producer config (the 2.13 stubs spell the
# value type out; `dict` is invariant, so a `dict[str, str]` would not be assignable).
ProducerConfig = dict[str, str | int | float | bool]

# Bound on the final flush: how long the run waits for the broker to acknowledge.
FLUSH_TIMEOUT_SECONDS = 120

# Cap on how long produce() may keep hitting a full librdkafka queue before the run
# fails (see produce_one).
QUEUE_FULL_DEADLINE_SECONDS = 120


class ProducerLike(Protocol):
    """What the produce loop needs from a producer -- the real confluent_kafka.Producer
    satisfies it structurally, and so do the tests' fakes."""

    def produce(
        self,
        topic: str,
        *,
        key: bytes,
        value: bytes,
        on_delivery: Callable[[object, object], None] | None = None,
    ) -> None: ...

    def poll(self, timeout: float = 0) -> int: ...

    def flush(self, timeout: float = -1) -> int: ...


def produce_one(
    producer: ProducerLike,
    topic: str,
    key: bytes,
    value: bytes,
    delivery_errors: list[str],
) -> None:
    """Enqueue one message (key AND value together) with the sync's bounded
    backpressure: produce() only enqueues, and BufferError means librdkafka's
    queue hit its ceiling -- serve the delivery callbacks with poll() and retry
    (demo volumes never hit it, but this loop is the producer's real shape)."""

    def on_delivery(err: object, _msg: object) -> None:
        if err is not None:
            delivery_errors.append(str(err))

    queue_full_deadline = time.monotonic() + QUEUE_FULL_DEADLINE_SECONDS
    while True:
        try:
            producer.produce(topic=topic, key=key, value=value, on_delivery=on_delivery)
            break
        except BufferError:
            if time.monotonic() > queue_full_deadline:
                raise RuntimeError(
                    f"Kafka producer queue stayed full for {QUEUE_FULL_DEADLINE_SECONDS}s (topic {topic})"
                ) from None
            # poll() serves delivery callbacks; its return count is irrelevant here.
            _ = producer.poll(0.1)


def kafka_producer_config(
    profile: KafkaProfile, environ: Mapping[str, str] | None = None
) -> ProducerConfig:
    """The producer's settings: the profile's bootstrap servers and options, plus the
    user and password when the profile authenticates over SASL. A missing password
    fails naming the environment variable, never printing any value."""
    environ = os.environ if environ is None else environ
    conf: ProducerConfig = {
        "bootstrap.servers": profile.bootstrap_servers,
        **profile.options,
    }
    if profile.uses_sasl:
        # The model guarantees both are set when SASL is used.
        env_var = profile.password_secret_key or ""
        password = environ.get(env_var, "")
        if not password:
            raise ValueError(
                f"Kafka profile {profile.name!r} needs its password in the environment "
                + f"variable {env_var}"
            )
        conf["sasl.username"] = profile.user or ""
        conf["sasl.password"] = password
    # Volume headroom: compress on the wire, let librdkafka batch briefly (the produce
    # loop's final flush absorbs the linger), and raise the queue ceilings so a large
    # backlog never blocks the enqueuer.
    conf.update(
        {
            "compression.type": "lz4",
            "linger.ms": "50",
            "batch.size": str(1024 * 1024),
            "queue.buffering.max.messages": str(500000),
            "batch.num.messages": str(20000),
        }
    )
    return conf


def producer(profile: KafkaProfile) -> Producer:
    """A producer whose TLS/SASL handshake starts now, in librdkafka's background
    threads. The brokers are reached over VPN and connecting takes ~9s; creating the
    producer before the scan runs lets that happen off the critical path."""
    producer = Producer(kafka_producer_config(profile))
    # Serve any immediately-ready callbacks so the TLS/SASL handshake's first
    # events never sit queued (poll's return count is irrelevant here).
    _ = producer.poll(0)
    return producer


class KafkaSink:
    """The pipeline's `MessageSink` for one topic of one cluster. The producer is made by
    `producer_factory` when something is published, not when the sink is built, so a dry
    run never connects and never needs the password."""

    def __init__(
        self,
        profile: KafkaProfile,
        topic: str,
        producer_factory: Callable[[KafkaProfile], ProducerLike],
    ) -> None:
        self._profile: KafkaProfile = profile
        self._topic: str = topic
        self._producer_factory: Callable[[KafkaProfile], ProducerLike] = (
            producer_factory
        )

    def publish(self, messages: Sequence[KafkaMessage]) -> None:
        """Produce every message to the topic of the profile's cluster, then flush within a
        bound. Any delivery the broker rejected, or still undelivered when the flush gives
        up, fails the run."""
        kafka_producer = self._producer_factory(self._profile)
        delivery_errors: list[str] = []
        for message in messages:
            produce_one(
                kafka_producer, self._topic, message.key, message.value, delivery_errors
            )
        undelivered = kafka_producer.flush(timeout=FLUSH_TIMEOUT_SECONDS)
        if undelivered or delivery_errors:
            raise RuntimeError(
                f"Kafka delivery failed: {len(delivery_errors)} rejected ({delivery_errors[:3]}), "
                + f"{undelivered} undelivered after {FLUSH_TIMEOUT_SECONDS}s"
            )
