"""The per-run mode switch: the launchpad-facing `dry_run` override.

`RunModeConfig` is the switch; `run_mode_for` re-defaults it to the instance's YAML value
so the scaffold shows the effective mode; `effective_dry_run` arbitrates at run time.
"""

from dagster import AssetExecutionContext, Config

from ..core.config import DeltaToKafkaConfig


class RunModeConfig(Config):
    """The per-run mode switch. None (the default) means the YAML decides; a value
    overrides it for this run only, logged and recorded in the metadata. The YAML value
    still governs schedules and blank launches. The launchpad meets this switch through
    run_mode_for(cfg), which re-defaults it to the instance's YAML value so the scaffold
    shows the effective mode rather than a blank."""

    dry_run: bool | None = None


def effective_dry_run(
    cfg: DeltaToKafkaConfig, config: RunModeConfig, context: AssetExecutionContext
) -> bool:
    """The run's mode: the YAML value, or the launch's override (logged when they differ)."""
    if config.dry_run is None:
        return cfg.dry_run
    if config.dry_run != cfg.dry_run:
        context.log.info(
            f"Run-config override: dry_run={config.dry_run} (the YAML value is {cfg.dry_run})"
        )
    return config.dry_run


def run_mode_for(cfg: DeltaToKafkaConfig) -> type[RunModeConfig]:
    """The launchpad-facing mode switch: RunModeConfig re-defaulted to this instance's
    YAML value. The scaffold button then shows the effective mode (false for a live-pinned
    instance, true for the safe default) instead of a blank, and launching with it lands
    exactly where a blank launch would. Typing null restores the YAML-decides escape
    hatch; the runtime semantics are untouched (effective_dry_run still arbitrates)."""

    class RunMode(RunModeConfig):
        dry_run: bool | None = cfg.dry_run

    return RunMode
