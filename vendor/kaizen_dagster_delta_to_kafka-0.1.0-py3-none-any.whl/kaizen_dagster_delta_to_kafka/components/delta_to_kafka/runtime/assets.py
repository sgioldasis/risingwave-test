"""The publish asset -- the instance's whole Dagster surface (the component is
publish-only).

This module is only the Dagster edge: the asset's decoration, the run-mode override, and
turning a `PublishResult` into the run's logs and metadata. What a run does is
`PublishPipeline` (`core/pipeline.py`), assembled by `factory.build_pipeline` from the
implementations; the asset declares no Dagster resources, so the same defs.yaml deploys to
staging and production with nothing for a team to bind. A test hands `build_publish_asset`
its own `build` to run the asset against fakes (tests/fakes.py).

Topic provisioning belongs to deployment infrastructure, not the component -- the
instance's topic must already exist when the asset publishes.

In dry-run (the default) the publish asset runs the whole path -- query, message format,
counting -- and sends nothing. The full result is published every run; the consumer owns
deduplication, so the producer stays stateless.
"""

import json
import re
from collections.abc import Callable, Sequence
from datetime import UTC, datetime
from typing import cast

from dagster import (
    AssetExecutionContext,
    AssetKey,
    DagsterLogManager,
    Definitions,
    MetadataValue,
    asset,
)

from ..core.config import DeltaToKafkaConfig
from ..core.messages import KafkaMessage, RunInfo
from ..core.pipeline import PublishPipeline, PublishResult
from .factory import build_pipeline
from .run_mode import effective_dry_run, run_mode_for

# How the asset gets its pipeline: `factory.build_pipeline` in a deployment, the same
# function with fake clients in a test.
PipelineFactory = Callable[
    [DeltaToKafkaConfig, DagsterLogManager | None], PublishPipeline
]


def dagster_identifier(value: str) -> str:
    """Coerce a value into something Dagster accepts as a definition name."""
    identifier = re.sub(r"[^A-Za-z0-9_]", "_", value).strip("_")
    return identifier or "job"


def asset_key(cfg: DeltaToKafkaConfig) -> AssetKey:
    """The prefix and the name as segments (`inverness/<name>`);
    `to_user_string()` is what a `defs.yaml` dependency spells."""
    return AssetKey([*cfg.asset_key_prefix, cfg.name])


def group_name(cfg: DeltaToKafkaConfig) -> str:
    return dagster_identifier("_".join([*cfg.asset_key_prefix, cfg.name]))


def previews(messages: Sequence[KafkaMessage], limit: int) -> list[dict[str, object]]:
    """The first `limit` messages as {"key", "value"} for run metadata, decoded from the
    wire JSON. A limit of 0 (the default) echoes nothing: the rows are often customer
    data, so showing them is opt-in."""
    return [
        {
            "key": message.key.decode("utf-8"),
            "value": cast("object", json.loads(message.value)),
        }
        for message in messages[:limit]
    ]


def metadata_entries(
    cfg: DeltaToKafkaConfig, result: PublishResult
) -> dict[str, object]:
    """The run metadata the materialization carries."""
    return {
        "items_count": MetadataValue.int(len(result.messages)),
        "topic": MetadataValue.text(cfg.topic),
        "dry_run": MetadataValue.bool(result.dry_run),
        "query": MetadataValue.text(cfg.query),
        "publish_seconds": MetadataValue.float(round(result.seconds, 1)),
        **(
            {
                "message_previews": MetadataValue.json(
                    previews(result.messages, cfg.preview_limit)
                )
            }
            if cfg.preview_limit
            else {}
        ),
        **result.source_metadata,
    }


def build_publish_asset(
    cfg: DeltaToKafkaConfig, build: PipelineFactory = build_pipeline
):
    run_mode = run_mode_for(cfg)

    @asset(
        name=cfg.name,
        key_prefix=list(cfg.asset_key_prefix),
        group_name=group_name(cfg),
        description=(
            "Run the query on the serverless SQL warehouse and publish one message per "
            f"row to {cfg.topic}. Under dry-run (the YAML default, or this run's mode "
            "switch) every message is built and nothing is sent."
        ),
    )
    # `-> None` is what keeps the I/O manager out of it: the asset reports metadata and has no
    # value to store, and without the annotation Dagster stores the returned None under
    # $DAGSTER_HOME/storage, which a pod without a writable DAGSTER_HOME refuses.
    def publish_query_result(context: AssetExecutionContext, config: run_mode) -> None:  # type: ignore[valid-type]  # pyright: ignore[reportInvalidTypeForm, reportUnknownParameterType] -- a per-instance Config subclass (the launchpad scaffold's prefill); dagster reads the annotation class at decoration time
        dry_run = effective_dry_run(cfg, config, context)  # pyright: ignore[reportUnknownArgumentType] -- see the signature note above
        pipeline = build(cfg, context.log)
        run = RunInfo(
            name=cfg.name,
            run_id=context.run.run_id,
            created=datetime.now(UTC),
            dry_run=dry_run,
        )

        result = pipeline.run(run)

        if dry_run:
            context.log.info(
                f"Dry run: built {len(result.messages)} message(s) for {cfg.topic} and sent "
                + "NOTHING (pin dry_run: false to publish)"
            )
        else:
            context.log.info(
                f"Published {len(result.messages)} message(s) to {cfg.topic} ({cfg.kafka_profile})"
            )
        context.add_output_metadata(metadata_entries(cfg, result))

    return publish_query_result


def build_instance_defs(cfg: DeltaToKafkaConfig) -> Definitions:
    """The instance's Definitions: exactly the publish asset, no jobs."""
    return Definitions(assets=[build_publish_asset(cfg)])
