"""The composition root: the one place that knows which implementation answers which interface.

`build_pipeline` turns an instance's configuration into a `PublishPipeline`: the Kafka
profile is read, the Databricks credentials are read from the environment, and the
Databricks source, the JSON serializer and the Kafka sink are wired to the pipeline. The
environment is read when the pipeline is built (a run starting), never at import, and the
Databricks client and the Kafka producer are only made when a read or a publish happens.

The client and producer factories are parameters so a test can hand in fakes without
patching anything.
"""

import os
from collections.abc import Callable, Mapping

from dagster import DagsterLogManager
from databricks.sdk import WorkspaceClient

from ..core.config import DeltaToKafkaConfig
from ..core.pipeline import PublishPipeline
from ..sink.encoding import JsonMessageSerializer
from ..sink.kafka import KafkaSink, ProducerLike, producer
from ..sink.kafka_profile import KafkaProfile, load_profile
from ..source.authentication import (
    Credentials,
    open_workspace_client,
    read_credentials,
)
from ..source.rows import StatementExecutionSource


def build_pipeline(
    cfg: DeltaToKafkaConfig,
    log: DagsterLogManager | None = None,
    *,
    environ: Mapping[str, str] | None = None,
    client_factory: Callable[
        [str, Credentials], WorkspaceClient
    ] = open_workspace_client,
    producer_factory: Callable[[KafkaProfile], ProducerLike] = producer,
) -> PublishPipeline:
    """The pipeline an instance runs. The profile is read first, so a broken one fails a
    dry run too; its password is only read when something is actually published."""
    profile = load_profile(cfg.kafka_profile)
    credentials = read_credentials(os.environ if environ is None else environ)
    return PublishPipeline(
        source=StatementExecutionSource(
            host=cfg.host,
            credentials=credentials,
            warehouse=cfg.warehouse,
            query=cfg.query,
            client_factory=client_factory,
            log=log,
        ),
        message_format=cfg.message,
        serializer=JsonMessageSerializer(),
        sink=KafkaSink(profile, cfg.topic, producer_factory),
        message_metadata=cfg.metadata,
    )
