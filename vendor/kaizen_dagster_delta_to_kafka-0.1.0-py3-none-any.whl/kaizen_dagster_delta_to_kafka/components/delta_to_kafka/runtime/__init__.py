"""What happens when Dagster starts a run: the publish asset (`assets`), its per-run mode
switch (`run_mode`) and the factory that wires the concrete source, serializer and sink
into the pipeline (`factory`). The one place that knows about all of `core`, `source` and
`sink`."""
