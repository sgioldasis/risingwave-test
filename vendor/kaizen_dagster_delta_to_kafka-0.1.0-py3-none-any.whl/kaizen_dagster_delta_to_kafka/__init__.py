"""Delta-to-Kafka Dagster components for Kaizen Gaming."""
