"""The Jobotron Dagster component: one `defs.yaml` instance -> one publisher.

The component that replaces the KYC team's jobotron notebooks: a per-company query on a
SQL warehouse (the Statement Execution API -- the only way it reads data), the rows
wrapped in the 13-field Jobotron envelope, and one Kafka message per customer on the
company's routed topic. One component type, no variants in code -- the variants differ
only in how parameters resolve, and that is the YAML's data:

- no `companies` block: single-statement mode (one query, one topic -- the notebooks'
  variant A/D shape);
- a `companies` block: fan-out -- **a partitioned asset, one partition per company**.
  Each company's parameters resolve in a fixed order (run anchor -> static ->
  per-company static -> configurator -> group lookup), each company's statement is
  bound through the Statement Execution API's parameters array (never interpolated),
  and each company publishes to its own routed topic.

The attributes read in the order data flows: the Dagster identity (`name`,
`asset_key_prefix`, `job_name`), the statement (`query`/`query_template`, `workspace`,
`warehouse`), the resolution (`companies`, `configurator`, `group_lookup`,
`parameters`, `parameters_by_company`, `literal_parameters`), the sink
(`kafka_profile`, `topic`/`topic_template`, `message`, `schema_version`), then the run
options (`dry_run`).
"""

from typing import Annotated, override

import dagster as dg
from dagster.components import Resolver
from pydantic import Field, model_validator

from .core.config import (
    CompaniesBlock,
    ConfiguratorBlock,
    GroupLookupBlock,
    JobotronConfig,
)
from .core.messages import MetadataField
from .runtime.assets import build_instance_defs
from .sink.formats.envelope import EnvelopeFormat
from .sink.formats.json import JsonFormat
from .sink.kafka_profile import load_profile
from .source.authentication import resolve_workspace


class JobotronComponent(dg.Component, dg.Model, dg.Resolvable):
    """One Jobotron publisher: per-company SQL on a SQL warehouse, the 13-field
    envelope, one Kafka message per customer. With a `companies` block the asset is
    partitioned by company; without one it is a single statement. dry_run (the default)
    follows the notebooks: the messages are built and published with IsDryRun: true,
    which the Worker no-ops."""

    # --- Dagster -----------------------------------------------------------------
    name: Annotated[
        str,
        Resolver.default(
            description="The asset's name. With `asset_key_prefix` it forms the asset "
            + "key."
        ),
    ]
    asset_key_prefix: Annotated[
        list[str],
        Resolver.default(
            description="Dagster asset-key segments prepended to the asset key."
        ),
    ] = Field(min_length=1)
    job_name: Annotated[
        str,
        Resolver.default(
            description="The envelope's JobName and the JobId's prefix: the NOTEBOOK's "
            + "name (e.g. Send_Email_to_Unverified_Customers), not a YAML slug."
        ),
    ]

    # --- source: the Databricks statement ------------------------------------------
    query: Annotated[
        str | None,
        Resolver.default(
            description="Single-statement mode: the query, with `{placeholder}s` bound "
            + "from the resolvers. Required without a `companies` block."
        ),
    ] = None
    query_template: Annotated[
        str | None,
        Resolver.default(
            description="Fan-out mode: the per-company query template. Must filter by "
            + "`{company_id}` (the comp_part pruning keeps one company's customers out "
            + "of another's topic). Required with a `companies` block."
        ),
    ] = None
    workspace: Annotated[
        str,
        Resolver(
            resolve_workspace,
            model_field_type=str,
            description="Which registered Databricks workspace hosts the tables this "
            + "instance reads -- a name from the repository's databricks-workspaces.yaml "
            + "(resolved per deployment). A literal https:// host is accepted where a "
            + "registry name is not available.",
        ),
    ]
    warehouse: Annotated[
        str,
        Resolver.default(
            description="The id of the SQL warehouse the queries are submitted to, "
            + "typed in the instance (quote it if it is all digits). It must belong "
            + "to `workspace`.",
        ),
    ]

    # --- resolution: which companies, with which parameters ------------------------
    companies: Annotated[
        CompaniesBlock | None,
        Resolver.default(
            description="The fan-out mode switch. Absent: one statement, one topic. "
            + "Present: a partitioned asset, one partition per company -- `include` "
            + "makes a static set, `source` (a table, e.g. de.metadatadb.mcompany) a "
            + "dynamic one, `exclude` prunes the enumeration."
        ),
    ] = None
    configurator: Annotated[
        ConfiguratorBlock | None,
        Resolver.default(
            description="Per-company parameters from the company's configurator entry "
            + "(requires `companies`). isActive is the implicit gate: an inactive "
            + "entry -- or none -- skips the company as a no-op success. The declared "
            + "`fields` become template variables, required when active."
        ),
    ] = None
    group_lookup: Annotated[
        GroupLookupBlock | None,
        Resolver.default(
            description="Resolve a code-valued variable (a mgrCode) to `{group_id}` "
            + "through de.metadatadb.mgroup. 0 or >1 matches fail the company."
        ),
    ] = None
    parameters: Annotated[
        dict[str, int | str | list[int] | list[str]],
        Resolver.default(
            description="Static binds for every `{placeholder}`, all companies."
        ),
    ] = Field(default_factory=dict)
    parameters_by_company: Annotated[
        dict[int | str, dict[str, int | str | list[int] | list[str]]],
        Resolver.default(
            description="Per-company static binds (fan-out mode): company id (int) "
            + "or exact comCode (str, case-insensitive) -> the binds only that "
            + "company's statement gets. All keys of one kind, not a mix."
        ),
    ] = Field(default_factory=dict)
    literal_parameters: Annotated[
        list[str],
        Resolver.default(
            description="Variables substituted as text instead of bound: the ones "
            + "whose position is not a value slot (a table name, an interval "
            + "literal). Whitelist-validated (letters/digits/underscores only), so no "
            + "SQL syntax can pass -- whatever their source."
        ),
    ] = Field(default_factory=list)

    # --- sink: the Kafka cluster, the topic routing, the message -------------------
    kafka_profile: Annotated[
        str,
        Resolver.default(
            description="The Kafka cluster to publish to: an entry of the Kafka "
            + "profiles file (sink/kafka_profiles.conf), which gives the bootstrap "
            + "servers, the user and the name of the secret holding the password."
        ),
    ]
    topic: Annotated[
        str | None,
        Resolver.default(
            description="Single-statement mode: the topic every message is published "
            + "to. It must already exist."
        ),
    ] = None
    topic_template: Annotated[
        str | None,
        Resolver.default(
            description="Fan-out mode: the per-company topic, routed by the "
            + "resolution's values -- `kyc.jobs.{market_code}` is the notebooks' own "
            + "routing (the comCode's first two characters, lowercased)."
        ),
    ] = None
    message: Annotated[
        JsonFormat | EnvelopeFormat,
        Resolver.default(
            description="How a row becomes a Kafka message: `envelope` (the contract "
            + "mode -- the 13 fields the Workers parse) or `json` (the row as the "
            + "query returned it, the demo mode)."
        ),
    ]
    metadata: Annotated[
        list[MetadataField],
        Resolver.default(
            description="Plain-JSON mode only: run facts added to every message as "
            + "extra JSON fields -- `processed_at`, `run_id`, `name`, `dry_run`. The "
            + "envelope carries its own run identity."
        ),
    ] = Field(default_factory=list)
    schema_version: Annotated[
        int,
        Resolver.default(
            description="The envelope contract's version (envelope mode only), bumped "
            + "by the author on a contract extension."
        ),
    ] = 1

    # --- run options ---------------------------------------------------------------
    dry_run: Annotated[
        bool,
        Resolver.default(
            description="The default run mode. True (the default) follows the "
            + "notebooks: the messages are built and published with IsDryRun: true, "
            + "which the Worker no-ops. In plain-JSON mode a dry run sends nothing. "
            + "Flippable per run from the launchpad."
        ),
    ] = True
    preview_limit: Annotated[
        int,
        Resolver.default(
            description="How many messages to echo into the run's metadata as "
            + "previews. 0 (the default) echoes none: rows are often customer data."
        ),
    ] = 0

    # Pydantic needs the hook on the model; the rules live in JobotronConfig, which
    # refuses an invalid instance on construction.
    @model_validator(mode="after")
    def validate_configuration(self) -> JobotronComponent:
        _ = self.to_config()
        # An unknown or broken profile is a load-time error, not a run-time one.
        _ = load_profile(self.kafka_profile)
        return self

    def to_config(self) -> JobotronConfig:
        """The instance's YAML attributes mapped onto the frozen config."""
        return JobotronConfig(
            name=self.name,
            asset_key_prefix=tuple(self.asset_key_prefix),
            job_name=self.job_name,
            query=self.query,
            query_template=self.query_template,
            host=self.workspace,
            warehouse=self.warehouse,
            companies=self.companies,
            configurator=self.configurator,
            group_lookup=self.group_lookup,
            parameters=self.parameters,
            parameters_by_company=self.parameters_by_company,
            literal_parameters=tuple(self.literal_parameters),
            kafka_profile=self.kafka_profile,
            topic=self.topic,
            topic_template=self.topic_template,
            message=self.message,
            metadata=tuple(self.metadata),
            schema_version=self.schema_version,
            dry_run=self.dry_run,
            preview_limit=self.preview_limit,
        )

    @override
    def build_defs(self, context: dg.ComponentLoadContext) -> dg.Definitions:
        return build_instance_defs(self.to_config())
