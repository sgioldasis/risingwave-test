"""The Configurator client: the notebooks' `configurator_client.ipynb`, ported.

`GET {base}/api/Sdk/calculateValue?configurationCode=…&hierarchyNodeCode=…&applicationName=databricks`
-- no authentication (access is network position), the response JSON's `value` field
carries the configuration itself as a JSON string.

Only *connecting* is retried: 3 attempts in all, 5 s then 15 s apart. Until it
connects, the request has not reached the configurator, so another attempt cannot do
anything twice; once it has (the response started), a failure is never retried. A
production run once failed with "Connect timed out" for its first three companies and
then connected for all the others -- the retry exists for that. Each attempt gets the
30 s connect/read timeout, so an unreachable configurator fails a call after about
2 minutes.

The client never logs a configuration value: the endpoint is unauthenticated, so the
component treats what it returns as data that stays off the logs.
"""

import json
import time
from collections.abc import Callable, Mapping
from typing import Protocol, cast
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

# The notebook's ApplicationName, TimeoutMillis and ConnectRetryDelaysMillis.
APPLICATION_NAME = "databricks"
TIMEOUT_SECONDS = 30.0
CONNECT_RETRY_DELAYS_SECONDS = (5.0, 15.0)


class OpenerLike(Protocol):
    """What the client calls to make a request -- `urllib.request.urlopen` in
    production, a fake in tests."""

    def __call__(self, request: Request, timeout: float) -> object: ...


def open_url(request: Request, timeout: float) -> object:
    return cast("object", urlopen(request, timeout=timeout))


class ConfiguratorError(RuntimeError):
    """A configurator call failed after its retries, or answered with something the
    component cannot use. The message names the request and the status -- never a
    configuration value."""


class ConfiguratorClient:
    """One configurator deployment (its base URL), one instance per run."""

    def __init__(
        self,
        base_url: str,
        *,
        timeout_seconds: float = TIMEOUT_SECONDS,
        retry_delays_seconds: tuple[float, ...] = CONNECT_RETRY_DELAYS_SECONDS,
        sleep: Callable[[float], None] = time.sleep,
        opener: OpenerLike = open_url,
    ) -> None:
        self._base_url: str = base_url.rstrip("/")
        self._timeout_seconds: float = timeout_seconds
        self._retry_delays_seconds: tuple[float, ...] = retry_delays_seconds
        self._sleep: Callable[[float], None] = sleep
        self._opener: OpenerLike = opener

    def configuration_value(
        self, configuration_code: str, hierarchy_node_code: str
    ) -> str:
        """The configuration's value for one hierarchy node (the notebooks pass the
        company's comCode): the JSON string the response's `value` field carries. An
        unknown configurationCode or node is an HTTP 422 -- a real failure here, not a
        skip (an existing-but-inactive entry is the skip)."""
        query = urlencode(
            {
                "configurationCode": configuration_code,
                "hierarchyNodeCode": hierarchy_node_code,
                "applicationName": APPLICATION_NAME,
            }
        )
        url = f"{self._base_url}/api/Sdk/calculateValue?{query}"
        body = self._get(url)
        try:
            parsed = cast("object", json.loads(body))
        except json.JSONDecodeError as error:
            raise ConfiguratorError(
                f"Configurator response for {url} is not JSON: {error}"
            ) from error
        entry = cast("dict[str, object]", parsed) if isinstance(parsed, dict) else {}
        value = entry.get("value")
        if value is None or (isinstance(value, str) and not value):
            raise ConfiguratorError(f"Configurator returned no value for {url}")
        return str(value)

    def _get(self, url: str) -> str:
        """One GET with the connect-only retry. A connect-phase failure (`URLError`,
        which wraps DNS, refused and TLS errors, or a timeout before the response
        started) is retried through the delays; a failure after the server started
        answering -- the body read included -- is not: the request has reached the
        configurator, and another attempt could do something twice."""
        attempts = len(self._retry_delays_seconds) + 1
        for attempt in range(1, attempts + 1):
            request = Request(
                url, headers={"Accept": "application/json"}
            )  # the instance's own base_url
            try:
                response = self._opener(request, self._timeout_seconds)
            except (URLError, TimeoutError, OSError) as error:
                # Connect-phase: the request never reached the configurator.
                if attempt < attempts:
                    _ = self._sleep(self._retry_delays_seconds[attempt - 1])
                    continue
                raise ConfiguratorError(
                    f"Could not connect to {url} after {attempts} attempts: {error}"
                ) from error
            status = _status_of(response)
            body = _read_body(response)
            if status != 200:
                raise ConfiguratorError(
                    f"Configurator returned HTTP {status} for {url}: {body}"
                )
            return body
        raise AssertionError("unreachable: the loop returns or raises")


def _read_body(response: object) -> str:
    stream = getattr(response, "read", None)
    if stream is None:
        return ""
    try:
        raw = cast("object", stream())
    finally:
        closer = getattr(response, "close", None)
        if closer is not None:
            closer()
    return raw.decode("utf-8") if isinstance(raw, bytes) else str(raw or "")


def _status_of(response: object) -> int | None:
    status = getattr(response, "status", None)
    return status if isinstance(status, int) else None


def parse_entry(
    value_text: str,
    *,
    configuration_code: str,
    hierarchy_node_code: str,
) -> tuple[dict[str, object] | None, str | None]:
    """The configuration's value parsed the notebook's way -- defensively. Returns
    (fields, skip_reason): the fields when active (None when skipped). Field names are
    matched case-insensitively; every field is read as text then converted by whoever
    binds it (the configurator can return numbers as strings, `"isActive": "true"`).
    An inactive entry -- or one without isActive, the company not being set up for the
    job -- is a valid skip, not an error; a field declared in the instance that the
    active entry lacks is a real failure (the notebook's `requiredField`)."""
    try:
        config = cast("object", json.loads(value_text))
    except json.JSONDecodeError as error:
        raise ValueError(
            f"{configuration_code} for {hierarchy_node_code} is not valid JSON: {error}"
        ) from error
    if not isinstance(config, dict):
        raise TypeError(
            f"{configuration_code} for {hierarchy_node_code} is not a JSON object"
        )
    entry = cast("dict[str, object]", config)
    fields = {str(key).lower(): value for key, value in entry.items()}

    def optional(name: str) -> str | None:
        value = fields.get(name.lower())
        if value is None:
            return None
        text = value if isinstance(value, str) else json.dumps(value)
        text = text.strip()
        return text or None

    def as_bool(name: str, text: str) -> bool:
        lowered = text.lower()
        if lowered not in {"true", "false"}:
            raise ValueError(
                f"{configuration_code} for {hierarchy_node_code} has an invalid {name}: '{text}'"
            )
        return lowered == "true"

    raw_active = optional("isActive")
    if raw_active is None:
        return None, f"{configuration_code} has no isActive"
    if not as_bool("isActive", raw_active):
        return None, f"{configuration_code} is inactive"
    return dict(entry), None


def required_fields(
    entry: Mapping[str, object],
    declared: Mapping[str, str],
    *,
    configuration_code: str,
    hierarchy_node_code: str,
) -> dict[str, str]:
    """The declared fields out of an active entry: each must be present (non-null,
    non-blank) when the entry is active -- the notebook's `requiredField`. Returns
    template-variable -> raw text (the value's conversion happens at bind time)."""
    fields = {str(key).lower(): value for key, value in entry.items()}
    resolved: dict[str, str] = {}
    for variable, key in declared.items():
        text = fields.get(key.lower())
        if text is None or (isinstance(text, str) and not text.strip()):
            raise ValueError(
                f"{configuration_code} for {hierarchy_node_code} is active but has no {key}"
            )
        resolved[variable] = text if isinstance(text, str) else json.dumps(text)
    return resolved
