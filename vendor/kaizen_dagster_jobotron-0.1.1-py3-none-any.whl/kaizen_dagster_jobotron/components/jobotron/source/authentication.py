"""How the component decides which Databricks workspace to reach, and as whom.

Two independent decisions, made in this order:

1. WHICH WORKSPACE (at load time, `resolve_workspace`). The component's `workspace`
   attribute is rendered by Dagster first, so `{{ env(...) }}` works. Then:
   a. a literal `https://...` host is used as is (direct construction, tests);
   b. otherwise the name is looked up in `databricks-workspaces.yaml` at the repository
      root, and the deployment picks the host: `production_host` when
      `DAGSTER_CLOUD_DEPLOYMENT_NAME` is `prd`, `staging_host` for anything else
      (including unset);
   c. a name that is not registered fails the load, listing the registered ones.

2. AS WHOM (at run time, `read_credentials`). The environment is read when a run
   starts -- never at import -- so a test can change it between calls. The three
   `MULTI_WORKSPACE_ARM_*` variables decide, and a blank value counts as unset:
   a. all three set  -> `ServicePrincipal`: the SDK's Azure client-secret flow, with
      `auth_type` pinned so a stray `DATABRICKS_TOKEN` / `DATABRICKS_HOST` cannot take
      over. This is what a deployment uses;
   b. none set       -> `AmbientCredentials`: the SDK's default credential chain,
      which in practice is the developer's own `databricks auth login` /
      `~/.databrickscfg`. The chain and its order belong to the SDK and are NOT pinned,
      so a `DATABRICKS_TOKEN` or `DATABRICKS_HOST` in the shell can win over the login;
   c. one or two set -> `ValueError` naming the variables (never the values): falling
      back silently would reach Databricks as someone the deployment did not intend.

Either kind of credential only ever reaches the Databricks API (`open_workspace_client`,
which the Statement Execution API call goes through). The component never reads storage:
it holds no storage credential and resolves no table location.

No Dagster resources anywhere.


Ported verbatim from the sibling wheel kaizen-dagster-delta-to-kafka, where this
exact module was reviewed and shipped; any difference is a bug here."""

import os
from collections.abc import Mapping
from pathlib import Path
from typing import ClassVar, cast

import yaml
from dagster import ComponentLoadContext, ResolutionContext
from databricks.sdk import WorkspaceClient
from databricks.sdk.core import Config
from pydantic import BaseModel, ConfigDict, Field

# --- as whom: the credential value types ----------------------------------------


class ServicePrincipal(BaseModel):
    """The Azure service principal a deployment reaches Databricks as.

    Three required fields rather than three optional ones, so a partially configured
    environment is unrepresentable here instead of re-checked by whoever reads it.
    """

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    tenant_id: str
    client_id: str
    # Out of the repr: a traceback formatter that renders locals prints reprs, and
    # the tenant and client IDs are what a reader debugs by anyway.
    client_secret: str = Field(repr=False)


class AmbientCredentials(BaseModel):
    """Nothing configured; the SDK's own chain decides.

    In practice this is local development, where `databricks auth login` or a
    `~/.databrickscfg` profile is what makes a workspace reachable at all.
    """

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)


type Credentials = ServicePrincipal | AmbientCredentials

REGISTRY_FILENAME = "databricks-workspaces.yaml"

# Where a Dagster workspace monorepo keeps it: the repository root, two levels above a
# `projects/<location>` project root -- and the same relative place in a deployed image,
# where each Dockerfile copies it beside `projects/`.
REGISTRY_RELATIVE_TO_PROJECT_ROOT = Path("..", "..", REGISTRY_FILENAME)


CREDENTIAL_NAMES = (
    "MULTI_WORKSPACE_ARM_TENANT_ID",
    "MULTI_WORKSPACE_ARM_CLIENT_ID",
    "MULTI_WORKSPACE_ARM_CLIENT_SECRET",
)


def read_credentials(env: Mapping[str, str]) -> Credentials:
    """Read the service principal from an environment, refusing a partial one.

    Takes the mapping rather than reading ``os.environ`` so the rule is a function of
    its argument; the one edge that samples the real environment is the publish asset.

    A partial set is refused rather than fallen back on, because the fallback is silent:
    two of the three present means a deployment intended this principal and would
    otherwise reach Databricks as whoever the ambient chain resolves to.
    """
    # A variable set to the empty string counts as unset: an injected secret that
    # resolved to nothing is not a credential, and carrying it on would reach Azure as
    # a blank client secret instead of naming what is missing here.
    configured = [name for name in CREDENTIAL_NAMES if env.get(name, "").strip()]
    match configured:
        case []:
            return AmbientCredentials()
        case [tenant_id_name, client_id_name, client_secret_name]:
            return ServicePrincipal(
                tenant_id=env[tenant_id_name],
                client_id=env[client_id_name],
                client_secret=env[client_secret_name],
            )
        case names:
            # The names only -- never a value, two of these three being secrets.
            raise ValueError(
                "Databricks service principal env vars must be configured together; "
                + f"found only {names}."
            )


# Bounds on one SDK request and on the SDK's own retries of it, so a run cannot hang on
# the SDK's much longer defaults.
SDK_HTTP_TIMEOUT_SECONDS = 60
SDK_RETRY_TIMEOUT_SECONDS = 60


def _config(host: str, credentials: Credentials) -> Config:
    """The SDK config for one workspace with the credentials given.

    ``auth_type`` is pinned for the principal rather than left to the default chain,
    which tries Databricks native authentication first: a ``DATABRICKS_TOKEN`` or
    ``DATABRICKS_HOST`` in the environment would otherwise be offered in its place.
    """
    match credentials:
        case AmbientCredentials():
            return Config(
                host=host,
                http_timeout_seconds=SDK_HTTP_TIMEOUT_SECONDS,
                retry_timeout_seconds=SDK_RETRY_TIMEOUT_SECONDS,
            )
        case ServicePrincipal() as principal:
            return Config(
                host=host,
                auth_type="azure-client-secret",
                azure_tenant_id=principal.tenant_id,
                azure_client_id=principal.client_id,
                azure_client_secret=principal.client_secret,
                http_timeout_seconds=SDK_HTTP_TIMEOUT_SECONDS,
                retry_timeout_seconds=SDK_RETRY_TIMEOUT_SECONDS,
            )


def open_workspace_client(host: str, credentials: Credentials) -> WorkspaceClient:
    """An SDK client for one workspace: what the statement runner executes through."""
    try:
        return WorkspaceClient(config=_config(host, credentials))
    except ValueError as error:
        raise ValueError(_unauthenticated_message(host, credentials, error)) from error


def _unauthenticated_message(
    host: str, credentials: Credentials, error: ValueError
) -> str:
    """Say why no client could be had, and what the reader can do about it."""
    match credentials:
        case AmbientCredentials():
            return (
                f"Could not authenticate to Databricks workspace {host} with the SDK's "
                + f"default credential chain. Run `databricks auth login --host {host}`, "
                + f"or set {', '.join(CREDENTIAL_NAMES)} for the service principal."
            )
        case ServicePrincipal():
            return (
                "The service principal could not authenticate to Databricks workspace "
                + f"{host}: {error}"
            )


# --- the workspace registry -----------------------------------------------------


def load_workspace_registry(path: Path) -> dict[str, dict[str, object]]:
    """The parsed contents of a databricks-workspaces.yaml file."""
    try:
        parsed = cast(object, yaml.safe_load(path.read_text()))
    except OSError as e:
        raise ValueError(
            f"Could not read Databricks workspace registry at {path}: {e}"
        ) from e
    parsed_dict = (
        cast("dict[object, object]", parsed) if isinstance(parsed, dict) else None
    )
    workspaces = parsed_dict.get("workspaces") if parsed_dict is not None else None
    if not isinstance(workspaces, dict):
        raise TypeError(
            f"Databricks workspace registry at {path} has no `workspaces` mapping"
        )
    return cast("dict[str, dict[str, object]]", workspaces)


def _deployment() -> str:
    """The deployment this code location is running as (staging unless said otherwise)."""
    return os.environ.get("DAGSTER_CLOUD_DEPLOYMENT_NAME", "stg")


def workspace_host(
    registry: dict[str, dict[str, object]], name: str, deployment: str
) -> str:
    """A registered workspace name and a deployment -> the workspace's host URL."""
    entry = registry.get(name)
    if entry is None:
        raise ValueError(
            f"Unknown Databricks workspace {name!r}. Registered: "
            + f"{sorted(registry)}. Add the workspace to databricks-workspaces.yaml, "
            + "or name one of those."
        )
    key = "production_host" if deployment == "prd" else "staging_host"
    host = entry.get(key, "")
    if not isinstance(host, str) or not host:
        raise ValueError(f"Registered Databricks workspace {name!r} has no {key}")
    return host


def _registry_path(context: ResolutionContext) -> Path:
    """The registry file the load's project root implies."""
    project_root = ComponentLoadContext.from_resolution_context(context).project_root
    return Path(project_root) / REGISTRY_RELATIVE_TO_PROJECT_ROOT


def resolve_workspace(context: ResolutionContext, name: str) -> str:
    """Resolve the component's `workspace` attribute to the host URL statements are sent to.

    Dagster renders the field before calling this, so `{{ env(...) }}` keeps working.
    A registered name is looked up in the repository's registry, in the deployment
    this code location is running as. A literal `https://` host is passed through --
    the escape hatch a direct (non-YAML) construction uses, tests included; a name
    that resolves through the registry stays the reviewed path for every `defs.yaml`.
    """
    if name.startswith("https://"):
        return name
    return workspace_host(
        load_workspace_registry(_registry_path(context)), name, _deployment()
    )
