"""The one place a statement result becomes Arrow: the manifest's declared column types
give the Arrow schema, and each cell -- which the JSON_ARRAY wire renders as a string --
is read back as the type its column declares.

| Databricks type                  | Arrow type              | Python value        |
| -------------------------------- | ----------------------- | ------------------- |
| BYTE, SHORT, INT, LONG           | int8, int16, int32, int64 | int               |
| FLOAT, DOUBLE                    | float64                 | float               |
| DECIMAL(p, s)                    | decimal128(p, s)        | Decimal (exact)     |
| BOOLEAN                          | bool                    | bool                |
| DATE                             | date32                  | date                |
| TIMESTAMP                        | timestamp(us, UTC)      | aware datetime      |
| TIMESTAMP_NTZ (by `type_text`)   | timestamp(us)           | naive datetime      |
| BINARY                           | binary (base64 on wire) | bytes               |
| everything else (STRING, CHAR, ARRAY, MAP, STRUCT, INTERVAL, ...) | string | the text as sent |

FLOAT is read as float64 as well: a float32 would print as `0.10000000149011612` for the
`0.1` the warehouse sent. A cell that cannot be read as its declared type fails the run
naming the row and the column, never the value: rows are often customer data.


Ported verbatim from the sibling wheel kaizen-dagster-delta-to-kafka, where this
exact module was reviewed and shipped; any difference is a bug here."""

import base64
from collections.abc import Callable, Sequence
from datetime import UTC, date, datetime
from decimal import Decimal

import pyarrow as pa
from databricks.sdk.service.sql import (
    ColumnInfo,
    ColumnInfoTypeName,
    StatementResponse,
)

type Parse = Callable[[str], object]


def _boolean(value: str) -> bool:
    lowered = value.strip().lower()
    if lowered not in {"true", "false"}:
        raise ValueError("not a boolean")
    return lowered == "true"


def _timestamp(value: str) -> datetime:
    """A TIMESTAMP is an instant: the warehouse sends it in UTC, and a zone-less value is
    taken as UTC."""
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _timestamp_ntz(value: str) -> datetime:
    """A TIMESTAMP_NTZ is a wall-clock reading with no zone, and stays that way."""
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed
    return parsed.astimezone(UTC).replace(tzinfo=None)


def _type_text(column: ColumnInfo) -> str:
    return column.type_text or (column.type_name.value if column.type_name else "")


def _typed(column: ColumnInfo) -> tuple[pa.DataType, Parse | None]:
    """The Arrow type a column's declared type maps to, and how to read one of its cells.
    No parser means the text is kept as it was sent."""
    match column.type_name:
        case ColumnInfoTypeName.BYTE:
            return pa.int8(), int
        case ColumnInfoTypeName.SHORT:
            return pa.int16(), int
        case ColumnInfoTypeName.INT:
            return pa.int32(), int
        case ColumnInfoTypeName.LONG:
            return pa.int64(), int
        case ColumnInfoTypeName.FLOAT | ColumnInfoTypeName.DOUBLE:
            return pa.float64(), float
        case ColumnInfoTypeName.DECIMAL:
            if column.type_precision is None or column.type_scale is None:
                raise ValueError(
                    f"Column {column.name!r} is a DECIMAL without a precision and scale"
                )
            return pa.decimal128(column.type_precision, column.type_scale), Decimal
        case ColumnInfoTypeName.BOOLEAN:
            return pa.bool_(), _boolean
        case ColumnInfoTypeName.DATE:
            return pa.date32(), date.fromisoformat
        case ColumnInfoTypeName.TIMESTAMP:
            if _type_text(column).upper().startswith("TIMESTAMP_NTZ"):
                return pa.timestamp("us"), _timestamp_ntz
            return pa.timestamp("us", tz="UTC"), _timestamp
        case ColumnInfoTypeName.BINARY:
            return pa.binary(), lambda value: base64.b64decode(value, validate=True)
        case _:
            return pa.string(), None


def _columns(response: StatementResponse) -> Sequence[ColumnInfo]:
    manifest = response.manifest
    schema = manifest.schema if manifest is not None else None
    columns = (schema.columns if schema is not None else None) or []
    for position, column in enumerate(columns):
        if not column.name:
            raise ValueError(f"Result column {position} has no name")
    return columns


def schema_of(response: StatementResponse) -> pa.Schema:
    """The Arrow schema of a statement's result: column names, order and types from the
    manifest, so even an empty result carries the names for the contract check."""
    return pa.schema(
        [(column.name or "", _typed(column)[0]) for column in _columns(response)]
    )


def record_batch(
    response: StatementResponse,
    rows: Sequence[Sequence[str | None]],
    first_row_number: int = 1,
) -> pa.RecordBatch:
    """One chunk of a statement's rows as a record batch of `schema_of(response)`, cells
    read back from their wire strings. `first_row_number` is the 1-based number of the
    chunk's first row in the whole result, so an error names the row as the query
    returned it."""
    columns = _columns(response)
    for number, row in enumerate(rows, start=first_row_number):
        if len(row) != len(columns):
            raise ValueError(
                f"Row {number} has {len(row)} value(s) for {len(columns)} column(s)"
            )

    names: list[str] = []
    arrays: list[pa.Array[pa.Scalar[pa.DataType]]] = []
    for position, column in enumerate(columns):
        name = column.name or ""
        arrow_type, parse = _typed(column)
        values: list[object] = []
        for number, row in enumerate(rows, start=first_row_number):
            cell = row[position]
            if cell is None or parse is None:
                values.append(cell)
                continue
            try:
                values.append(parse(str(cell)))
            except ValueError, ArithmeticError:
                # `from None`: the chained error would quote the value.
                raise ValueError(
                    f"Row {number}, column {name!r}: not a valid {_type_text(column)} value"
                ) from None
        try:
            arrays.append(pa.array(values, type=arrow_type))  # pyright: ignore[reportUnknownMemberType] -- pyarrow-stubs' overloads of `pa.array` are partly unknown
        except pa.ArrowInvalid, pa.ArrowTypeError, OverflowError:
            raise ValueError(
                f"Column {name!r}: values do not fit {_type_text(column)}"
            ) from None
        names.append(name)
    return pa.RecordBatch.from_arrays(arrays, names=names)  # pyright: ignore[reportUnknownMemberType] -- pyarrow-stubs leave the array type partly unknown
