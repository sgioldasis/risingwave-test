"""Everything that reaches the source: who we are on Databricks (`authentication`), how a
statement runs (`statement_execution`) and the query's rows as one Arrow table (`rows`)."""
