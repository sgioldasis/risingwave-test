"""The Jobotron envelope: the 13-field message every Jobotron Worker parses. This module
is the port of the KYC notebooks' shared publisher (kafka_message_publisher.ipynb) --
the notebooks are the spec, and the compatibility guarantee to the Workers is
byte-for-byte: a Worker must not be able to tell a component message from a notebook
one.

The notebook's Spark, and what this module does instead:

| notebook (Scala)                                         | here                                    |
| -------------------------------------------------------- | --------------------------------------- |
| `to_json(..., ignoreNullFields = false)`                  | `canonical_json` (sink/encoding.py): compact separators, the struct's field order, nulls explicit, non-ASCII as-is |
| `sha2(to_json(col("ItemPayload"), JsonOptions), 256)`     | sha2-256 of `canonical_json(payload)`   |
| `row_number().over(Window.orderBy("CustomerId"))`         | rows sorted by `CustomerId` (stable sort), numbered from 1 |
| `snapshot.localCheckpoint()` + `count()`                  | the whole result set materialized once: `ItemsCount` and every `ItemNumber` come from the same read |
| `concat_ws("_", lit(jobName), col("CompanyId"), lit(jobDateTime))` | `job_name_companyId_yyyyMMddHHmmss` (UTC) |
| `lit(jobCreated.toString)` (a second-truncated `Instant`) | `YYYY-MM-DDTHH:MM:SSZ`                  |
| `col("CustomerId").cast(StringType).as("key")`            | the key is the stringified `CustomerId` |

Field order in the value is the notebook's `select` order -- Workers may not care, but
byte-for-byte means the bytes match, so the envelope dict is built in exactly that
order. Proven against a live specimen captured from `kyc.jobs.br` (2026-11-12): its
`ItemPayloadHash` is `sha2-256` of the payload's compact JSON with the fields in query
order, ints inline.
"""

from collections.abc import Mapping
from datetime import UTC, datetime
from hashlib import sha256

from ..sink.encoding import canonical_json
from .messages import RunInfo

# The notebook's `val SchemaVersion = 1`; the instance bumps it on a contract extension.
NOTEBOOK_SCHEMA_VERSION = 1

# The instant format the notebook's `Instant.toString` yields for a second-truncated
# instant: ISO-8601 in UTC with a `Z`, no fractional seconds.
JOB_CREATED_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

# The `JobId`'s timestamp: the same instant as JobCreated, in the notebook's
# `yyyyMMddHHmmss` (UTC) spelling.
JOB_DATE_TIME_FORMAT = "%Y%m%d%H%M%S"

# The value's field order: the notebook publisher's `select`, verbatim. The envelope
# dict is built in this order because byte-for-byte is the guarantee.
ENVELOPE_FIELDS: tuple[str, ...] = (
    "JobId",
    "JobName",
    "JobCreated",
    "RunId",
    "CompanyId",
    "CustomerId",
    "ItemsCount",
    "ItemNumber",
    "ItemId",
    "ItemPayload",
    "ItemPayloadHash",
    "IsDryRun",
    "SchemaVersion",
)


def job_created_of(created: datetime) -> str:
    """The run's start as the envelope's `JobCreated`: second-truncated UTC (`Z`)."""
    return created.astimezone(UTC).strftime(JOB_CREATED_FORMAT)


def payload_hash(payload: Mapping[str, object]) -> str:
    """`sha2(to_json(ItemPayload, ignoreNullFields=false), 256)`: the hash of the
    payload's canonical JSON -- compact, field order as the query returned the columns,
    nulls explicit."""
    return sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def job_id_of(job_name: str, company_id: int, created: datetime) -> str:
    """`concat_ws("_", lit(jobName), col("CompanyId"), lit(jobDateTime))`."""
    job_date_time = created.astimezone(UTC).strftime(JOB_DATE_TIME_FORMAT)
    return f"{job_name}_{company_id}_{job_date_time}"


class EnvelopeBuilder:
    """Builds one company's envelope messages from one statement's rows. One instance
    per company per run: `ItemsCount` is the row count of the read the messages come
    from, and the run identity (`JobCreated`, `RunId`, `IsDryRun`) is the same on every
    message of the company's batch, exactly as the notebook stamps one snapshot."""

    def __init__(
        self,
        *,
        job_name: str,
        company_id: int,
        schema_version: int = NOTEBOOK_SCHEMA_VERSION,
    ) -> None:
        if not job_name.strip():
            raise ValueError("job_name must not be blank")
        self._job_name: str = job_name
        self._company_id: int = company_id
        self._schema_version: int = schema_version

    def build(
        self,
        rows: list[dict[str, object]],
        *,
        run: RunInfo,
    ) -> list[dict[str, object]]:
        """The rows of one statement's read as envelope payloads, in the notebook's
        field order. Rows are ordered by `CustomerId` (the notebook's
        `Window.orderBy("CustomerId")`), so `ItemNumber` is stable across reruns of the
        same input; `ItemsCount` is the count of the same read. The `CustomerId` column
        must exist and be non-null (it is the envelope's identity in two places: the
        field and the Kafka key)."""
        customer_column = "CustomerId"
        for number, row in enumerate(rows, start=1):
            if customer_column not in row:
                raise ValueError(
                    f"Row {number} has no {customer_column} column -- the envelope's "
                    + f"identity needs it (found {sorted(row)})"
                )
            if row[customer_column] is None:
                raise ValueError(
                    f"Row {number} has a null {customer_column} -- the envelope's "
                    + "identity cannot be null"
                )
        ordered = sorted(rows, key=_customer_order)
        items_count = len(ordered)
        job_created = job_created_of(run.created)
        job_id = job_id_of(self._job_name, self._company_id, run.created)
        envelopes: list[dict[str, object]] = []
        for item_number, row in enumerate(ordered, start=1):
            item_payload_hash = payload_hash(row)
            envelopes.append(
                {
                    "JobId": job_id,
                    "JobName": self._job_name,
                    "JobCreated": job_created,
                    "RunId": run.run_id,
                    "CompanyId": self._company_id,
                    "CustomerId": row[customer_column],
                    "ItemsCount": items_count,
                    "ItemNumber": item_number,
                    "ItemId": f"{item_payload_hash}-{item_number}",
                    "ItemPayload": row,
                    "ItemPayloadHash": item_payload_hash,
                    "IsDryRun": run.dry_run,
                    "SchemaVersion": self._schema_version,
                }
            )
        return envelopes


def _customer_order(row: dict[str, object]) -> tuple[int, float | str]:
    """Rows sort by `CustomerId` as the notebook's window orders them -- numerically
    when the column is numeric, lexicographically otherwise. The tuple's first element
    keeps the two kinds comparable (the queries return one column type; a mixed column
    would sort in two blocks rather than fail)."""
    value = row["CustomerId"]
    return (0, value) if isinstance(value, int | float) else (1, str(value))
