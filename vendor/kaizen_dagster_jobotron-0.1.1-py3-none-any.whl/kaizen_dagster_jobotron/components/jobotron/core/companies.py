"""The company identity and its enumeration: the notebooks' `companies.ipynb`.

Every fan-out run enumerates the companies from `de.metadatadb.mcompany` (minus the
static inactive list), and each company's `comCode` is what the configurator is asked
with and what routes its topic (`kyc.jobs.<first two chars of comCode, lowercased>` --
the notebook's `getTopic`).

The enumeration is a statement like any other: bound parameters for the include/exclude
lists, the table name whitelist-checked and substituted (identifiers cannot be bound).
The lists name companies either by id (ints) or by their exact comCode (strings,
compared case-insensitively) -- never a mix, and never a comCode prefix (codes share
prefixes across markets: `DE` would prune both DEBTN and DEKSN).
"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from ..source.statement_execution import StatementParameterListItem
from .template import BoundStatement, bind_parameter, validate_table_name

CompanyKey = int | str
"""How an instance names a company: its numeric id, or its exact comCode."""


@dataclass(frozen=True)
class Company:
    """One active company: the id that prunes the query and the code that routes it."""

    company_id: int
    com_code: str

    @property
    def market_code(self) -> str:
        """`getTopic(comCode)`: `kyc.jobs.` + the first two characters, lowercased."""
        return self.com_code[:2].lower()

    def matches(self, key: CompanyKey) -> bool:
        """Does this company answer to the instance's key: the id, or the comCode
        case-insensitively (the yaml's `CYSTX` and the table's `CYSTX` agree)."""
        if isinstance(key, int):
            return self.company_id == key
        return self.com_code.lower() == key.lower()


def companies_statement(
    *,
    source_table: str,
    include: Sequence[CompanyKey] | None = None,
    exclude: Sequence[CompanyKey] | None = None,
) -> BoundStatement:
    """The enumeration statement: `CompanyId` and `comCode` for the companies the
    instance wants, in id order (the notebooks' `order by comCompanyID`)."""
    table = validate_table_name(source_table, "companies.source")
    clauses: list[str] = []
    parameters: list[StatementParameterListItem] = []
    if include is not None:
        clauses.append(_key_list("in", include, parameters))
    if exclude:
        clauses.append(_key_list("not in", exclude, parameters))
    where = f" where {' and '.join(clauses)}" if clauses else ""
    sql = (
        f"select cast(comCompanyID as int) as CompanyId, comCode from {table}{where} "
        + "order by comCompanyID"
    )
    return BoundStatement(sql, parameters)


def _key_list(
    operator: str,
    keys: Sequence[CompanyKey],
    parameters: list[StatementParameterListItem],
) -> str:
    """`comCompanyID <op> (:id_1, ...)` or `lower(comCode) <op> (...)`, each key
    bound. The two shapes cannot mix in one list: an int is an id, a str is a code,
    and a list that straddles the two would silently depend on column-choice order."""
    if not keys:
        raise ValueError("An include/exclude company list must not be empty")
    by_id = all(isinstance(key, int) for key in keys)
    by_code = all(isinstance(key, str) for key in keys)
    if not (by_id or by_code):
        raise ValueError(
            "An include/exclude company list is either all ids (ints) or all exact "
            + "comCodes (strings) -- mixing them is ambiguous"
        )
    column = "comCompanyID" if by_id else "lower(comCode)"
    markers: list[str] = []
    for index, key in enumerate(keys, start=1):
        value = key if by_id else str(key).lower()
        parameters.append(bind_parameter(f"id_{index}", value))
        markers.append(f":id_{index}")
    return f"{column} {operator} ({', '.join(markers)})"


def parse_companies(rows: Sequence[Mapping[str, object]]) -> list[Company]:
    """The enumeration's rows as companies. A null comCode is refused: it would route
    the topic badly (`kyc.jobs.no`-shaped nonsense or a silent wrong topic)."""
    companies: list[Company] = []
    for row in rows:
        company_id = row.get("CompanyId")
        com_code = row.get("comCode")
        if company_id is None or com_code is None:
            raise ValueError(
                "The company enumeration returned a row without CompanyId or comCode: "
                + "check the companies.source table's columns"
            )
        companies.append(Company(int(str(company_id)), str(com_code)))
    return companies
