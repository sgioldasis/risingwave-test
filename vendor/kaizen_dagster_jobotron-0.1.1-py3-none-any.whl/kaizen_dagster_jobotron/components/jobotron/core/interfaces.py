"""The seams the publish pipeline is written against: where rows come from, how a read
becomes records, how a record becomes a message, where messages go.

`PublishPipeline` depends on these and on nothing concrete, so a different source or
sink is a new class that satisfies one of them, and the pipeline's tests need neither
Databricks nor Kafka. The implementations live beside what they reach (`source/`,
`sink/`); `runtime/factory.py` is the one place that picks them.

Adapted from the sibling wheel's seams in two places, for the Jobotron shape:
`MessageFormat.shape` receives the whole read (the envelope needs the materialized
snapshot -- `ItemsCount` and every `ItemNumber` from one query run, the notebook's
`localCheckpoint()`), and `MessageSink.publish` takes the topic (a fan-out run routes
each company's batch to its own topic).
"""

from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

import pyarrow as pa

from .messages import KafkaMessage, MessageIdentity, Record, RunInfo


@dataclass(frozen=True)
class RowStream:
    """What a source read: the result's schema, its rows as an iterator of record batches,
    and facts about the read for the run's metadata (which warehouse, how long it took).

    The schema is known before any row is read. The batches are read as the iterator is
    advanced, and the source checks the result is complete when the iterator runs out:
    whoever must not act on a partial result consumes every batch first."""

    schema: pa.Schema
    batches: Iterator[pa.RecordBatch]
    metadata: Mapping[str, object] = field(default_factory=dict[str, object])


class RowSource(Protocol):
    """Where the rows come from. The iterator of a read yields every row of the result and
    then ends, or raises: a partial result is never passed off as a whole one."""

    def read(self) -> RowStream: ...


@runtime_checkable
class MessageFormat(Protocol):
    """One way of turning a read into records. The format models in the sink package
    satisfy it structurally; they are also the YAML's `message` section."""

    def check_schema(self, schema: pa.Schema) -> None:
        """Refuse a result whose columns the format cannot use, before any row is read."""
        ...

    def shape(
        self, batches: Iterator[pa.RecordBatch], run: RunInfo, identity: MessageIdentity
    ) -> list[Record]:
        """The read's rows as records, in the format's own order. The iterator must be
        consumed fully -- the source's completeness check fires as it ends -- so a
        partial result never becomes messages. `identity` is whose messages these are
        (the envelope stamps it in; the plain format ignores it)."""
        ...


class MessageSerializer(Protocol):
    """How a record and the run's metadata fields become one message on the wire."""

    def serialize(
        self, record: Record, extra: Mapping[str, object]
    ) -> KafkaMessage: ...


class MessageSink(Protocol):
    """Where the messages go. `publish` returns once every message is acknowledged and
    raises if any was rejected or is still undelivered."""

    def publish(self, topic: str, messages: Sequence[KafkaMessage]) -> None: ...
