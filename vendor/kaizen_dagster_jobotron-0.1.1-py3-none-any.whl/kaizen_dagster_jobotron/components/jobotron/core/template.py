"""The query template and its bindings: how a `{placeholder}` becomes SQL.

One hard rule, from the notebooks' own hazard: values are bound through the Statement
Execution API's parameters array, never interpolated into the SQL text. The notebooks
interpolated configuration values straight into SQL strings; here every `{name}` in a
value position becomes a `:name` marker with a bound parameter.

The exception is declared `literal` variables: Spark parameter markers cannot sit in
every syntactic position -- a table name (`de.voperdb_{market}`) or an interval literal
(`interval {days_countdown} days`) is not a value slot. A variable the instance declares
in `literal_parameters` is substituted as text, but only after the whitelist check:
`^[A-Za-z0-9_]+$`. Such a value cannot carry SQL syntax (no spaces, quotes, parens,
comments), whatever its source -- the whitelist is the boundary, not trust in the
author. An undeclared variable always binds.
"""

import re
from collections.abc import Mapping, Sequence
from typing import cast, override

from ..source.statement_execution import (
    StatementParameterListItem,
    bind_parameter,
)

# `bind_parameter` arrives here from the statement-execution layer; listed so the
# companies and runtime modules can import it through this one.
__all__ = ["bind_parameter"]

# A template placeholder: `{name}`, lower-snake-case, like the notebook's own spelling
# of companyId in the interpolated SQL.
PLACEHOLDER_PATTERN = re.compile(r"\{([a-z_][a-z0-9_]*)\}")

# The whitelist a substituted literal must pass: identifier- or integer-shaped, so no
# SQL syntax can hide in it (spaces, quotes, parens, dashes and semicolons all fail).
LITERAL_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")

# A source table name, as the notebook's `de.metadatadb.mcompany`: segments of the same
# charset joined by dots.
TABLE_PATTERN = re.compile(r"^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)*$")


def placeholders(text: str) -> list[str]:
    """The template's placeholders, in order, duplicates included."""
    return PLACEHOLDER_PATTERN.findall(text)


def validate_table_name(name: str, attribute: str) -> str:
    """A source table name from the YAML: whitelist-checked, since it is substituted
    into the enumeration SQL verbatim (identifiers cannot be bound)."""
    if not TABLE_PATTERN.match(name):
        raise ValueError(
            f"{attribute} must be a qualified table name (catalog.schema.table), "
            + f"letters/digits/underscores only; got {name!r}"
        )
    return name


def validate_literal(name: str, value: object) -> str:
    """The whitelist a substituted literal must pass. Failing names the template
    variable and the value: the author has to see which config entry was refused."""
    text = value if isinstance(value, str) else str(value)
    if not LITERAL_PATTERN.match(text):
        raise ValueError(
            f"Literal parameter {name!r} must match {LITERAL_PATTERN.pattern} "
            + f"(no spaces, quotes or SQL punctuation); got {value!r}"
        )
    return text


class BoundStatement:
    """A template with its placeholders resolved: the SQL text (markers in, no raw
    values) and the parameters array to submit with it."""

    def __init__(self, sql: str, parameters: list[StatementParameterListItem]) -> None:
        self.sql: str = sql
        self.parameters: list[StatementParameterListItem] = parameters

    @override
    def __repr__(self) -> str:
        names = [parameter.name for parameter in self.parameters]
        return f"BoundStatement({len(names)} bound: {names})"


def bind(
    template: str,
    values: Mapping[str, object],
    literals: Mapping[str, object] | None = None,
) -> BoundStatement:
    """Resolve the template's placeholders and return the statement to submit.

    Every undeclared `{name}` must have exactly one value and becomes a `:name` marker
    bound to it: a scalar binds as one parameter; a comma-separated string or a YAML
    list expands to one parameter per element (`not in ({excluded_types})` works with
    `excluded_types: [2, 5, 6, 10, 11]`). A declared literal is whitelist-validated and
    substituted as text instead. A value with no placeholder in the template is fine
    (a configurator entry can carry more than the query uses). A placeholder used twice
    binds once."""
    literals = literals or {}
    parameters: list[StatementParameterListItem] = []
    sql = template

    for name in dict.fromkeys(placeholders(template)):
        if name in literals:
            sql = sql.replace(f"{{{name}}}", validate_literal(name, literals[name]))
            continue
        if name not in values:
            raise ValueError(
                f"Template placeholder {{{name}}} has no value -- every placeholder "
                + "needs exactly one source"
            )
        value = values[name]
        elements = _elements(value, name)
        markers: list[str] = []
        for index, element in enumerate(elements, start=1):
            marker = name if len(elements) == 1 else f"{name}_{index}"
            parameters.append(bind_parameter(marker, element))
            markers.append(f":{marker}")
        sql = sql.replace(f"{{{name}}}", ", ".join(markers))

    return BoundStatement(sql, parameters)


def _elements(value: object, name: str) -> list[int | str]:
    """One bindable value or a list of them. A comma-separated string splits (the
    notebooks' `not in` lists arrive that way from YAML); an empty list is refused --
    `in ()` is not SQL."""
    if isinstance(value, list | tuple):
        # YAML gives lists, pydantic tuples: either way a sequence of scalars.
        items = cast("Sequence[object]", value)
        if not items:
            raise ValueError(
                f"Parameter {name!r} is an empty list -- `in ()` is not SQL"
            )
        return [_element(item, name) for item in items]
    if isinstance(value, str) and "," in value:
        # The notebooks' `not in` lists arrive from YAML as a comma-separated string
        # ("2, 5, 6, 10, 11"): split and bind each element.
        return [_element(item.strip(), name) for item in value.split(",")]
    return [_element(value, name)]


def _element(value: object, name: str) -> int | str:
    if isinstance(value, bool | int | str):
        return value
    raise ValueError(
        f"Parameter {name!r} has a {type(value).__name__} element; bindable values are int or str"
    )


def render_topic(spec: str, values: Mapping[str, object]) -> str:
    """The topic template for one company (`kyc.jobs.{com_code}`): every placeholder is
    substituted after the same whitelist check as a literal -- a topic name is not SQL,
    so nothing is bound, and a value with SQL-ish characters in it is refused instead
    of published-to."""
    for name in dict.fromkeys(placeholders(spec)):
        if name not in values:
            raise ValueError(f"Topic placeholder {{{name}}} has no value")
        spec = spec.replace(f"{{{name}}}", validate_literal(name, values[name]))
    return spec
