"""The parameter algebra: which values a company's statement is bound with, and whether
the company runs at all.

The variants differ only in how parameters resolve, so that is a small set of
composable resolvers, each producing values for the template's `{placeholders}`, in a
fixed order (each may consume the previous layer's variables):

| resolver        | produces                        | notebook origin |
| --------------- | ------------------------------- | --------------- |
| run anchor      | `{run_id}`, `{run_ts}`, `{created_from}` | the `createdFrom` invariant |
| static          | `parameters` constants, all companies | variant A/C/D literals |
| per-company     | `parameters_by_company[id or comCode]` | the cy/gr/ro trio's 4-line differences |
| configurator    | per-company values from its config entry | `configurator_client.ipynb` |
| group lookup    | `{group_id}` from a code-valued variable | `groups.ipynb` |

`company_id` and `com_code` come from the company identity itself (the enumeration).

Two load-time rules live here as checks the config runs once: a variable must have
exactly one source (two resolvers producing the same name is an authoring conflict),
and a template placeholder must have a source. A configurator entry that is inactive --
or has no isActive -- is a *valid skip*, not an error (the notebook's `Left(reason)`):
the partition materializes as a no-op success with the reason in its metadata.
"""

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from .messages import RunInfo


@dataclass(frozen=True)
class Resolution:
    """One company's resolved bindings. `values` maps template variables to scalars or
    lists; `skip_reason` is set (and `values` irrelevant) when the company is a valid
    skip -- an inactive configurator entry, the notebook's `Left(reason)`."""

    values: Mapping[str, object]
    skip_reason: str | None = None

    @property
    def skipped(self) -> bool:
        return self.skip_reason is not None


def run_anchor(run: RunInfo) -> dict[str, object]:
    """The run-scoped variables: one value per run, even across a midnight-crossing
    one. `created_from` is the start of yesterday, UTC -- the notebooks' `createdFrom`
    (`ccgCreated >= createdFrom` reads exactly the group memberships made yesterday and
    today). `run_ts` is the run's own start, the `JobCreated` instant."""
    created = run.created.astimezone(UTC)
    start_of_yesterday = (created - timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    return {
        "run_id": run.run_id,
        "run_ts": created.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "created_from": start_of_yesterday.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def check_single_sources(
    static: Mapping[str, object],
    per_company: Mapping[int | str, Mapping[str, object]],
    configurator_fields: Mapping[str, str],
    group_lookup_code: str | None,
) -> None:
    """The one-source rule across the resolvers: a variable two of them would produce is
    an authoring conflict, refused when the instance loads. `per_company` is checked
    across companies too -- the same variable meaning different things per company and
    statically is exactly the ambiguity the rule forbids."""
    seen: dict[str, str] = {}
    for name in static:
        _ = seen.setdefault(name, "parameters")
    # Across companies the same variable is the point (market is cy for one, gr for
    # another); the conflict is with a *different* resolver, so the union is what
    # competes for a source.
    per_company_names: set[str] = set()
    for company_values in per_company.values():
        per_company_names.update(company_values)
    for name in per_company_names:
        if name in seen:
            raise ValueError(
                f"Template variable {name!r} has two sources: {seen[name]} and "
                + "parameters_by_company"
            )
        seen[name] = "parameters_by_company"
    for variable in configurator_fields:
        if variable in seen:
            raise ValueError(
                f"Template variable {variable!r} has two sources: {seen[variable]} and "
                + "the configurator"
            )
        seen[variable] = "configurator"
    if group_lookup_code is not None:
        produced = "group_id"
        if produced in seen:
            raise ValueError(
                f"Template variable {produced!r} has two sources: {seen[produced]} "
                + "and the group lookup"
            )
        if group_lookup_code not in seen:
            raise ValueError(
                f"The group lookup resolves {group_lookup_code!r}, which no earlier "
                + "resolver produces (static, per-company or the configurator)"
            )


def resolve_company(
    *,
    company_id: int,
    com_code: str,
    run: RunInfo,
    static: Mapping[str, object] | None = None,
    per_company: Mapping[str, object] | None = None,
    configurator: Mapping[str, str] | None = None,
    configurator_skip: str | None = None,
    group_lookup_code: str | None = None,
    group_id_of: Callable[[str], int] | None = None,
) -> Resolution:
    """One company's values, in the fixed order. The configurator is handed in already
    fetched and parsed (its I/O is the caller's seam): `configurator_skip` carries the
    notebook's `Left(reason)` -- an inactive entry, or none at all. The group lookup
    consumes the code-valued variable an earlier resolver produced and binds
    `{group_id}`; 0 or >1 matches fails the company, as the notebook's `require` does."""
    values: dict[str, object] = {
        "company_id": company_id,
        "com_code": com_code,
        # The notebook's getTopic: the topic key is the comCode's first two
        # characters, lowercased (`kyc.jobs.gr` for GRSTX). The configurator, by
        # contrast, is asked with the full comCode -- hence two variables.
        "market_code": com_code[:2].lower(),
        **run_anchor(run),
    }
    if configurator_skip is not None:
        return Resolution(values={}, skip_reason=configurator_skip)
    values.update(static or {})
    values.update(per_company or {})
    if configurator is not None:
        values.update(configurator)
    if group_lookup_code is not None:
        code = values[group_lookup_code]
        if not isinstance(code, str):
            raise ValueError(
                f"The group lookup resolves {group_lookup_code!r}, which must be a "
                + f"string group code; got {type(code).__name__}"
            )
        if group_id_of is None:
            raise ValueError("A group lookup needs the mgroup seam (group_id_of)")
        values["group_id"] = group_id_of(code)
    return Resolution(values=values)


def start_of_yesterday_utc(now: datetime | None = None) -> datetime:
    """The notebooks' `createdFrom`: midnight UTC at the start of yesterday."""
    created = (now or datetime.now(UTC)).astimezone(UTC)
    return (created - timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
