"""The publish pipeline for one company: read the bound statement's rows, shape them
into messages, publish them to the company's topic.

It knows no Databricks, no Kafka and no Dagster: it is written against the interfaces
(`interfaces.py`), and `runtime/factory.py` supplies the implementations. Whether a dry
run publishes is the format mode's business, decided once at construction:
the notebooks' dry run *publishes* with `IsDryRun: true` and the Worker no-ops it (the
captured specimen proves the wire behavior), so the envelope mode always sinks and the
mode lives in the message. The plain-JSON mode has no such field: there a dry run
builds everything and sends nothing, exactly the sibling wheel's semantics. Either way
nothing is published until every message exists, and an empty result publishes nothing
(the notebook's `if (messagesCount > 0)`).
"""

import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass

from .interfaces import MessageFormat, MessageSerializer, MessageSink, RowSource
from .message_metadata import metadata_fields
from .messages import KafkaMessage, MessageIdentity, MetadataField, RunInfo
from .template import BoundStatement


@dataclass(frozen=True)
class PublishResult:
    """What one company's publish did: the messages it built (sent, or not in a
    plain-JSON dry run), what the source reported about its read, how long the whole
    run took, and -- for the partition metadata -- the topic and any skip reason."""

    messages: tuple[KafkaMessage, ...]
    topic: str
    source_metadata: dict[str, object]
    dry_run: bool
    seconds: float
    skip_reason: str | None = None


class PublishPipeline:
    def __init__(
        self,
        *,
        source_factory: Callable[[BoundStatement], RowSource],
        message_format: MessageFormat,
        serializer: MessageSerializer,
        sink: MessageSink,
        dry_run_publishes: bool,
        metadata: Sequence[MetadataField] = (),
    ) -> None:
        self._source_factory: Callable[[BoundStatement], RowSource] = source_factory
        self._format: MessageFormat = message_format
        self._serializer: MessageSerializer = serializer
        self._sink: MessageSink = sink
        # The notebook semantics (envelope): a dry run publishes with IsDryRun: true.
        # The sibling semantics (plain JSON): a dry run sends nothing.
        self._dry_run_publishes: bool = dry_run_publishes
        self._metadata: tuple[MetadataField, ...] = tuple(metadata)

    def run(
        self,
        *,
        run: RunInfo,
        identity: MessageIdentity,
        statement: BoundStatement,
        topic: str,
        dry_run: bool,
        skip_reason: str | None = None,
    ) -> PublishResult:
        """One company's publish. `skip_reason` short-circuits to an empty result: an
        inactive configurator entry materializes as a no-op success, nothing read and
        nothing sent, the reason carried for the partition metadata."""
        started = time.monotonic()
        if skip_reason is not None:
            return PublishResult(
                messages=(),
                topic=topic,
                source_metadata={},
                dry_run=dry_run,
                seconds=time.monotonic() - started,
                skip_reason=skip_reason,
            )
        stream = self._source_factory(statement).read()
        self._format.check_schema(stream.schema)
        extra = metadata_fields(run, self._metadata)
        messages: list[KafkaMessage] = []
        for record in self._format.shape(stream.batches, run, identity):
            messages.append(self._serializer.serialize(record, extra))
        publishes = messages and (not dry_run or self._dry_run_publishes)
        if publishes:
            self._sink.publish(topic, messages)
        return PublishResult(
            messages=tuple(messages),
            topic=topic,
            source_metadata=dict(stream.metadata),
            dry_run=dry_run,
            seconds=time.monotonic() - started,
        )
