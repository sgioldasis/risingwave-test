"""One instance's configuration, as a frozen model the factory, the asset and the
resolvers read.

Construction refuses what would otherwise fail at run time -- the design's "fail loud
at load": unknown template placeholders, two resolvers producing the same variable, a
declared source no template uses, `configurator` without `companies`, a fan-out
template without a `{company_id}` filter, a wrong shape for the mode. Errors name the
`defs.yaml` attribute a value came from, since that is what the person fixing it edits.

The mode switch is the `companies` block: absent = single-statement mode (one query,
one topic -- the sibling wheel's shape); present = fan-out (a query template, a topic
template, and one partition per company).
"""

from typing import ClassVar

import dagster as dg
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..sink.formats.envelope import EnvelopeFormat
from ..sink.formats.json import JsonFormat
from .companies import Company
from .messages import MessageIdentity, MetadataField
from .resolution import check_single_sources
from .template import placeholders

# The variables the component itself produces, before any resolver runs.
BUILTIN_VARIABLES: frozenset[str] = frozenset(
    {"company_id", "com_code", "market_code", "run_id", "run_ts", "created_from"}
)


class CompaniesBlock(dg.Model, dg.Resolvable):
    """The fan-out mode's partition set: which companies the instance runs for, and
    where their identities come from. `include` (a static list) makes the partition set
    static; `source` (a table) makes it dynamic -- companies joining or leaving need no
    code deploy. `exclude` prunes the enumeration (the notebooks' static inactive
    list). A list names companies either by id (ints) or by their exact comCode
    (strings, compared case-insensitively) -- never a mix."""

    source: str | None = Field(
        default=None,
        description="The table the companies are enumerated from "
        + "(`de.metadatadb.mcompany` in the notebooks). The enumeration reads "
        + "CompanyId and comCode, minus `exclude`, in id order.",
    )
    include: list[int | str] | None = Field(
        default=None,
        description="A static company list: the partition set is fixed at load time "
        + "and every company must still be active in `source`'s table when the run "
        + "enumerates it. Entries are company ids (7) or exact comCodes (CYSTX, "
        + "case-insensitive) -- all of one kind, not a mix; a comCode prefix is "
        + "refused by design (codes share prefixes across markets). One of "
        + "`include` or `source`, not both.",
    )
    exclude: list[int | str] = Field(
        default_factory=list,
        description="Companies the enumeration skips -- the notebooks' static "
        + "inactive list (2, 3, 5, 6, 10, 12, 13, 14). Entries follow the same "
        + "id-or-exact-comCode rule as `include`. Only with `source`.",
    )

    @model_validator(mode="after")
    def _refuse_mixed_key_kinds(self) -> CompaniesBlock:
        for field_name, keys in (("include", self.include), ("exclude", self.exclude)):
            if keys and not (
                all(isinstance(key, int) for key in keys)
                or all(isinstance(key, str) for key in keys)
            ):
                raise ValueError(
                    f"companies.{field_name} is either all ids (ints) or all exact "
                    + "comCodes (strings) -- mixing them is ambiguous"
                )
        return self


class CompaniesBlockYAML(CompaniesBlock, dg.Model, dg.Resolvable):
    """(YAML alias -- see CompaniesBlock.)"""


class ConfiguratorBlock(dg.Model, dg.Resolvable):
    """The per-company parameter source: the notebooks' configurator client. Each
    active company's entry is fetched by its comCode; the entry's `isActive` is the
    implicit gate (inactive -- or absent -- is a valid skip); the declared `fields`
    become template variables and are required when the entry is active."""

    base_url: str = Field(
        description="The configurator deployment's base URL "
        + "(`{{ env('CONFIGURATOR_BASE_URL') }}`). Unauthenticated: access is "
        + "network position, so configuration values stay off the logs."
    )
    configuration_code: str = Field(
        description="The configuration to read "
        + "(e.g. UnverifiedCustomerLimitsUntilRestrictionConfig)."
    )
    fields: dict[str, str] = Field(
        default_factory=dict,
        description="Template variable <- the entry's field key "
        + "(`group_code: group` binds {group_code} from the entry's `group`). Fields "
        + "are matched case-insensitively and read as text; a declared field a "
        + "company's active entry lacks fails that company.",
    )


class GroupLookupBlock(dg.Model, dg.Resolvable):
    """The group-code resolution: the notebooks' `groups.ipynb`. The code-valued
    variable (a `mgrCode`, whatever produced it) resolves to `{group_id}` through
    `de.metadatadb.mgroup`; 0 or >1 matches fails the company, as the notebook's
    `require` does."""

    code: str = Field(
        description="The template variable carrying the group's mgrCode "
        + "(`group_code` when the configurator provided it)."
    )


MessageFormat = JsonFormat | EnvelopeFormat


class JobotronConfig(BaseModel):
    """One instance: the companies (maybe just one, implicitly), their parameters, one
    statement per company, and the messages that go to Kafka.

    Construction refuses what would otherwise fail at run time. Errors name the
    `defs.yaml` attribute a value came from (`workspace`, not `host`), since that is
    what the person fixing it edits."""

    model_config: ClassVar[ConfigDict] = ConfigDict(
        frozen=True, arbitrary_types_allowed=True
    )

    # Dagster: the asset's name, the code location's namespace, and the envelope's
    # JobName/JobId prefix -- the NOTEBOOK's name, not a YAML slug.
    name: str
    asset_key_prefix: tuple[str, ...]
    job_name: str = Field(
        description="The envelope's JobName and JobId prefix: the notebook's name (e.g. Send_Email_to_Unverified_Customers)."
    )

    # Source: the statement (template in fan-out mode), the workspace and the warehouse.
    query: str | None = None
    query_template: str | None = None
    host: str
    warehouse: str

    # Resolution: the mode switch and the resolvers, in their fixed order.
    companies: CompaniesBlock | None = None
    configurator: ConfiguratorBlock | None = None
    group_lookup: GroupLookupBlock | None = None
    parameters: dict[str, int | str | list[int] | list[str]] = Field(
        default_factory=dict
    )
    # Keys are company ids (ints) or exact comCodes (strings, matched
    # case-insensitively) -- the same rule as companies.include/exclude, and a mix of
    # the two is refused the same way.
    parameters_by_company: dict[
        int | str, dict[str, int | str | list[int] | list[str]]
    ] = Field(default_factory=dict)
    # Variables substituted as text (whitelist-validated) instead of bound: the ones
    # whose position is not a value slot (a table name, an interval literal).
    literal_parameters: tuple[str, ...] = ()

    # Sink: the Kafka cluster, the topic (routed per company in fan-out mode), the
    # message shape, and the plain-JSON-only run facts.
    kafka_profile: str
    topic: str | None = None
    topic_template: str | None = None
    message: MessageFormat
    metadata: tuple[MetadataField, ...] = ()
    schema_version: int = 1

    # Run options.
    dry_run: bool = True
    preview_limit: int = 0

    @property
    def fan_out(self) -> bool:
        return self.companies is not None

    @property
    def template(self) -> str:
        """The query template (or the plain query, in single-statement mode)."""
        return (self.query_template or "") if self.fan_out else (self.query or "")

    @property
    def topic_spec(self) -> str:
        """The topic template (or the plain topic, in single-statement mode)."""
        return (self.topic_template or "") if self.fan_out else (self.topic or "")

    def static_company_keys(self) -> list[int | str] | None:
        """The static partition set, when the companies block is a list: the include
        keys (ids or exact comCodes), or the parameters_by_company keys when there is
        no include."""
        if self.companies is None or self.companies.source is not None:
            return None
        if self.companies.include is not None:
            keys = self.companies.include
            # A homogeneous list (the validator refuses a mix): ids sort numerically,
            # codes lexically.
            return (
                sorted(keys)
                if all(isinstance(key, int) for key in keys)
                else sorted(keys, key=str)
            )
        if self.parameters_by_company:
            # Homogeneous keys (the validator refuses a mix), so this sorts either
            # numerically (ids) or lexically (codes).
            return sorted(self.parameters_by_company)
        return None

    @model_validator(mode="after")
    def _refuse_mixed_parameter_keys(self) -> JobotronConfig:
        keys = list(self.parameters_by_company)
        if keys and not (
            all(isinstance(key, int) for key in keys)
            or all(isinstance(key, str) for key in keys)
        ):
            raise ValueError(
                "parameters_by_company keys are either all ids (ints) or all exact "
                + "comCodes (strings) -- mixing them is ambiguous"
            )
        return self

    @model_validator(mode="after")
    def _refuse_what_would_fail_at_run_time(self) -> JobotronConfig:
        for field_name, value in (
            ("name", self.name),
            ("workspace", self.host),
            ("warehouse", self.warehouse),
            ("kafka_profile", self.kafka_profile),
            ("job_name", self.job_name),
        ):
            if not value.strip():
                raise ValueError(f"{field_name} must not be blank")
        for segment in self.asset_key_prefix:
            if not segment.strip():
                raise ValueError("asset_key_prefix segment must not be blank")
            if "/" in segment:
                raise ValueError(
                    f"asset_key_prefix segments must not contain '/' (it would not round-trip through a Dagster asset key); got {segment!r}"
                )
        if self.preview_limit < 0:
            raise ValueError("preview_limit must not be negative")
        self._check_mode()
        self._check_single_sources()
        self._check_placeholders()
        self._check_message_options()
        return self

    def _check_mode(self) -> None:
        if self.fan_out:
            companies = self.companies
            assert companies is not None  # fan_out is exactly this
            if not (self.query_template or "").strip():
                raise ValueError(
                    "fan-out mode (a companies block) needs query_template"
                )
            if not (self.topic_template or "").strip():
                raise ValueError(
                    "fan-out mode (a companies block) needs topic_template"
                )
            if self.query is not None or self.topic is not None:
                raise ValueError(
                    "a companies block makes the instance a fan-out: use "
                    + "query_template/topic_template, not query/topic"
                )
            if "{company_id}" not in (self.query_template or ""):
                raise ValueError(
                    "query_template must filter by {company_id} -- the comp_part "
                    + "pruning is what keeps another company's customers out of a "
                    + "company's topic"
                )
            if companies.include is not None and companies.source is not None:
                raise ValueError("companies: give one of include or source, not both")
            if companies.include is None and companies.source is None:
                raise ValueError(
                    "companies: give include (a static list) or source (a table to "
                    + "enumerate); the partition set needs one of them"
                )
            if companies.exclude and companies.source is None:
                raise ValueError(
                    "companies.exclude only prunes an enumeration; it needs companies.source"
                )
            if self.configurator is not None:
                if not self.configurator.base_url.strip():
                    raise ValueError("configurator.base_url must not be blank")
                if not self.configurator.configuration_code.strip():
                    raise ValueError(
                        "configurator.configuration_code must not be blank"
                    )
        else:
            if not (self.query or "").strip():
                raise ValueError(
                    "query is required (a companies block would make this a fan-out)"
                )
            if not (self.topic or "").strip():
                raise ValueError(
                    "topic is required (a companies block would make this a fan-out)"
                )
            if self.query_template is not None or self.topic_template is not None:
                raise ValueError(
                    "query_template/topic_template belong to a fan-out instance: add "
                    + "a companies block, or use query/topic"
                )
            if self.configurator is not None:
                raise ValueError(
                    "configurator requires companies (it resolves per company)"
                )
            if self.parameters_by_company:
                raise ValueError(
                    "parameters_by_company requires companies (it binds per company)"
                )

    def _check_single_sources(self) -> None:
        configurator_fields = self.configurator.fields if self.configurator else {}
        group_code = self.group_lookup.code if self.group_lookup else None
        _ = check_single_sources(
            self.parameters, self.parameters_by_company, configurator_fields, group_code
        )

    def _check_placeholders(self) -> None:
        """Every template placeholder needs exactly one source, and every declared
        source must be used -- a variable nobody reads is an authoring mistake that
        would otherwise hide (a renamed column in the template, say)."""
        used = set(placeholders(self.template)) | set(placeholders(self.topic_spec))
        produced = set(self.parameters)
        for company_values in self.parameters_by_company.values():
            produced.update(company_values)
        if self.configurator:
            produced.update(self.configurator.fields)
        if self.group_lookup:
            produced.add("group_id")
        unknown = sorted(used - produced - BUILTIN_VARIABLES)
        if unknown:
            raise ValueError(
                f"Template placeholder(s) {unknown} have no source -- declare them in "
                + "parameters, parameters_by_company or the configurator's fields"
            )
        # A configurator field can be an intermediate rather than a template value:
        # the group lookup's code names a field that resolves `group_id` without
        # ever appearing in a template.
        consumed_by_lookup: set[str] = (
            {self.group_lookup.code} if self.group_lookup else set()
        )
        unused = sorted(
            name
            for name in produced
            if name not in used and name not in consumed_by_lookup
        )
        if unused:
            raise ValueError(
                f"Declared template variable(s) {unused} appear in no template -- "
                + "remove them, or use them in query_template/topic_template"
            )
        for name in self.literal_parameters:
            if name not in produced and name not in BUILTIN_VARIABLES:
                raise ValueError(
                    f"literal_parameters names {name!r}, which no resolver produces"
                )

    def _check_message_options(self) -> None:
        if isinstance(self.message, EnvelopeFormat):
            if self.metadata:
                raise ValueError(
                    "metadata fields are a plain-JSON feature -- the envelope carries "
                    + "its own run identity (JobCreated, RunId, IsDryRun)"
                )
        else:
            if self.schema_version != 1:
                raise ValueError(
                    "schema_version is the envelope contract's version; plain-JSON "
                    + "messages have no schema"
                )

    def identity_for(self, company: Company | None) -> MessageIdentity:
        """The batch identity a company's messages carry. `company` is None in
        single-statement mode: the rows' own CompanyId column decides (the envelope
        format checks it)."""
        return MessageIdentity(
            job_name=self.job_name,
            company_id=company.company_id if company else None,
            schema_version=self.schema_version,
        )
