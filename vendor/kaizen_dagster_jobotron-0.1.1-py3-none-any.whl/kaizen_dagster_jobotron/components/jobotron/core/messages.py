"""The messages the modules pass between each other: a shaped row (`Record`), the bytes that
go on the wire (`KafkaMessage`) and what a run can stamp into every message (`RunInfo`).

All are frozen pydantic models, so a value that exists is a valid one and nothing
downstream re-checks it.


Ported verbatim from the sibling wheel kaizen-dagster-delta-to-kafka, where this
exact module was reviewed and shipped; any difference is a bug here."""

from dataclasses import dataclass
from datetime import datetime
from typing import ClassVar, Literal

from pydantic import BaseModel, ConfigDict


class Record(BaseModel):
    """One row, shaped by a message format and ready to be encoded: the Kafka key and the
    JSON object that becomes the value. Not yet bytes."""

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    key: str
    payload: dict[str, object]


class KafkaMessage(BaseModel):
    """One message as it goes on the wire."""

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    key: bytes
    value: bytes


class RunInfo(BaseModel):
    """What the run can stamp into every message as metadata: the instance's `name` and
    the run's id, start time and mode."""

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    name: str
    run_id: str
    created: datetime
    dry_run: bool


# The run facts an instance can add to every message (see message_metadata.py).
# A plain alias, not a `type` statement: Dagster derives the YAML model from it.
MetadataField = Literal["processed_at", "run_id", "name", "dry_run"]


@dataclass(frozen=True)
class MessageIdentity:
    """Whose messages a run's batch are: the envelope stamps these on every item. One
    value per company per run. `company_id` is None only in single-statement mode,
    where the rows' own `CompanyId` column decides (and must be one company)."""

    job_name: str
    company_id: int | None
    schema_version: int = 1
