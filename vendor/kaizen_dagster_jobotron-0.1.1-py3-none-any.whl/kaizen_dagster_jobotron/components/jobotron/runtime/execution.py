"""One company's run, end to end: enumerate it, resolve its parameters, bind the
statement, publish. The asset calls this per partition; the tests call it with fakes.

The order is the notebooks' loop body, with the loop itself replaced by the partition:
enumerate the company (its comCode is what the configurator is asked with), fetch its
configurator entry (inactive = a valid skip), resolve the algebra in its fixed order,
bind the statement -- parameters array, never interpolated -- and publish to the
company's routed topic.
"""

from dagster import DagsterLogManager
from databricks.sdk import WorkspaceClient

from ..core.companies import Company, companies_statement, parse_companies
from ..core.config import JobotronConfig
from ..core.messages import RunInfo
from ..core.pipeline import PublishPipeline
from ..core.resolution import resolve_company
from ..core.template import BoundStatement, bind, bind_parameter, render_topic
from ..source.configurator import (
    ConfiguratorClient,
    parse_entry,
    required_fields,
)
from ..source.rows import fetch_rows

# The notebooks' company table, when the instance does not name one.
DEFAULT_SOURCE = "de.metadatadb.mcompany"

# The notebooks' groups table: the one `groups.ipynb` resolves through.
GROUPS_TABLE = "de.metadatadb.mgroup"


def enumerate_company(
    cfg: JobotronConfig,
    company_key: int | str,
    client: WorkspaceClient,
    log: DagsterLogManager | None,
) -> Company:
    """The one company's identity from the enumeration table: its comCode, and the
    proof that it is active. The key is the partition's company: an id or an exact
    comCode (case-insensitive), matching how the instance's `companies.include` names
    it. A partition key naming a company the table does not have (or that the exclude
    list prunes) fails the partition -- the notebooks' enumeration simply never sees
    such a company."""
    source = (cfg.companies.source if cfg.companies else None) or DEFAULT_SOURCE
    statement = companies_statement(source_table=source, include=[company_key])
    rows = fetch_rows(client, cfg.warehouse, statement, log)
    companies = parse_companies(rows)
    for company in companies:
        if company.matches(company_key):
            return company
    raise ValueError(
        f"Company {company_key!r} is not in the enumeration of {source} -- inactive, "
        + "unknown, or pruned by companies.exclude"
    )


def group_id_lookup(
    cfg: JobotronConfig, client: WorkspaceClient, log: DagsterLogManager | None
):
    """The mgroup seam the group resolver binds through: a code -> its one mgrGroupID,
    failing on 0 or >1 matches exactly as the notebook's `require` does. The code
    arrives bound as a parameter -- it comes from configuration, never from SQL text
    (the notebook's own comment)."""

    def lookup(code: str) -> int:
        statement = BoundStatement(
            f"select mgrGroupID from {GROUPS_TABLE} where mgrCode = :code",
            [bind_parameter("code", code)],
        )
        rows = fetch_rows(client, cfg.warehouse, statement, log)
        ids = [int(str(row["mgrGroupID"])) for row in rows]
        if not ids:
            raise ValueError(f"No group found in {GROUPS_TABLE} with mgrCode '{code}'")
        if len(ids) > 1:
            raise ValueError(
                f"{len(ids)} groups found in {GROUPS_TABLE} with mgrCode '{code}': "
                + f"{ids}"
            )
        return ids[0]

    return lookup


def configurator_values(
    cfg: JobotronConfig,
    company: Company,
    configurator: ConfiguratorClient,
) -> tuple[dict[str, str] | None, str | None]:
    """The company's configurator entry, parsed the notebook's way: (fields, skip).
    An inactive entry -- or one without isActive -- is the valid skip; the declared
    fields of an active entry are required."""
    assert cfg.configurator is not None
    value = configurator.configuration_value(
        cfg.configurator.configuration_code, company.com_code
    )
    entry, skip = parse_entry(
        value,
        configuration_code=cfg.configurator.configuration_code,
        hierarchy_node_code=company.com_code,
    )
    if skip is not None:
        return None, skip
    assert entry is not None
    return (
        required_fields(
            entry,
            cfg.configurator.fields,
            configuration_code=cfg.configurator.configuration_code,
            hierarchy_node_code=company.com_code,
        ),
        None,
    )


def per_company_parameters(
    cfg: JobotronConfig, company: Company
) -> dict[str, int | str | list[int] | list[str]]:
    """The per-company values for one enumerated company: the entry whose key is its
    id (int) or exact comCode (str, case-insensitive) -- the same matching rule as
    the include/exclude lists."""
    for key, values in cfg.parameters_by_company.items():
        if company.matches(key):
            return values
    return {}


def run_company(
    *,
    cfg: JobotronConfig,
    company: Company | None,
    run: RunInfo,
    dry_run: bool,
    pipeline: PublishPipeline,
    client: WorkspaceClient | None = None,
    configurator: ConfiguratorClient | None = None,
    log: DagsterLogManager | None = None,
):
    """One company's publish (or the whole run, in single-statement mode). Returns the
    pipeline's result: messages, topic, skip reason, timings."""
    skip_reason: str | None = None
    configurator_fields: dict[str, str] | None = None
    if cfg.fan_out:
        assert company is not None
        assert client is not None
        if cfg.configurator:
            assert configurator is not None
            configurator_fields, skip_reason = configurator_values(
                cfg, company, configurator
            )
    resolution = resolve_company(
        company_id=company.company_id if company else 0,
        com_code=company.com_code if company else "",
        run=run,
        static=cfg.parameters,
        per_company=per_company_parameters(cfg, company) if company else {},
        configurator=configurator_fields,
        configurator_skip=skip_reason,
        group_lookup_code=cfg.group_lookup.code if cfg.group_lookup else None,
        group_id_of=group_id_lookup(cfg, client, log)
        if cfg.group_lookup and client is not None
        else None,
    )
    if resolution.skipped:
        # A skipped partition has no topic: the resolution's values are empty by
        # design (nothing was resolved), so there is nothing to render from.
        return pipeline.run(
            run=run,
            identity=cfg.identity_for(company),
            statement=BoundStatement("", []),
            topic="",
            dry_run=dry_run,
            skip_reason=resolution.skip_reason,
        )
    # One path for both modes: in single mode the topic is a plain string (the
    # validator requires it), so rendering substitutes nothing.
    topic = render_topic(cfg.topic_spec, resolution.values)
    literals = {
        name: resolution.values[name]
        for name in cfg.literal_parameters
        if name in resolution.values
    }
    statement = bind(cfg.template, resolution.values, literals)
    return pipeline.run(
        run=run,
        identity=cfg.identity_for(company),
        statement=statement,
        topic=topic,
        dry_run=dry_run,
    )
