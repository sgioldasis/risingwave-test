"""The composition root: the one place that knows which implementation answers which interface.

`build_pipeline` turns an instance's configuration into a `PublishPipeline`: the Kafka
profile is read, the Databricks credentials are read from the environment, and the
Databricks source, the message format and the Kafka sink are wired to the pipeline.
The environment is read when the pipeline is built (a run starting), never at import,
and the Databricks client and the Kafka producer are only made when a read or a publish
happens.

The client and producer factories are parameters so a test can hand in fakes without
patching anything. Whether a dry run publishes is the format mode's: the envelope
publishes with IsDryRun: true (the notebooks' semantics -- the Worker no-ops it),
plain JSON keeps the sibling's build-everything-send-nothing.
"""

import os
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass

from dagster import DagsterLogManager
from databricks.sdk import WorkspaceClient

from ..core.config import JobotronConfig
from ..core.pipeline import PublishPipeline
from ..core.template import BoundStatement
from ..sink.encoding import JsonMessageSerializer
from ..sink.formats.envelope import EnvelopeFormat
from ..sink.kafka import KafkaSink, ProducerLike, producer
from ..sink.kafka_profile import KafkaProfile, load_profile
from ..source.authentication import (
    Credentials,
    open_workspace_client,
    read_credentials,
)
from ..source.configurator import ConfiguratorClient, open_url
from ..source.rows import StatementExecutionSource


def build_pipeline(
    cfg: JobotronConfig,
    log: DagsterLogManager | None = None,
    *,
    environ: Mapping[str, str] | None = None,
    client_factory: Callable[
        [str, Credentials], WorkspaceClient
    ] = open_workspace_client,
    producer_factory: Callable[[KafkaProfile], ProducerLike] = producer,
) -> PublishPipeline:
    """The pipeline an instance's partitions run. The profile is read first, so a
    broken one fails a dry run too; its password is only read when something is
    actually published."""
    profile = load_profile(cfg.kafka_profile)
    credentials = read_credentials(os.environ if environ is None else environ)

    def source_factory(statement: BoundStatement) -> StatementExecutionSource:
        return StatementExecutionSource(
            host=cfg.host,
            credentials=credentials,
            warehouse=cfg.warehouse,
            statement=statement,
            client_factory=client_factory,
            log=log,
        )

    return PublishPipeline(
        source_factory=source_factory,
        message_format=cfg.message,
        serializer=JsonMessageSerializer(),
        sink=KafkaSink(profile, producer_factory),
        dry_run_publishes=isinstance(cfg.message, EnvelopeFormat),
        metadata=cfg.metadata,
    )


def build_configurator(
    cfg: JobotronConfig,
    *,
    opener: object = open_url,
    sleep: Callable[[float], None] = time.sleep,
) -> ConfiguratorClient | None:
    """The configurator client, when the instance resolves per-company parameters
    through one. The base URL is templated (`{{ env(...) }}`) by Dagster before the
    model sees it. The opener and the sleep are parameters so a test hands in fakes."""
    if cfg.configurator is None:
        return None
    return ConfiguratorClient(
        cfg.configurator.base_url,
        opener=opener,  # pyright: ignore[reportArgumentType] -- the Protocol and the default agree structurally
        sleep=sleep,
    )


def open_enumeration_client(
    cfg: JobotronConfig,
    *,
    environ: Mapping[str, str] | None = None,
    client_factory: Callable[
        [str, Credentials], WorkspaceClient
    ] = open_workspace_client,
) -> WorkspaceClient:
    """The client the resolution seams read through (the company enumeration, the
    group lookup): the same workspace and credentials the statements use."""
    credentials = read_credentials(os.environ if environ is None else environ)
    return client_factory(cfg.host, credentials)


@dataclass(frozen=True)
class RunContext:
    """What one run needs wired: the publish pipeline, the client the resolution seams
    read through, and the configurator client when the instance has one."""

    pipeline: PublishPipeline
    client: WorkspaceClient
    configurator: ConfiguratorClient | None


def build_run_context(
    cfg: JobotronConfig,
    log: DagsterLogManager | None = None,
    *,
    environ: Mapping[str, str] | None = None,
    client_factory: Callable[
        [str, Credentials], WorkspaceClient
    ] = open_workspace_client,
    producer_factory: Callable[[KafkaProfile], ProducerLike] = producer,
    configurator_opener: object = open_url,
    configurator_sleep: Callable[[float], None] = time.sleep,
) -> RunContext:
    """The run's wiring, from the instance's configuration. The asset gets this from
    the `build` parameter it is decorated with, so a test hands in the real factory
    with fake clients and a recording producer."""
    return RunContext(
        pipeline=build_pipeline(
            cfg, log, client_factory=client_factory, producer_factory=producer_factory
        ),
        client=open_enumeration_client(
            cfg, environ=environ, client_factory=client_factory
        ),
        configurator=build_configurator(
            cfg, opener=configurator_opener, sleep=configurator_sleep
        ),
    )
