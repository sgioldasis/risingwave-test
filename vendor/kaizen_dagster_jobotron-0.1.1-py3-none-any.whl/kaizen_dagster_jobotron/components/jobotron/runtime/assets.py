"""The publish asset -- the instance's whole Dagster surface (the component is
publish-only).

Fan-out mode (a `companies` block) is a **partitioned asset: one partition per
company** -- the notebooks' failure-isolation loop expressed as Dagster partitions. A
company materializes independently (its own statement, topic, status); a failed
company fails its partition, not the run; re-running just one company after an
incident, backfilling a newly onboarded one, and per-company observability are
Dagster-native. A static `include` list makes the partition set a
`StaticPartitionsDef`; a `source` table makes it a `DynamicPartitionsDef` (companies
joining or leaving need no code deploy -- the host registers the enumeration's keys;
see the README).

This module is only the Dagster edge: the decoration, the run-mode override, and
turning a `PublishResult` into the run's logs and metadata. What a partition does is
`runtime/execution.run_company` over the pipeline `runtime/factory` wires; a test hands
`build_instance_defs` its own `build` to run against fakes.

Topic provisioning belongs to deployment infrastructure, not the component -- the
instance's topics must already exist when the asset publishes.
"""

import json
import re
from collections.abc import Callable, Sequence
from datetime import UTC, datetime
from typing import cast

from dagster import (
    AssetExecutionContext,
    AssetKey,
    DagsterLogManager,
    Definitions,
    DynamicPartitionsDefinition,
    MetadataValue,
    StaticPartitionsDefinition,
    asset,
)

from ..core.config import JobotronConfig
from ..core.messages import KafkaMessage, RunInfo
from ..core.pipeline import PublishResult
from ..sink.formats.envelope import EnvelopeFormat
from .execution import enumerate_company, run_company
from .factory import RunContext, build_run_context
from .run_mode import effective_dry_run, run_mode_for

# How the asset gets its wiring: `factory.build_run_context` in a deployment, the same
# function with fake clients in a test.
RunContextFactory = Callable[[JobotronConfig, DagsterLogManager | None], RunContext]


def dagster_identifier(value: str) -> str:
    """Coerce a value into something Dagster accepts as a definition name."""
    identifier = re.sub(r"[^A-Za-z0-9_]", "_", value).strip("_")
    return identifier or "job"


def asset_key(cfg: JobotronConfig) -> AssetKey:
    """The prefix and the name as segments (`inverness/<name>`);
    `to_user_string()` is what a `defs.yaml` dependency spells."""
    return AssetKey([*cfg.asset_key_prefix, cfg.name])


def group_name(cfg: JobotronConfig) -> str:
    return dagster_identifier("_".join([*cfg.asset_key_prefix, cfg.name]))


def previews(messages: Sequence[KafkaMessage], limit: int) -> list[dict[str, object]]:
    """The first `limit` messages as {"key", "value"} for run metadata, decoded from the
    wire JSON. A limit of 0 (the default) echoes nothing: the rows are often customer
    data, so showing them is opt-in."""
    return [
        {
            "key": message.key.decode("utf-8"),
            "value": cast("object", json.loads(message.value)),
        }
        for message in messages[:limit]
    ]


def result_metadata(
    cfg: JobotronConfig, result: PublishResult, company_id: int | None
) -> dict[str, object]:
    """The partition's metadata: what the ops surface reads (counts, topic, timings,
    skip reasons)."""
    return {
        "items_count": MetadataValue.int(len(result.messages)),
        "topic": MetadataValue.text(result.topic),
        "dry_run": MetadataValue.bool(result.dry_run),
        "query": MetadataValue.text(cfg.template),
        "publish_seconds": MetadataValue.float(round(result.seconds, 1)),
        **(
            {"company_id": MetadataValue.int(company_id)}
            if company_id is not None
            else {}
        ),
        **(
            {"skip_reason": MetadataValue.text(result.skip_reason)}
            if result.skip_reason is not None
            else {}
        ),
        **(
            {
                "message_previews": MetadataValue.json(
                    previews(result.messages, cfg.preview_limit)
                )
            }
            if cfg.preview_limit
            else {}
        ),
        **result.source_metadata,
    }


def partitions_def_of(
    cfg: JobotronConfig,
) -> StaticPartitionsDefinition | DynamicPartitionsDefinition:
    """The fan-out partition set: a static include list is static (the keys are the
    ids or exact comCodes, stringified); a source table is dynamic (the host registers
    the enumeration's keys; a new company needs no code deploy)."""
    static = cfg.static_company_keys()
    if static is not None:
        return StaticPartitionsDefinition([str(key) for key in static])
    return DynamicPartitionsDefinition(
        name=dagster_identifier(
            "_".join([*cfg.asset_key_prefix, cfg.name, "companies"])
        )
    )


def company_key_of(cfg: JobotronConfig, partition_key: str) -> int | str:
    """The partition's company key, as the instance's companies block names companies:
    an id the key parses to when the static include lists ids, the key itself
    otherwise -- the comCode, whether the static list named it or the enumeration
    registered it (`matches` compares comCodes case-insensitively)."""
    static = cfg.static_company_keys()
    if static and all(isinstance(key, int) for key in static):
        return int(partition_key or "")
    return partition_key


def build_instance_defs(
    cfg: JobotronConfig, build: RunContextFactory = build_run_context
) -> Definitions:
    """The instance's Definitions: exactly the publish asset, no jobs. Schedules are a
    host concern (a job + schedule materializing all partitions, or a subset after an
    incident); the component emits the partitioned asset."""
    run_mode = run_mode_for(cfg)

    if not cfg.fan_out:

        @asset(
            name=cfg.name,
            key_prefix=list(cfg.asset_key_prefix),
            group_name=group_name(cfg),
            description=(
                "Run the query on the SQL warehouse and publish the result to "
                + f"{cfg.topic}. Under dry-run the messages are built and "
                + (
                    "published with IsDryRun: true (the Worker no-ops them)."
                    if isinstance(cfg.message, EnvelopeFormat)
                    else "nothing is sent."
                )
            ),
        )
        # `-> None` keeps the I/O manager out of it: the asset reports metadata and has
        # no value to store.
        def publish_single(context: AssetExecutionContext, config: run_mode) -> None:  # type: ignore[valid-type]  # pyright: ignore[reportInvalidTypeForm, reportUnknownParameterType] -- a per-instance Config subclass (the launchpad scaffold's prefill); dagster reads the annotation class at decoration time
            dry_run = effective_dry_run(cfg, config, context)  # pyright: ignore[reportUnknownArgumentType]
            wired = build(cfg, context.log)
            run = RunInfo(
                name=cfg.name,
                run_id=context.run_id,
                created=datetime.now(UTC),
                dry_run=dry_run,
            )
            result = run_company(
                cfg=cfg,
                company=None,
                run=run,
                dry_run=dry_run,
                pipeline=wired.pipeline,
                client=wired.client,
                configurator=wired.configurator,
                log=context.log,
            )
            _log_result(context, cfg, result)
            context.add_output_metadata(result_metadata(cfg, result, None))

        return Definitions(assets=[publish_single])

    @asset(
        name=cfg.name,
        key_prefix=list(cfg.asset_key_prefix),
        group_name=group_name(cfg),
        partitions_def=partitions_def_of(cfg),
        description=(
            "One company's publish: the partition's company is enumerated, its "
            + "parameters resolved, its statement bound and its messages published to "
            + "its routed topic. A company's failure fails its partition only; an "
            + "inactive configurator entry is a no-op success."
        ),
    )
    # `-> None` keeps the I/O manager out of it: the asset reports metadata and has
    # no value to store.
    def publish_company(context: AssetExecutionContext, config: run_mode) -> None:  # type: ignore[valid-type]  # pyright: ignore[reportInvalidTypeForm, reportUnknownParameterType] -- see the note above
        company_key = company_key_of(cfg, context.partition_key or "")
        dry_run = effective_dry_run(cfg, config, context)  # pyright: ignore[reportUnknownArgumentType]
        wired = build(cfg, context.log)
        run = RunInfo(
            name=cfg.name,
            run_id=context.run_id,
            created=datetime.now(UTC),
            dry_run=dry_run,
        )
        company = enumerate_company(cfg, company_key, wired.client, context.log)
        context.log.info(
            f"Company {company.company_id} ({company.com_code}): topic code "
            + f"{company.market_code}"
        )
        result = run_company(
            cfg=cfg,
            company=company,
            run=run,
            dry_run=dry_run,
            pipeline=wired.pipeline,
            client=wired.client,
            configurator=wired.configurator,
            log=context.log,
        )
        _log_result(context, cfg, result)
        context.add_output_metadata(result_metadata(cfg, result, company.company_id))

    return Definitions(assets=[publish_company])


def _log_result(
    context: AssetExecutionContext, cfg: JobotronConfig, result: PublishResult
) -> None:
    if result.skip_reason is not None:
        context.log.info(f"Skipped: {result.skip_reason}")
        return
    if result.dry_run and not result.messages:
        context.log.info("Dry run: the query returned no rows, so nothing to publish")
    elif result.dry_run:
        context.log.info(
            f"Dry run: built {len(result.messages)} message(s) for {result.topic}"
            + (
                " and published them with IsDryRun: true (the Worker no-ops them)"
                if isinstance(cfg.message, EnvelopeFormat)
                else " and sent NOTHING"
            )
        )
    else:
        context.log.info(
            f"Published {len(result.messages)} message(s) to {result.topic} ({cfg.kafka_profile})"
        )
