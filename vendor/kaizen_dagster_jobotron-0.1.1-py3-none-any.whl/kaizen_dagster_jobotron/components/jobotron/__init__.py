from .component import JobotronComponent

__all__ = ["JobotronComponent"]
