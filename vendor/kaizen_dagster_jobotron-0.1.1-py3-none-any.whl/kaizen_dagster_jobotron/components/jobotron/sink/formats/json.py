"""The plain-JSON message format: one JSON message per row, the row as the query
returned it, keyed by one column. The query decides which columns are sent; nothing is
added or wrapped here (run metadata is added by the encoding step, when the instance
asks for it). The demo's format -- the envelope is the contract mode.

Adapted from the sibling wheel for the whole-read seam: the batches are consumed in
order, with the row numbers carried across chunk boundaries.
"""

from collections.abc import Iterator
from typing import Literal, cast

import dagster as dg
import pyarrow as pa
from pydantic import Field, field_validator, model_validator

from ...core.messages import MessageIdentity, Record, RunInfo
from ..encoding import key_text


class JsonFormat(dg.Model, dg.Resolvable):
    """The `message` section: the value is the row as JSON (the query's column order,
    nulls explicit) and the key is `key_column`'s value. `envelope` is the other
    format."""

    format: Literal["json"] = Field(
        description="The message format. `json` is the row as the query returned it; "
        + "`envelope` (the contract mode) wraps it in the 13-field Jobotron envelope."
    )
    key_column: str = Field(
        description="The result column the Kafka key is taken from. It must be in "
        + "every row's result and never null."
    )

    @field_validator("format", mode="before")
    @classmethod
    def _refuse_any_other_format(cls, value: object) -> object:
        if value != "json":
            raise ValueError(f"format must be 'json' or 'envelope'; got {value!r}")
        return value

    @model_validator(mode="after")
    def _refuse_a_blank_key_column(self) -> JsonFormat:
        if not self.key_column.strip():
            raise ValueError("key_column must not be blank")
        return self

    def check_schema(self, schema: pa.Schema) -> None:
        """A result without the key column fails here, before any row is read -- an empty
        result included, since it still carries its column names."""
        columns = list(schema.names)
        if self.key_column not in columns:
            raise ValueError(
                f"The query result has no key column {self.key_column!r} (found {columns}) -- alias it in the SELECT or change key_column"
            )

    def shape(
        self,
        batches: Iterator[pa.RecordBatch],
        # The seam passes the run and identity the envelope uses; the plain format
        # adds none.
        run: RunInfo,  # pyright: ignore[reportUnusedParameter]
        identity: MessageIdentity,  # pyright: ignore[reportUnusedParameter]
    ) -> list[Record]:
        """The read's rows as records, in the result's order. A row whose key is null
        fails here, before anything is encoded. `run` and `identity` are unused: the
        plain format adds no envelope of its own."""
        records: list[Record] = []
        first_row_number = 1
        for batch in batches:
            for number, row in enumerate(batch.to_pylist(), start=first_row_number):
                key = cast("object", row[self.key_column])
                if key is None:
                    raise ValueError(
                        f"Row {number} has a null {self.key_column} -- the Kafka record key cannot be null"
                    )
                records.append(Record(key=key_text(key), payload=row))
            first_row_number += batch.num_rows
        return records
