"""The envelope message format: the 13-field Jobotron envelope (core/envelope.py)
around each row, keyed by the stringified `CustomerId`. The contract mode -- the
notebooks' Workers parse this, and byte-for-byte compatibility with the notebook
publisher is the guarantee.

The whole read is the materialized snapshot: the format consumes every batch, so the
source's completeness check fires before the first message exists, and `ItemsCount` /
`ItemNumber` come from one query run.
"""

from collections.abc import Iterator
from typing import Literal, cast

import dagster as dg
import pyarrow as pa
from pydantic import Field, field_validator, model_validator

from ...core.envelope import EnvelopeBuilder
from ...core.messages import MessageIdentity, Record, RunInfo
from ..encoding import key_text


class EnvelopeFormat(dg.Model, dg.Resolvable):
    """The `message` section: the row becomes `ItemPayload` inside the envelope, the key
    is `CustomerId` stringified (the notebook casts it to StringType), and the run
    identity (`JobId`, `JobCreated`, `RunId`, `IsDryRun`) is stamped per message."""

    format: Literal["envelope"] = Field(
        description="The message format. `envelope` is the Jobotron contract; `json` "
        + "(the row as the query returned it) is the demo mode."
    )
    key_column: str = Field(
        description="The result column the Kafka key is taken from, stringified. The "
        + "envelope's own identity column is `CustomerId` and every notebook keys on "
        + "it; a different value must be a column the envelope builder accepts."
    )

    @field_validator("format", mode="before")
    @classmethod
    def _refuse_any_other_format(cls, value: object) -> object:
        if value != "envelope":
            raise ValueError(f"format must be 'envelope' or 'json'; got {value!r}")
        return value

    @model_validator(mode="after")
    def _refuse_a_blank_key_column(self) -> EnvelopeFormat:
        if not self.key_column.strip():
            raise ValueError("key_column must not be blank")
        return self

    def check_schema(self, schema: pa.Schema) -> None:
        """A result without the key column fails here, before any row is read."""
        columns = list(schema.names)
        if self.key_column not in columns:
            raise ValueError(
                f"The query result has no key column {self.key_column!r} (found {columns}) -- alias it in the SELECT or change key_column"
            )

    def shape(
        self,
        batches: Iterator[pa.RecordBatch],
        run: RunInfo,
        identity: MessageIdentity,
    ) -> list[Record]:
        """The read as envelope records. The rows are the payloads (every column of a
        row becomes its ItemPayload, as the notebook's `struct(snapshot.columns)`), the
        key is the stringified key-column value, and the builder orders and numbers the
        items by `CustomerId`."""
        rows: list[dict[str, object]] = []
        keys: list[str] = []
        for batch in batches:
            for row in batch.to_pylist():
                key = cast("object", row[self.key_column])
                if key is None:
                    raise ValueError(
                        f"A row has a null {self.key_column} -- the Kafka record key cannot be null"
                    )
                rows.append(row)
                keys.append(key_text(key))
        company_id = _one_company(rows, identity.company_id)
        builder = EnvelopeBuilder(
            job_name=identity.job_name,
            company_id=company_id,
            schema_version=identity.schema_version,
        )
        envelopes = builder.build(rows, run=run)
        return [
            Record(key=key, payload=envelope)
            for key, envelope in zip(keys, envelopes, strict=True)
        ]


def _one_company(rows: list[dict[str, object]], company_id: int | None) -> int:
    """The batch's one company, from the rows' `CompanyId` column -- every notebook
    selects it, and it is the isolation guarantee made checkable: a fan-out partition
    for company 7 refuses a read that carries company 9's customers (a query that lost
    its `comp_part` filter, say) instead of publishing the leak. In single-statement
    mode (`company_id` is None) the column decides, but the batch must still be one
    company: the envelope's JobId and CompanyId are per company."""
    if not rows:
        # An empty result publishes nothing; the identity is never used.
        return 0 if company_id is None else company_id
    seen = {row.get("CompanyId") for row in rows}
    if None in seen:
        raise ValueError(
            "The query result has a null CompanyId -- the envelope needs each row's "
            + "company (alias it in the SELECT)"
        )
    if len(seen) > 1:
        raise ValueError(
            f"The query result mixes companies {sorted(seen, key=str)} -- a company's topic "
            + "must not carry another company's customers; check the comp_part filter"
        )
    derived = next(iter(seen))
    if not isinstance(derived, int) or isinstance(derived, bool):
        raise TypeError(
            f"The query result's CompanyId is a {type(derived).__name__}; the envelope needs an int"
        )
    if company_id is not None and derived != company_id:
        raise ValueError(
            f"The query returned CompanyId {derived} for partition company {company_id} "
            + "-- another company's customers would leak into this topic; check the "
            + "comp_part filter"
        )
    return derived
