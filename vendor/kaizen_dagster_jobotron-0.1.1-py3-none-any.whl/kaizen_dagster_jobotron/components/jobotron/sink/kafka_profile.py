"""A Kafka profile and where it is read from: one entry of the profiles file (HOCON,
`kafka_profiles.conf` beside this module). Reading only: no secret is fetched here, and
nothing touches the network.


Ported verbatim from the sibling wheel kaizen-dagster-delta-to-kafka, where this
exact module was reviewed and shipped; any difference is a bug here."""

from pathlib import Path
from typing import ClassVar, cast

from pydantic import BaseModel, ConfigDict, Field, model_validator

# pyhocon publishes no type stubs.
from pyhocon import ConfigFactory  # pyright: ignore[reportMissingTypeStubs]

PROFILES_FILE = Path(__file__).with_name("kafka_profiles.conf")

# The Scala profiles' own spelling of the options key.
_OPTIONS_KEY = "kakfaOptions"
_OPTION_PREFIX = "kafka."


class KafkaProfile(BaseModel):
    """One entry of the Kafka profiles file: where the cluster is and how to
    authenticate to it. The password is not in the profile, only the name of the secret
    that holds it, which is also the name of the environment variable the deployment
    exposes it as, read as it is written."""

    model_config: ClassVar[ConfigDict] = ConfigDict(frozen=True)

    name: str
    bootstrap_servers: str
    user: str | None = None
    password_secret_key: str | None = None
    # The profile's Kafka options as the producer spells them: the profile's `kafka.`
    # prefix is already stripped (`kafka.security.protocol` -> `security.protocol`).
    options: dict[str, str] = Field(default_factory=dict)

    @property
    def uses_sasl(self) -> bool:
        return self.options.get("security.protocol", "").upper().startswith("SASL")

    @model_validator(mode="after")
    def _sasl_needs_a_user_and_a_secret(self) -> KafkaProfile:
        if not self.bootstrap_servers.strip():
            raise ValueError(
                f"profile {self.name!r} bootstrap servers must not be blank"
            )
        if self.uses_sasl and not (self.user and self.password_secret_key):
            raise ValueError(
                f"profile {self.name!r} uses {self.options['security.protocol']} but has "
                + "no kafkaUser / kafkaPasswordSecretKey"
            )
        return self


def _text(entry: dict[str, object], key: str) -> str | None:
    value = entry.get(key)
    return None if value is None else str(value)


def load_profile(name: str, path: Path = PROFILES_FILE) -> KafkaProfile:
    """The named profile. An unknown name, an unreadable file or a profile without
    bootstrap servers fails with the profile's name, never a secret."""
    parsed = ConfigFactory.parse_string(path.read_text(encoding="utf-8"))  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    profiles = cast("dict[str, object]", parsed.as_plain_ordered_dict())  # pyright: ignore[reportUnknownMemberType]
    entry = profiles.get(name)
    if entry is None:
        known = ", ".join(sorted(profiles)) or "none"
        raise ValueError(
            f"Unknown Kafka profile {name!r} in {path.name} (known: {known})"
        )
    fields = cast("dict[str, object]", entry)
    raw_options = cast("dict[str, object]", fields.get(_OPTIONS_KEY) or {})
    options = {
        key.removeprefix(_OPTION_PREFIX): str(value)
        for key, value in raw_options.items()
    }
    return KafkaProfile(
        name=name,
        bootstrap_servers=_text(fields, "kafkaBootstrapServers") or "",
        user=_text(fields, "kafkaUser"),
        password_secret_key=_text(fields, "kafkaPasswordSecretKey"),
        options=options,
    )
