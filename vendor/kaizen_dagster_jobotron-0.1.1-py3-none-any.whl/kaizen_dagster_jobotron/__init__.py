"""The Jobotron Dagster component library: per-company SQL -> the 13-field envelope -> Kafka."""

from .components.jobotron.component import JobotronComponent

__all__ = ["JobotronComponent"]
